# -*- coding: utf-8 -*-
"""Модули испытаний «Сапёра» и их совместная работа.

АРХИТЕКТУРА СОЕДИНЕНИЯ ИСПЫТАНИЙ
--------------------------------
Каждое испытание — модуль с тремя обязательными точками входа:

    on_first_cell_opened(x, y)   == OnFirstCellOpened()
        срабатывает один раз после открытия первой ячейки;
    on_update(dt)                == OnUpdate(deltaTime)
        вызывается каждый кадр;
    on_cell_changed(coord, kind) == OnCellChanged(cell)
        когда меняется одна клетка (kind: "open" | "flag" | "explode");
    on_board_changed(reason)     == OnBoardChanged()
        когда меняется всё поле (тасовка, взрыв фугаса и т.д.).

Модули НЕ знают друг о друге напрямую: они читают и пишут общее
состояние раунда (поле board, фазы, таймеры — всё лежит в объекте
игры self.g) и получают события от игры-«хаба».

Порядок выполнения каждый кадр (порядок списка модулей):

    1. ОРБИТА   — движение + вращение поля;
    2. ТАСОВКА  — проверка таймера и запуск анимации тасовки;
    3. ФУГАС    — проверка таймеров временных бомб;
    4. БЛИЦ     — таймер партии;
    5. ДИВЕРСАНТ — страховка «без флажков»;
    6. ТУМАН    — туман над клетками и лампа (после всех сдвигов поля);
    ...затем отрисовка + камера (в коде окна).

ПРАВИЛА СОВМЕСТИМОСТИ
---------------------
    ОРБИТА + ТАСОВКА : тасовка работает в локальных координатах поля,
                       карта в это время продолжает крутиться и ехать
                       по восьмёрке; траектория не прыгает; зум и
                       Shift+ЛКМ работают.
    ОРБИТА + ФУГАС   : временная бомба живёт в координатах поля;
                       таймер и клик по ней работают, пока поле едет;
                       Shift+ЛКМ по-прежнему не открывает клетки.
    ТАСОВКА + ФУГАС  : зона следующей тасовки (улетающая полоса)
                       выбирается сразу при запуске её таймера; если до
                       тасовки меньше SHUFFLE_FUGAS_GUARD (4) секунд, бомбы
                       на эту зону не садятся. Защита не короче фитиля
                       (+0.5 с), поэтому к моменту тасовки на улетающей
                       полосе бомбы гарантированно нет. Бомбы вне зоны
                       тасовка НЕ сбивает —
                       они едут вместе с полем; во время анимации таймеры
                       фугаса заморожены и новая бомба не появляется.
    ТУМАН + ОРБИТА   : карта едет и крутится, туман приклеен к клеткам;
                       камера чуть-чуть следует за картой (FOG_FOLLOW),
                       отдалять нельзя, двигать Shift+ЛКМ — можно.
    ТУМАН + ТАСОВКА  : клочки тумана летят вместе с полосами поля.
    ТУМАН + ФУГАС    : временные бомбы и взрывы рисуются поверх тумана.
    Приоритет при конфликтах: Тасовка > Фугас > Орбита.

Запуск раунда: build_modules(game, keys) строит список модулей
в порядке кадра; игра вызывает их методы и рассылает события.
"""
import math
import random

import settings as st


class Module:
    """Базовый модуль испытания: три обязательные точки входа."""

    key = ""

    def __init__(self, game):
        self.g = game            # общий контекст раунда (поле, фазы, события)

    # --- обязательные точки входа (переопределяются по надобности) ---

    def on_first_cell_opened(self, coord):
        """OnFirstCellOpened(): один раз после открытия первой ячейки."""

    def on_update(self, dt):
        """OnUpdate(deltaTime): каждый кадр, в порядке списка модулей."""

    def on_cell_changed(self, coord, kind):
        """OnCellChanged(cell): открытие/флажок/взрыв одной клетки."""

    def on_board_changed(self, reason):
        """OnBoardChanged(): тасовка, взрыв фугаса и другие сдвиги поля."""

    # --- имена из ТЗ как псевдонимы (те же точки входа) ---

    OnFirstCellOpened = on_first_cell_opened
    OnUpdate = on_update
    OnCellChanged = on_cell_changed
    OnBoardChanged = on_board_changed

    def __repr__(self):
        return "<{}>".format(self.key)


class OrbitModule(Module):
    """«ОРБИТА»: карта (поле целиком) едет по восьмёрке и крутится.

    Просто визуал + управление картой: зум и перетаскивание живут
    в трансформации карты (game.orbit_zoom / orbit_pan) и не зависят
    от других модулей. Крутится КАРТА, клетки приклеены к ней.
    """

    key = "orbit"

    def on_update(self, dt):
        g = self.g
        if g.state != "game" or g.ended or g.exploding:
            return
        g.orbit_u = (g.orbit_u + dt * st.ORBIT_MOVE_SPEED) % math.tau
        g.orbit_deg = (g.orbit_deg + dt * st.ORBIT_ROT_SPEED) % 360.0
        g._orbit_apply()

    def on_board_changed(self, reason):
        # Тасовка меняет содержимое поля, но не траекторию: параметр
        # восьмёрки и угол хранятся здесь и никем не сбрасываются,
        # поэтому поле после тасовки не «прыгает».
        pass


class ShuffleModule(Module):
    """«ТАСОВКА»: каждые SHUFFLE_INTERVAL секунд полоса поля улетает,
    на её место прилетает обновлённая. Работает в локальных координатах
    поля, поэтому совместима с «Орбитой» (та крутит карту целиком)."""

    key = "shuffle"

    def on_first_cell_opened(self, coord):
        g = self.g
        g.shuffle_phase = "waiting"
        g.shuffle_t = st.SHUFFLE_INTERVAL
        g._plan_shuffle()           # где будет тасовка — известно сразу

    def on_update(self, dt):
        g = self.g
        if g.state != "game":
            return
        if g.shuffle_phase == "anim":
            g._update_shuffle_anim(dt)   # анимация доигрывает даже после конца
            return
        if g.ended or g.exploding:
            return
        if g.shuffle_phase == "waiting":
            # таймер не ждёт новых открытий — тасуем по истечении периода
            g.shuffle_t -= dt
            if g.shuffle_t <= 0:
                g._shuffle_start()       # внутри — событие on_board_changed


class FugasModule(Module):
    """«ФУГАС»: временные бомбы на открытых клетках — успей кликнуть.

    Приоритет ниже Тасовки: во время анимации тасовки таймеры фугаса
    заморожены. Бомбы вне зоны тасовки переезжают вместе с полем, бомба
    внутри зоны (страховка — обычно её там нет) снимается без взрыва.
    """

    key = "fugas"

    def __init__(self, game):
        super().__init__(game)
        self.started = False     # механизм запускается после первой ячейки

    def on_first_cell_opened(self, coord):
        g = self.g
        self.started = True
        # поле «на взводе» FUGAS_PRIME секунд, дальше цикл розыгрышей
        g.fugas_phase = "priming"
        g.fugas_t = st.FUGAS_PRIME

    def on_update(self, dt):
        g = self.g
        if (g.state != "game" or g.ended or g.exploding):
            return
        # визуальные таймеры (мигание, тряска появления) идут всегда
        g.fugas_blink += dt
        for bomb in g.fugas_bombs:
            bomb["age"] += dt
        if g.shuffle_phase == "anim":
            # Тасовка тяжелее: таймеры фугаса заморожены, новую бомбу
            # посреди анимации не ставим.
            return
        if g.fugas_phase in ("priming", "cooldown"):
            g.fugas_t -= dt
            if g.fugas_t <= 0:
                g._fugas_cycle()          # шаг 1: выбор секунды
        elif g.fugas_phase == "waiting":
            g.fugas_t -= dt
            if g.fugas_t <= 0:
                if random.random() < st.FUGAS_CHANCE:
                    g._fugas_spawn()      # шаг 4: появилась бомба
                else:
                    g._fugas_cycle()      # 50%: ничего, шаг 1 заново
        elif g.fugas_phase == "armed":
            g.fugas_t -= dt
            if g.fugas_t <= 0:
                g.fugas_t = 0.0
                g._fugas_explode()        # не успел — взрыв

    def on_board_changed(self, reason):
        g = self.g
        if not self.started:
            return
        if reason == "shuffle_start":
            # Бомбы вне улетающей зоны не сбиваются — едут вместе с полем
            # (их клетки сдвигаются на d). Бомба в самой зоне — страховка:
            # снимается без взрыва (обычно её там нет: последние секунды
            # перед тасовкой бомбы на зону не садятся).
            last = g.shuffle_last or {}
            strip = last.get("strip", frozenset())
            d = last.get("d", 0)
            vertical = last.get("vertical", True)
            kept, removed = [], 0
            for bomb in g.fugas_bombs:
                if bomb["coord"] in strip:
                    removed += 1
                    continue
                x, y = bomb["coord"]
                bomb["coord"] = (x + d, y) if vertical else (x, y + d)
                kept.append(bomb)
            g.fugas_bombs = kept
            if removed:
                g._toast("Фугас снят: карта тасуется")
            if g.fugas_phase == "armed" and not kept:
                g.fugas_phase = "idle"    # цикл продолжится после тасовки
        elif reason == "shuffle_end":
            # Таймеры фугаса продолжают с того же места; если бомбы
            # розыгрыша сняла тасовка — цикл заново.
            if g.fugas_phase == "idle":
                g._fugas_cycle()


class BlitzModule(Module):
    """«БЛИЦ»: таймер партии — успей открыть всё поле до нуля."""

    key = "blitz"

    def on_update(self, dt):
        g = self.g
        if g.state != "game" or g.ended or g.exploding:
            return
        g.blitz_left -= dt
        if g.blitz_left <= 0:
            g.blitz_left = 0.0
            g._time_up()

    def on_first_cell_opened(self, coord):
        pass                      # отсчёт БЛИЦа идёт с самого старта раунда


class NoFlagsModule(Module):
    """«ДИВЕРСАНТ»: флажки отключены. Игра блокирует их на вводе,
    этот модуль — страховка через событие on_cell_changed."""

    key = "noflags"

    def on_cell_changed(self, coord, kind):
        if kind != "flag":
            return
        x, y = coord
        c = self.g.board.cell(x, y)
        if c.flagged and not c.revealed:
            c.flagged = False
            self.g.board.flags_used -= 1
            self.g._sync_cells()


class FogModule(Module):
    """«ТУМАН»: всё поле под сплошным туманом; ПРОБЕЛ — лампа в курсоре
    светит жёлтым и разгоняет туман вокруг себя, вдали — темнота. Камера
    чуть приближена (отдалять нельзя), карту можно двигать. Идёт
    последним: туман берёт уже готовые позиции карты и клеток этого
    кадра (после Орбиты и Тасовки)."""

    key = "fog"

    def on_update(self, dt):
        self.g._fog_update(dt)

    def on_cell_changed(self, coord, kind):
        pass                      # туман не зависит от содержимого клеток

    def on_board_changed(self, reason):
        pass                      # туман приклеен к карте — едет с ней


# Порядок кадра: Орбита -> Тасовка -> Фугас -> Блиц -> Диверсант -> Туман.
# (отрисовка + камера выполняются после всех модулей, в коде окна)
MODULE_ORDER = ("orbit", "shuffle", "fugas", "blitz", "noflags", "fog")

MODULE_CLASSES = {
    "orbit": OrbitModule,
    "shuffle": ShuffleModule,
    "fugas": FugasModule,
    "blitz": BlitzModule,
    "noflags": NoFlagsModule,
    "fog": FogModule,
}


def build_modules(game, challenges):
    """Список модулей для набора испытаний, в порядке выполнения кадра."""
    chosen = set(challenges or ())
    return [MODULE_CLASSES[k](game) for k in MODULE_ORDER if k in chosen]


def combined_mult(challenges, diff_key):
    """Итоговый множитель награды: произведение множителей выбранных
    испытаний × множитель сложности (settings.DIFF_CHAL_MULT: «Новичок» ×0.5,
    «Любитель» ×1, «Эксперт» ×1.5). Без испытаний — 1.0 (обычная игра)."""
    keys = list(challenges or ())
    if not keys:
        return 1.0
    m = 1.0
    for k in keys:
        m *= st.challenge_mult(k, diff_key)
    return m * st.diff_chal_mult(diff_key)
