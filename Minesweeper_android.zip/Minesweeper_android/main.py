# -*- coding: utf-8 -*-
"""Minesweeper — точка входа для Android (Kivy). На ПК тоже запускается:
    pip install kivy pillow plyer && python main.py
(исходная ПК-версия на настоящем arcade остаётся в своей папке.)
"""
import os
import sys

os.environ.setdefault("KIVY_NO_ARGS", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from kivy.config import Config  # noqa: E402

Config.set("kivy", "exit_on_escape", "0")
Config.set("input", "mouse", "mouse,multitouch_on_demand")
Config.set("graphics", "maxfps", "60")
from kivy.utils import platform  # noqa: E402

if platform not in ("android", "ios"):
    Config.set("graphics", "width", "1280")
    Config.set("graphics", "height", "720")

import arcade  # noqa: E402  (локальный arcade поверх Kivy)
from mobile import MobileGame  # noqa: E402

if __name__ == "__main__":
    MobileGame()
    arcade.run()
