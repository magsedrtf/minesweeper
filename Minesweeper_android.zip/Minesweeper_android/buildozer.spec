[app]
title = Minesweeper
package.name = minesweeper
package.domain = org.minesweeper
source.dir = .
source.include_exts = py,png,jpg,wav,ttf,json,txt
source.exclude_dirs = tests,tools,bin,.buildozer,__pycache__
# сейв с ПК не кладём в APK: иначе при каждом обновлении он затрёт прогресс на телефоне
source.exclude_patterns = minesweeper_save.json,saper2d_save.json,*.bat,run.sh
version = 1.0
requirements = python3,kivy==2.3.0,pillow,plyer
orientation = landscape
fullscreen = 1
android.permissions = VIBRATE
android.api = 34
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
# icon.filename = %(source.dir)s/sprites/icon.png

[buildozer]
log_level = 2
warn_on_root = 1
