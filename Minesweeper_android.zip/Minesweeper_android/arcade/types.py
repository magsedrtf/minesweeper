# -*- coding: utf-8 -*-
"""arcade.types — LRBT / Rect."""
from collections import namedtuple


class Rect(namedtuple("Rect", "left right bottom top width height x y")):
    __slots__ = ()

    @property
    def lbwh(self):
        return (self.left, self.bottom, self.width, self.height)

    @property
    def center(self):
        return (self.x, self.y)


def LRBT(left, right, bottom, top):
    w, h = right - left, top - bottom
    return Rect(left, right, bottom, top, w, h, left + w / 2.0, bottom + h / 2.0)


def LBWH(left, bottom, width, height):
    return LRBT(left, left + width, bottom, bottom + height)


def XYWH(x, y, width, height):
    return LRBT(x - width / 2.0, x + width / 2.0, y - height / 2.0, y + height / 2.0)


Color = tuple
RGBA255 = tuple
