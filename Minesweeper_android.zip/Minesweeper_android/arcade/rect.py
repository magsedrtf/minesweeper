# -*- coding: utf-8 -*-
"""arcade.rect — XYWH (центр + размер), LRBT, LBWH."""
from .types import Rect, LRBT, LBWH, XYWH  # noqa: F401
