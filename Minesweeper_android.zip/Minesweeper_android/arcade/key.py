# -*- coding: utf-8 -*-
"""arcade.key — коды клавиш как в pyglet."""
MOD_SHIFT = 1
MOD_CTRL = 2
MOD_ALT = 4
MOD_CAPSLOCK = 8
MOD_ACCEL = 2

BACKSPACE = 65288
TAB = 65289
ENTER = RETURN = 65293
ESCAPE = 65307
SPACE = 32
LEFT = 65361
UP = 65362
RIGHT = 65363
DOWN = 65364
LSHIFT = 65505
RSHIFT = 65506
LCTRL = 65507
RCTRL = 65508
LALT = 65513
RALT = 65514
EQUAL = 61
PLUS = 43
MINUS = 45
NUM_ADD = 65451
NUM_SUBTRACT = 65453
F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12 = range(65470, 65482)

for _c in range(26):
    globals()[chr(65 + _c)] = 97 + _c          # A..Z -> 'a'..'z'
for _d in range(10):
    globals()["KEY_%d" % _d] = 48 + _d
del _c, _d
