# -*- coding: utf-8 -*-
"""Мини-arcade поверх Kivy (для Android).

Реализует ровно ту часть API arcade 3.x, которой пользуется игра:
Window, Sprite, SpriteList, Texture, Text, Camera2D, draw_*,
load_sound/play_sound/stop_sound, key.*, rect.XYWH, types.LRBT.
Файлы игры (game.py, ui.py, sprites.py, fieldfx.py, sounds.py, ...)
импортируют этот модуль как обычный `arcade` и остаются без изменений.
"""
import math
import os
import weakref

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window as _KW
from kivy.graphics import (Color as _KColor, Mesh as _KMesh, Line as _KLine,
                           Rectangle as _KRect, Ellipse as _KEllipse,
                           PushMatrix as _KPush, PopMatrix as _KPop,
                           Translate as _KTranslate, Scale as _KScale,
                           InstructionGroup as _KGroup)
from kivy.graphics.scissor_instructions import ScissorPush, ScissorPop
from kivy.graphics.texture import Texture as _KTexture
from kivy.uix.widget import Widget as _KWidget

from . import key            # noqa: F401  (arcade.key.*)
from . import types          # noqa: F401  (arcade.types.LRBT)
from . import rect           # noqa: F401  (arcade.rect.XYWH)
from .types import LRBT, Rect  # noqa: F401

VERSION = "3.3.3-kivy"
MOUSE_BUTTON_LEFT = 1
MOUSE_BUTTON_MIDDLE = 2
MOUSE_BUTTON_RIGHT = 4

_window = None


def get_window():
    return _window


def _rgba(color):
    c = tuple(color)
    if len(c) == 3:
        c = c + (255,)
    return (c[0] / 255.0, c[1] / 255.0, c[2] / 255.0, c[3] / 255.0)


# ---------------------------------------------------------------- текстуры

class Texture:
    """Картинка PIL -> текстура Kivy (создаётся лениво, при первом показе;
    после потери GL-контекста на Android перезаливается сама)."""

    def __init__(self, image, hash=None, **kw):
        from PIL import Image
        path = None
        if isinstance(image, str):
            path = image
            image = Image.open(image)
            image.load()
        if image.mode != "RGBA":
            image = image.convert("RGBA")
        self.image = image
        self.width, self.height = image.size
        self.size = image.size
        self.hash = hash or path
        self.file_path = path
        self._k = None

    @classmethod
    def create_empty(cls, name, size):
        from PIL import Image
        return cls(Image.new("RGBA", tuple(size), (0, 0, 0, 0)), hash=name)

    def _upload(self, tex):
        tex.blit_buffer(self.image.tobytes(), colorfmt="rgba", bufferfmt="ubyte")

    def kivy(self):
        if self._k is None:
            t = _KTexture.create(size=self.image.size, colorfmt="rgba")
            t.mag_filter = "linear"
            t.min_filter = "linear"
            self._upload(t)
            t.flip_vertical()          # PIL: сверху вниз, GL: снизу вверх
            t.add_reload_observer(self._upload)
            self._k = t
        return self._k


_TEX_CACHE = {}


def load_texture(path, **kw):
    t = _TEX_CACHE.get(path)
    if t is None:
        t = _TEX_CACHE[path] = Texture(path)
    return t


# ---------------------------------------------------------------- рамка кадра

class _Frame:
    """Состояние текущего кадра: куда складываем инструкции."""
    n = 0              # номер кадра
    canvas = None
    scale = 1.0        # масштаб текущей камеры (для чёткого текста)
    pushed = False
    scissor = False


def _add(instr):
    if _Frame.canvas is not None:
        _Frame.canvas.add(instr)


class Vec2(tuple):
    def __new__(cls, x, y):
        return tuple.__new__(cls, (x, y))

    x = property(lambda s: s[0])
    y = property(lambda s: s[1])

    def __mul__(self, k):
        if isinstance(k, (int, float)):
            return Vec2(self[0] * k, self[1] * k)
        return Vec2(self[0] * k[0], self[1] * k[1])
    __rmul__ = __mul__

    def __truediv__(self, k):
        return Vec2(self[0] / k, self[1] / k)

    def __add__(self, o):
        return Vec2(self[0] + o[0], self[1] + o[1])

    def __sub__(self, o):
        return Vec2(self[0] - o[0], self[1] - o[1])


class _Scale(Vec2):
    """scale спрайта: как Vec2 в arcade 3, но сравнивается/умножается
    как число, если масштаб одинаковый по осям."""

    def __float__(self):
        return float(self[0])

    def __eq__(self, o):
        if isinstance(o, (int, float)):
            return self[0] == o and self[1] == o
        return tuple.__eq__(self, o)

    def __hash__(self):
        return tuple.__hash__(self)

    def __sub__(self, o):
        if isinstance(o, (int, float)):
            return self[0] - o
        return Vec2.__sub__(self, o)

    def __rsub__(self, o):
        return o - self[0]

    def __lt__(self, o):
        return self[0] < (o if isinstance(o, (int, float)) else o[0])

    def __gt__(self, o):
        return self[0] > (o if isinstance(o, (int, float)) else o[0])

    def __abs__(self):
        return abs(self[0])

    def __round__(self, n=0):
        return round(self[0], n)


# ---------------------------------------------------------------- спрайты

class Sprite:
    def __init__(self, path_or_texture=None, scale=1.0, center_x=0.0,
                 center_y=0.0, angle=0.0, **kw):
        if isinstance(path_or_texture, str):
            path_or_texture = load_texture(path_or_texture)
        self._texture = path_or_texture
        s = float(scale) if isinstance(scale, (int, float)) else None
        self._sx, self._sy = (s, s) if s is not None else (float(scale[0]), float(scale[1]))
        self._x, self._y = float(center_x), float(center_y)
        self._angle = float(angle)
        self._color = (255, 255, 255, 255)
        self.visible = True
        self.properties = {}
        self.sprite_lists = []
        self._dirty = True
        self._frame = -1
        self._g = None
        self._kc = None
        self._km = None
        self._ktex = None

    # --- свойства
    def _touch(self):
        self._dirty = True

    @property
    def texture(self):
        return self._texture

    @texture.setter
    def texture(self, t):
        if t is not self._texture:
            self._texture = t
            self._dirty = True

    @property
    def position(self):
        return Vec2(self._x, self._y)

    @position.setter
    def position(self, p):
        x, y = float(p[0]), float(p[1])
        if x != self._x or y != self._y:
            self._x, self._y = x, y
            self._dirty = True

    @property
    def center_x(self):
        return self._x

    @center_x.setter
    def center_x(self, v):
        self.position = (v, self._y)

    @property
    def center_y(self):
        return self._y

    @center_y.setter
    def center_y(self, v):
        self.position = (self._x, v)

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, a):
        a = float(a)
        if a != self._angle:
            self._angle = a
            self._dirty = True

    @property
    def scale(self):
        return _Scale(self._sx, self._sy)

    @scale.setter
    def scale(self, s):
        if isinstance(s, (int, float)):
            sx = sy = float(s)
        else:
            sx, sy = float(s[0]), float(s[1])
        if sx != self._sx or sy != self._sy:
            self._sx, self._sy = sx, sy
            self._dirty = True

    @property
    def scale_x(self):
        return self._sx

    @scale_x.setter
    def scale_x(self, v):
        self.scale = (v, self._sy)

    @property
    def scale_y(self):
        return self._sy

    @scale_y.setter
    def scale_y(self, v):
        self.scale = (self._sx, v)

    @property
    def width(self):
        return (self._texture.width if self._texture else 0) * abs(self._sx)

    @width.setter
    def width(self, w):
        tw = self._texture.width if self._texture else 1
        self.scale_x = w / float(tw or 1)

    @property
    def height(self):
        return (self._texture.height if self._texture else 0) * abs(self._sy)

    @height.setter
    def height(self, h):
        th = self._texture.height if self._texture else 1
        self.scale_y = h / float(th or 1)

    @property
    def size(self):
        return Vec2(self.width, self.height)

    left = property(lambda s: s._x - s.width / 2)
    right = property(lambda s: s._x + s.width / 2)
    bottom = property(lambda s: s._y - s.height / 2)
    top = property(lambda s: s._y + s.height / 2)

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, c):
        c = tuple(int(v) for v in c)
        if len(c) == 3:
            c = c + (self._color[3],)
        if c != self._color:
            self._color = c
            if self._kc is not None:
                self._kc.rgba = _rgba(c)

    @property
    def alpha(self):
        return self._color[3]

    @alpha.setter
    def alpha(self, a):
        self.color = self._color[:3] + (int(max(0, min(255, a))),)

    @property
    def rgb(self):
        return self._color[:3]

    @rgb.setter
    def rgb(self, c):
        self.color = tuple(c[:3]) + (self._color[3],)

    def remove_from_sprite_lists(self):
        for sl in list(self.sprite_lists):
            if self in sl:
                list.remove(sl, self)
        self.sprite_lists = []

    kill = remove_from_sprite_lists

    def update(self, *a, **kw):
        pass

    def draw(self, **kw):
        draw_sprite(self)

    # --- геометрия
    def _verts(self):
        t = self._texture
        kt = t.kivy()
        hw = t.width * self._sx / 2.0
        hh = t.height * self._sy / 2.0
        x, y = self._x, self._y
        uv = kt.tex_coords
        if self._angle:
            r = math.radians(self._angle)          # arcade: по часовой
            c, s = math.cos(r), math.sin(r)
            pts = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
            v = []
            for i, (px, py) in enumerate(pts):
                v += [x + px * c + py * s, y - px * s + py * c,
                      uv[i * 2], uv[i * 2 + 1]]
        else:
            v = [x - hw, y - hh, uv[0], uv[1],
                 x + hw, y - hh, uv[2], uv[3],
                 x + hw, y + hh, uv[4], uv[5],
                 x - hw, y + hh, uv[6], uv[7]]
        return v, kt

    def _emit(self):
        if not self.visible or self._texture is None or self._color[3] <= 0:
            return
        if self._frame == _Frame.n:
            # второй раз в том же кадре (другое место/цвет) — отдельная копия
            v, kt = self._verts()
            _add(_KColor(*_rgba(self._color)))
            _add(_KMesh(vertices=v, indices=[0, 1, 2, 3],
                        mode="triangle_fan", texture=kt))
            return
        self._frame = _Frame.n
        if self._g is None:
            v, kt = self._verts()
            self._g = _KGroup()
            self._kc = _KColor(*_rgba(self._color))
            self._km = _KMesh(vertices=v, indices=[0, 1, 2, 3],
                              mode="triangle_fan", texture=kt)
            self._g.add(self._kc)
            self._g.add(self._km)
            self._ktex = kt
            self._dirty = False
        elif self._dirty:
            v, kt = self._verts()
            self._km.vertices = v
            if kt is not self._ktex:
                self._km.texture = kt
                self._ktex = kt
            self._dirty = False
        _add(self._g)


BasicSprite = Sprite
TextureAnimationSprite = Sprite


class SpriteList(list):
    def __init__(self, *a, **kw):
        list.__init__(self)
        self.visible = True
        self.alpha = 255

    def append(self, sp):
        list.append(self, sp)
        sp.sprite_lists.append(self)

    def extend(self, sps):
        for sp in sps:
            self.append(sp)

    def insert(self, i, sp):
        list.insert(self, i, sp)
        sp.sprite_lists.append(self)

    def remove(self, sp):
        list.remove(self, sp)
        try:
            sp.sprite_lists.remove(self)
        except ValueError:
            pass

    def pop(self, i=-1):
        sp = list.pop(self, i)
        try:
            sp.sprite_lists.remove(self)
        except ValueError:
            pass
        return sp

    def clear(self, *a, **kw):
        for sp in self:
            try:
                sp.sprite_lists.remove(self)
            except ValueError:
                pass
        del self[:]

    def draw(self, **kw):
        if not self.visible:
            return
        for sp in self:
            sp._emit()

    def update(self, *a, **kw):
        pass


def draw_sprite(sprite, **kw):
    sprite._emit()


# ---------------------------------------------------------------- примитивы

def draw_lrbt_rectangle_filled(left, right, bottom, top, color):
    _add(_KColor(*_rgba(color)))
    _add(_KRect(pos=(left, bottom), size=(right - left, top - bottom)))


def draw_lrbt_rectangle_outline(left, right, bottom, top, color, border_width=1):
    _add(_KColor(*_rgba(color)))
    _add(_KLine(rectangle=(left, bottom, right - left, top - bottom),
                width=max(1.0, border_width / 2.0)))


def _rect_lbwh(r):
    return r.left, r.bottom, r.width, r.height


def draw_rect_filled(rect, color, tilt_angle=0, **kw):
    l, b, w, h = _rect_lbwh(rect)
    if tilt_angle:
        cx, cy = l + w / 2.0, b + h / 2.0
        r = math.radians(tilt_angle)
        c, s = math.cos(r), math.sin(r)
        pts = []
        for px, py in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)):
            pts.append((cx + px * c + py * s, cy - px * s + py * c))
        draw_polygon_filled(pts, color)
        return
    _add(_KColor(*_rgba(color)))
    _add(_KRect(pos=(l, b), size=(w, h)))


def draw_rect_outline(rect, color, border_width=1, tilt_angle=0, **kw):
    l, b, w, h = _rect_lbwh(rect)
    _add(_KColor(*_rgba(color)))
    _add(_KLine(rectangle=(l, b, w, h), width=max(1.0, border_width / 2.0)))


def draw_circle_filled(cx, cy, radius, color, tilt_angle=0, num_segments=-1):
    _add(_KColor(*_rgba(color)))
    _add(_KEllipse(pos=(cx - radius, cy - radius), size=(radius * 2, radius * 2)))


def draw_circle_outline(cx, cy, radius, color, border_width=1, tilt_angle=0,
                        num_segments=-1):
    _add(_KColor(*_rgba(color)))
    _add(_KLine(circle=(cx, cy, radius), width=max(1.0, border_width / 2.0)))


def draw_polygon_filled(point_list, color):
    pts = [(float(p[0]), float(p[1])) for p in point_list]
    if len(pts) < 3:
        return
    v = []
    for x, y in pts:
        v += [x, y, 0.0, 0.0]
    _add(_KColor(*_rgba(color)))
    _add(_KMesh(vertices=v, indices=list(range(len(pts))), mode="triangle_fan"))


def draw_polygon_outline(point_list, color, line_width=1):
    pts = []
    for p in point_list:
        pts += [float(p[0]), float(p[1])]
    _add(_KColor(*_rgba(color)))
    _add(_KLine(points=pts, close=True, width=max(1.0, line_width / 2.0)))


def draw_line(x1, y1, x2, y2, color, line_width=1):
    _add(_KColor(*_rgba(color)))
    _add(_KLine(points=[x1, y1, x2, y2], width=max(1.0, line_width / 2.0)))


# ---------------------------------------------------------------- текст

_FONTS = {}          # семейство -> {"regular": путь, "bold": путь}


def load_font(path):
    from kivy.core.text import LabelBase
    try:
        from PIL import ImageFont
        fam, style = ImageFont.truetype(path, 12).getname()
    except Exception:
        fam, style = os.path.splitext(os.path.basename(path))[0], ""
    d = _FONTS.setdefault(fam, {})
    d["bold" if "bold" in (style or "").lower() else "regular"] = path
    reg = d.get("regular") or d.get("bold")
    LabelBase.register(fam, fn_regular=reg, fn_bold=d.get("bold") or reg)


_TEXT_CACHE = {}
_METRICS = {}


def _font_path(name, bold):
    d = _FONTS.get(name) or {}
    return d.get("bold" if bold else "regular") or d.get("regular") or d.get("bold")


def _descent(name, bold, px):
    k = (name, bold, px)
    if k not in _METRICS:
        try:
            from PIL import ImageFont
            f = ImageFont.truetype(_font_path(name, bold), px)
            _METRICS[k] = f.getmetrics()          # (ascent, descent)
        except Exception:
            _METRICS[k] = (px * 0.8, px * 0.2)
    return _METRICS[k]


def _text_texture(text, name, px, bold):
    k = (text, name, px, bold)
    t = _TEXT_CACHE.get(k)
    if t is None:
        from kivy.core.text import Label as CoreLabel
        kw = dict(text=text, font_size=px, bold=bold, color=(1, 1, 1, 1))
        if name in _FONTS:
            kw["font_name"] = name
        lab = CoreLabel(**kw)
        lab.refresh()
        t = lab.texture
        if len(_TEXT_CACHE) > 1500:
            _TEXT_CACHE.clear()
        _TEXT_CACHE[k] = t
    return t


class Text:
    def __init__(self, text="", x=0.0, y=0.0, color=(255, 255, 255, 255),
                 font_size=12, width=None, align="left",
                 font_name=("calibri", "arial"), bold=False, italic=False,
                 anchor_x="left", anchor_y="baseline", multiline=False,
                 rotation=0, **kw):
        self.value = str(text)
        self.x, self.y = float(x), float(y)
        self.color = color
        self.font_size = font_size
        self.width = width
        self.align = align
        if isinstance(font_name, (tuple, list)):
            font_name = next((f for f in font_name if f in _FONTS), font_name[0])
        self.font_name = font_name
        self.bold = bool(bold)
        self.anchor_x = anchor_x
        self.anchor_y = anchor_y
        self.rotation = rotation
        self.visible = True

    text = property(lambda s: s.value, lambda s, v: setattr(s, "value", str(v)))

    @property
    def position(self):
        return Vec2(self.x, self.y)

    @position.setter
    def position(self, p):
        self.x, self.y = float(p[0]), float(p[1])

    def _px(self):
        return max(1, int(round(self.font_size * 96.0 / 72.0)))   # pt -> px

    def _layout(self):
        px = self._px()
        k = max(0.25, _Frame.scale)
        rpx = max(1, int(round(px * k)))          # рисуем в реальном размере
        tex = _text_texture(self.value, self.font_name, rpx, self.bold)
        w, h = tex.width / k, tex.height / k
        return tex, w, h, px

    @property
    def content_width(self):
        return self._layout()[1]

    @property
    def content_height(self):
        return self._layout()[2]

    def draw(self):
        if not self.visible or not self.value:
            return
        col = tuple(self.color)
        if len(col) == 4 and col[3] <= 0:
            return
        tex, w, h, px = self._layout()
        x, y = self.x, self.y
        if self.anchor_x == "center":
            x -= w / 2.0
        elif self.anchor_x == "right":
            x -= w
        if self.anchor_y == "center":
            y -= h / 2.0
        elif self.anchor_y == "top":
            y -= h
        elif self.anchor_y == "baseline":
            y -= _descent(self.font_name, self.bold, px)[1]
        _add(_KColor(*_rgba(col)))
        _add(_KRect(texture=tex, pos=(x, y), size=(w, h)))


def create_text_sprite(*a, **kw):
    raise NotImplementedError


# ---------------------------------------------------------------- камера

class Camera2D:
    def __init__(self, viewport=None, position=None, zoom=1.0, projection=None,
                 window=None, **kw):
        self.window = window or _window
        w, h = self.window.width, self.window.height
        self.viewport = viewport or LRBT(0, w, 0, h)
        self.projection = projection or LRBT(-w / 2.0, w / 2.0, -h / 2.0, h / 2.0)
        self.position = position or (w / 2.0, h / 2.0)
        self.zoom = zoom

    def _affine(self):
        vp, pr = self.viewport, self.projection
        kx = vp.width / float(pr.width or 1)
        ky = vp.height / float(pr.height or 1)
        z = self.zoom
        px, py = self.position[0], self.position[1]
        ax, ay = z * kx, z * ky
        bx = vp.left - (px * z + pr.left) * kx
        by = vp.bottom - (py * z + pr.bottom) * ky
        return ax, ay, bx, by

    def use(self):
        ax, ay, bx, by = self._affine()
        if _Frame.pushed:
            _add(_KPop())
        _add(_KPush())
        _add(_KTranslate(bx, by))
        _add(_KScale(ax, ay, 1.0))
        _Frame.pushed = True
        _Frame.scale = ax

    def activate(self):
        self.use()
        return self

    def project(self, xy):
        ax, ay, bx, by = self._affine()
        return Vec2(xy[0] * ax + bx, xy[1] * ay + by)

    def unproject(self, xy):
        ax, ay, bx, by = self._affine()
        return Vec2((xy[0] - bx) / ax, (xy[1] - by) / ay)

    def match_window(self, *a, **kw):
        w, h = self.window.width, self.window.height
        self.viewport = LRBT(0, w, 0, h)


# ---------------------------------------------------------------- звук

class Sound:
    POOL = 4

    def __init__(self, path, streaming=False):
        self.file_name = path
        self._pool = []

    def _voice(self):
        from kivy.core.audio import SoundLoader
        for s in self._pool:
            if s.state != "play":
                return s
        if len(self._pool) < self.POOL:
            s = SoundLoader.load(self.file_name)
            if s is None:
                return None
            self._pool.append(s)
            return s
        s = self._pool.pop(0)       # все голоса заняты — перезапускаем старый
        self._pool.append(s)
        s.stop()
        return s

    def play(self, volume=1.0, pan=0.0, loop=False, speed=1.0):
        s = self._voice()
        if s is None:
            return None
        s.loop = bool(loop)
        s.volume = max(0.0, min(1.0, float(volume)))
        s.play()
        return _Player(s)


class _Player:
    def __init__(self, s):
        self._s = s

    @property
    def volume(self):
        return self._s.volume

    @volume.setter
    def volume(self, v):
        self._s.volume = max(0.0, min(1.0, float(v)))

    @property
    def playing(self):
        return self._s.state == "play"

    def pause(self):
        self._s.stop()

    def play(self):
        self._s.play()

    def delete(self):
        self._s.stop()


def load_sound(path, streaming=False):
    return Sound(path, streaming)


def play_sound(sound, volume=1.0, pan=0.0, loop=False, speed=1.0):
    if sound is None:
        return None
    return sound.play(volume, pan, loop, speed)


def stop_sound(player):
    if player is not None:
        player._s.loop = False
        player._s.stop()


# ---------------------------------------------------------------- окно

class _Ctx:
    def __init__(self):
        self._viewport = None

    @property
    def viewport(self):
        return self._viewport

    @viewport.setter
    def viewport(self, v):
        self._viewport = v            # Kivy сам рисует на всё окно

    @property
    def scissor(self):
        return None

    @scissor.setter
    def scissor(self, r):
        if _Frame.scissor:
            _add(ScissorPop())
            _Frame.scissor = False
        if r is not None:
            x, y, w, h = (int(v) for v in r)
            _add(ScissorPush(x=x, y=y, width=w, height=h))
            _Frame.scissor = True


_KIVY_KEYS = {
    27: key.ESCAPE, 32: key.SPACE, 292: key.F11, 304: key.LSHIFT,
    303: key.RSHIFT, 61: key.EQUAL, 45: key.MINUS, 270: key.NUM_ADD,
    269: key.NUM_SUBTRACT, 13: key.ENTER, 8: key.BACKSPACE,
}


class _Root(_KWidget):
    """Корневой виджет: холст для кадра + пересылка касаний в окно."""

    def __init__(self, win, **kw):
        super().__init__(**kw)
        self.win = win

    def on_touch_down(self, t):
        self.win._touch_down(t)
        return True

    def on_touch_move(self, t):
        self.win._touch_move(t)
        return True

    def on_touch_up(self, t):
        self.win._touch_up(t)
        return True


class Window:
    def __init__(self, width=1280, height=720, title="Arcade Window",
                 fullscreen=False, resizable=True, update_rate=1 / 60,
                 vsync=True, **kw):
        global _window
        _window = self
        self.ctx = _Ctx()
        self.root = _Root(self)
        self._title = title
        self._fullscreen = True
        self.background_color = (0, 0, 0, 255)
        self._last_mouse = (0.0, 0.0)
        _KW.bind(on_resize=self._k_resize, on_key_down=self._k_down,
                 on_key_up=self._k_up)

    # --- размеры
    width = property(lambda s: int(_KW.width))
    height = property(lambda s: int(_KW.height))

    def get_size(self):
        return self.width, self.height

    @property
    def fullscreen(self):
        return self._fullscreen

    def set_fullscreen(self, flag=True, *a, **kw):
        self._fullscreen = bool(flag)     # на телефоне — всегда полный экран

    def set_mouse_visible(self, v=True):
        pass

    def set_caption(self, s):
        self._title = s

    def close(self):
        app = App.get_running_app()
        if app is not None:
            app.stop()

    def clear(self, color=None, **kw):
        c = color if color is not None else self.background_color
        _KW.clearcolor = _rgba(c)

    # --- события (переопределяются игрой)
    def on_resize(self, width, height):
        pass

    def on_update(self, dt):
        pass

    def on_draw(self):
        pass

    def on_mouse_motion(self, x, y, dx, dy):
        pass

    def on_mouse_press(self, x, y, button, modifiers):
        pass

    def on_mouse_release(self, x, y, button, modifiers):
        pass

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        pass

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        pass

    def on_key_press(self, symbol, modifiers):
        pass

    def on_key_release(self, symbol, modifiers):
        pass

    # --- касания: по умолчанию — как мышь (переопределяет mobile.py)
    def _touch_down(self, t):
        if getattr(t, "button", "left") in ("scrollup", "scrolldown"):
            self.on_mouse_scroll(t.x, t.y, 0, 1 if t.button == "scrolldown" else -1)
            return
        b = MOUSE_BUTTON_RIGHT if getattr(t, "button", "left") == "right" else MOUSE_BUTTON_LEFT
        self.on_mouse_motion(t.x, t.y, 0, 0)
        self.on_mouse_press(t.x, t.y, b, 0)

    def _touch_move(self, t):
        self.on_mouse_motion(t.x, t.y, t.dx, t.dy)

    def _touch_up(self, t):
        b = MOUSE_BUTTON_RIGHT if getattr(t, "button", "left") == "right" else MOUSE_BUTTON_LEFT
        self.on_mouse_release(t.x, t.y, b, 0)

    # --- Kivy -> arcade
    def _k_resize(self, win, w, h):
        self.on_resize(int(w), int(h))

    @staticmethod
    def _mods(mods):
        m = 0
        if "shift" in mods:
            m |= key.MOD_SHIFT
        if "ctrl" in mods:
            m |= key.MOD_CTRL
        if "alt" in mods:
            m |= key.MOD_ALT
        return m

    def _map_key(self, k):
        if k in _KIVY_KEYS:
            return _KIVY_KEYS[k]
        if 97 <= k <= 122 or 48 <= k <= 57:
            return k
        return k

    def _k_down(self, win, k, scancode=None, codepoint=None, mods=()):
        self.on_key_press(self._map_key(k), self._mods(mods or ()))
        return k == 27            # «Назад» на Android не закрывает игру

    def _k_up(self, win, k, scancode=None, *a):
        self.on_key_release(self._map_key(k), 0)
        return k == 27

    # --- кадр
    def _tick(self, dt):
        dt = max(0.0, min(dt, 0.1))
        self.on_update(dt)
        _Frame.n += 1
        _Frame.canvas = self.root.canvas
        _Frame.pushed = False
        _Frame.scissor = False
        _Frame.scale = 1.0
        self.root.canvas.clear()
        self.on_draw()
        if _Frame.scissor:
            _add(ScissorPop())
            _Frame.scissor = False
        if _Frame.pushed:
            _add(_KPop())
            _Frame.pushed = False


class View:
    pass


class _ArcadeApp(App):
    def __init__(self, win, **kw):
        super().__init__(**kw)
        self.win = win
        self.title = win._title

    def build(self):
        return self.win.root

    def on_start(self):
        hook = getattr(self.win, "on_app_start", None)
        if hook:
            hook()
        Clock.schedule_interval(self.win._tick, 0)

    def on_pause(self):
        hook = getattr(self.win, "on_app_pause", None)
        if hook:
            hook()
        return True

    def on_resume(self):
        hook = getattr(self.win, "on_app_resume", None)
        if hook:
            hook()


def run(*a, **kw):
    if _window is None:
        raise RuntimeError("arcade.Window не создано")
    _ArcadeApp(_window).run()


def exit():
    if _window is not None:
        _window.close()


def get_window_size():
    return _window.width, _window.height
