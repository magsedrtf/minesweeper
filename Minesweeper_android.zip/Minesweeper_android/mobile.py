# -*- coding: utf-8 -*-
"""Сенсорное управление для Android. Логика игры (game.py и др.) не меняется:
касания превращаются в те же вызовы, что делает мышь/клавиатура на ПК.

  • тап            — ЛКМ (открыть клетку / нажать кнопку)
  • долгое нажатие — ПКМ (флажок), с вибрацией
  • два пальца     — двигать карту + щипок для зума (во всех режимах партии)
  • один палец     — тянуть карту (без тумана)
  • ТУМАН: палец, который сдвинулся, «несёт» лампу (как курсор на ПК);
    пока его держишь, другим пальцем тапаешь/ставишь флажки.
    Покачать лампу пальцем или потрясти телефон — зарядить лампу.
    Кнопка «ЛАМПА» = ПРОБЕЛ.
  • магазин/инвентарь — свайп листает (как колесо мыши)
  • во время взрывов тап — пропустить (как ПРОБЕЛ)
  • кнопка «Назад» = ESC, кнопка ♪ в меню = клавиша M
"""
import math
import time

import arcade
from arcade import key as K
from kivy.metrics import dp

import settings as st
from game import MinesweeperGame

LONG_PRESS = 0.38          # с — удержание для флажка
SHAKE_G = 19.0             # м/с² — порог рывка акселерометра
SHAKE_PEAKS = 3            # рывков за SHAKE_WINDOW — тряска
SHAKE_WINDOW = 1.0


class _Finger:
    __slots__ = ("uid", "x0", "y0", "x", "y", "t0", "role", "lamp0",
                 "can_flag", "acc")

    def __init__(self, t):
        self.uid = t.uid
        self.x0 = self.x = float(t.x)
        self.y0 = self.y = float(t.y)
        self.t0 = time.time()
        self.role = "pending"
        self.lamp0 = None
        self.can_flag = False
        self.acc = 0.0


class MobileGame(MinesweeperGame):
    def __init__(self, windowed=False):
        self._fingers = {}
        self._g_prev = None
        self._acc = None
        self._acc_peaks = []
        self._acc_last = 0.0
        self._buttons = []
        super().__init__(windowed=True)
        self._ui_cam = arcade.Camera2D()
        self._ui_txt = arcade.Text("", 0, 0, (255, 255, 255, 255), 12,
                                   font_name="DejaVu Sans", bold=True,
                                   anchor_x="center", anchor_y="center")

    # Зум/панорама карты двумя пальцами — в любой партии (на ПК — в «Орбите»
    # и «Тумане»). Без «Орбиты» карта при этом стоит на месте, как и раньше.
    def _map_mode(self):
        return True

    # ------------------------------------------------------------ helpers
    def _overlay_busy(self):
        return bool(getattr(self, "confirm_kind", None)) or bool(getattr(self, "overlay", None))

    def _zoomable(self):
        return self._orbit_on() and not self._overlay_busy()

    def _lamp_finger(self):
        for f in self._fingers.values():
            if f.role == "lamp":
                return f
        return None

    def _park_mouse(self):
        """Пальцев нет: «курсор» в центр (нейтральный параллакс). В тумане
        лампа остаётся там, где её оставили."""
        if self._fog_on():
            return
        self.mouse = (st.SCREEN_W / 2, st.SCREEN_H / 2)
        self.mouse_win = (self.width / 2.0, self.height / 2.0)

    def _vibrate(self, s=0.03):
        try:
            from plyer import vibrator
            vibrator.vibrate(s)
        except Exception:
            pass

    def _click(self, x, y, right=False):
        if (not right and self.state == "game" and self.exploding
                and not getattr(self, "confirm_kind", None)):
            self.on_key_press(K.SPACE, 0)          # пропустить взрывы
            return
        keep = self._fog_on()
        saved = (self.mouse, self.mouse_win)
        btn = arcade.MOUSE_BUTTON_RIGHT if right else arcade.MOUSE_BUTTON_LEFT
        self.on_mouse_press(x, y, btn, 0)
        self.on_mouse_release(x, y, btn, 0)
        if keep and self._fog_on():
            self.mouse, self.mouse_win = saved      # лампа не прыгает к пальцу

    # ------------------------------------------------------------ кнопки
    def _layout_buttons(self):
        b = []
        m = dp(14)
        W = self.width
        if self.state == "game" and self._fog_on() and not self.ended:
            r = dp(30)
            on = bool(getattr(self, "fog_lamp", False))
            b.append(("lamp", W - m - r, m + r, r, "ЛАМПА",
                      (255, 214, 90, 230) if on else (130, 130, 130, 210)))
        if self.state == "menu":
            r = dp(22)
            b.append(("music", W - m - r, m + r, r, "♪", (200, 200, 230, 220)))
        self._buttons = b
        return b

    def _button_at(self, x, y):
        for name, bx, by, r, _, _ in self._buttons:
            if math.hypot(x - bx, y - by) <= r * 1.25:
                return name
        return None

    def _press_button(self, name):
        k = K.SPACE if name == "lamp" else K.M
        self.on_key_press(k, 0)
        self.on_key_release(k, 0)

    def _draw_buttons(self):
        b = self._layout_buttons()
        if not b:
            return
        W, H = self.width, self.height
        cam = self._ui_cam
        cam.viewport = arcade.LRBT(0, W, 0, H)
        cam.projection = arcade.LRBT(0, W, 0, H)
        cam.position = (0, 0)
        cam.zoom = 1.0
        self.ctx.scissor = None
        cam.use()
        t = self._ui_txt
        for name, bx, by, r, label, col in b:
            arcade.draw_circle_filled(bx, by, r, (20, 20, 28, 170))
            arcade.draw_circle_outline(bx, by, r, col, 3)
            t.value = label
            t.color = col
            t.font_size = (r * 0.42 if len(label) > 2 else r * 0.9) * 72.0 / 96.0
            t.x, t.y = bx, by
            t.draw()

    # ------------------------------------------------------------ касания
    def _touch_down(self, t):
        if getattr(t, "button", "left") in ("scrollup", "scrolldown", "scrollleft", "scrollright"):
            return super()._touch_down(t)          # колесо мыши на ПК-тесте
        f = _Finger(t)
        name = self._button_at(f.x, f.y)
        if name:
            f.role = "done"
            self._fingers[f.uid] = f
            self._press_button(name)
            return
        if getattr(t, "button", "left") == "right":   # ПК-тест мышью
            f.role = "done"
            self._fingers[f.uid] = f
            self._click(f.x, f.y, right=True)
            return
        free = [g for g in self._fingers.values() if g.role in ("pending", "pan")]
        if free and self._zoomable() and not any(
                g.role == "pinch" for g in self._fingers.values()):
            free[0].role = "pinch"                 # второй палец — щипок
            f.role = "pinch"
            self._g_prev = None
        f.can_flag = (self.state == "game" and not self.ended and not self.exploding
                      and not self._overlay_busy())
        self._fingers[f.uid] = f
        if f.role == "pending" and not self._fog_on():
            self.on_mouse_motion(f.x, f.y, 0, 0)   # «наведение» под пальцем

    def _touch_move(self, t):
        f = self._fingers.get(t.uid)
        if f is None:
            return
        x, y = float(t.x), float(t.y)
        dx, dy = x - f.x, y - f.y
        f.x, f.y = x, y
        if f.role == "pinch":
            self._pinch_update()
            return
        if f.role == "pending" and math.hypot(x - f.x0, y - f.y0) > dp(10):
            if self._fog_on() and not self.ended and self._lamp_finger() is None:
                f.role = "lamp"
                f.lamp0 = tuple(self.mouse_win)
            elif self.state in ("shop", "inventory") and not self._overlay_busy():
                f.role = "scroll"
            elif self._zoomable():
                f.role = "pan"
            else:
                f.role = "drag"                    # как зажатая ЛКМ (ползунки и т.п.)
                self.on_mouse_motion(f.x0, f.y0, 0, 0)
                self.on_mouse_press(f.x0, f.y0, arcade.MOUSE_BUTTON_LEFT, 0)
        if f.role == "lamp":
            W, H = self.width, self.height
            nx = max(0.0, min(W - 1.0, f.lamp0[0] + x - f.x0))
            ny = max(0.0, min(H - 1.0, f.lamp0[1] + y - f.y0))
            ox, oy = self.mouse_win
            self.on_mouse_motion(nx, ny, nx - ox, ny - oy)
        elif f.role == "pan":
            if self._zoomable():
                w1 = self._win_to_world_px(x, y)
                w0 = self._win_to_world_px(x - dx, y - dy)
                self.orbit_pan = [self.orbit_pan[0] + w1[0] - w0[0],
                                  self.orbit_pan[1] + w1[1] - w0[1]]
                self._orbit_apply()
        elif f.role == "scroll":
            zoom = self._vp[2] or 1.0
            f.acc += dy / zoom
            pos = self._to_virtual(f.x0, f.y0)
            if self.state in st.SCROLL_SCREENS:
                if abs(f.acc) >= 1.0:
                    self._shop_wheel(pos, -f.acc / float(st.SCROLL_STEP))
                    f.acc = 0.0
            elif abs(f.acc) >= dp(60) / zoom:      # страницы: свайп листает
                self._shop_wheel(pos, -1 if f.acc > 0 else 1)
                f.acc = 0.0
        elif f.role == "drag":
            self.on_mouse_motion(x, y, dx, dy)

    def _pinch_update(self):
        fs = [g for g in self._fingers.values() if g.role == "pinch"]
        if len(fs) < 2 or not self._zoomable():
            return
        a, b = fs[0], fs[1]
        mid = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
        dist = math.hypot(a.x - b.x, a.y - b.y)
        if self._g_prev is not None:
            pm, pd = self._g_prev
            w1 = self._win_to_world_px(*mid)
            w0 = self._win_to_world_px(*pm)
            self.orbit_pan = [self.orbit_pan[0] + w1[0] - w0[0],
                              self.orbit_pan[1] + w1[1] - w0[1]]
            self._orbit_apply()
            if pd > 1.0 and dist > 1.0 and abs(dist / pd - 1.0) > 1e-4:
                self._orbit_zoom_at(mid[0], mid[1], dist / pd)
        self._g_prev = (mid, dist)

    def _touch_up(self, t):
        f = self._fingers.pop(t.uid, None)
        if f is None:
            return
        if f.role == "pending":
            self._click(f.x0, f.y0)
        elif f.role == "drag":
            self.on_mouse_release(f.x, f.y, arcade.MOUSE_BUTTON_LEFT, 0)
        elif f.role == "pinch":
            self._g_prev = None
            for g in self._fingers.values():
                if g.role == "pinch":
                    g.role = "pan"
        if not self._fingers:
            self._park_mouse()

    # ------------------------------------------------------------ акселерометр
    def on_app_start(self):
        try:
            from plyer import accelerometer
            accelerometer.enable()
            self._acc = accelerometer
        except Exception:
            self._acc = None

    def on_app_pause(self):
        try:
            if self._acc:
                self._acc.disable()
        except Exception:
            pass
        try:
            self.save.save()
        except Exception:
            pass

    def on_app_resume(self):
        try:
            if self._acc:
                self._acc.enable()
        except Exception:
            pass

    def _poll_accel(self):
        if not self._acc:
            return
        try:
            v = self._acc.acceleration
        except Exception:
            return
        if not v or v[0] is None:
            return
        mag = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        now = time.time()
        if mag > SHAKE_G and now - self._acc_last > 0.12:
            self._acc_peaks.append(now)
            self._acc_last = now
        self._acc_peaks = [p for p in self._acc_peaks if now - p < SHAKE_WINDOW]
        if len(self._acc_peaks) >= SHAKE_PEAKS:
            self._acc_peaks = []
            if (self._fog_on() and not self.ended and not self.exploding
                    and not getattr(self, "confirm_kind", None)):
                self._lamp_recharge()

    # ------------------------------------------------------------ кадр
    def on_update(self, dt):
        now = time.time()
        for f in list(self._fingers.values()):
            if (f.role == "pending" and f.can_flag and now - f.t0 >= LONG_PRESS
                    and self.state == "game"):
                f.role = "done"
                self._vibrate()
                self._click(f.x0, f.y0, right=True)
        self._poll_accel()
        super().on_update(dt)
        if not self._fingers and not self._fog_on():
            self._hover_on = False

    def on_draw(self):
        hide = not self._fingers and not self._fog_on()
        if hide:
            saved = self.mouse
            self.mouse = (-100000.0, -100000.0)    # без пальца — без «наведения»
        try:
            super().on_draw()
        finally:
            if hide:
                self.mouse = saved
        self._draw_buttons()
