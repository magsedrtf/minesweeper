# -*- coding: utf-8 -*-
"""Сохранение прогресса в JSON: монеты, купленные скины, рекорды.

Если рядом лежит старый файл saper2d_save.json (от pygame-версии),
прогресс автоматически переносится в minesweeper_save.json.
"""
import json
import os

from settings import BASE_COINS, SHOP_ITEMS
try:
    from settings import REMOVED_ITEMS
except ImportError:          # старые settings.py
    REMOVED_ITEMS = {}

SAVE_NAME = "minesweeper_save.json"
OLD_SAVE_NAME = "saper2d_save.json"


def known_skin_ids():
    """Все допустимые id скинов: из магазина + PNG из папки sprites/."""
    known = {it[0] for it in SHOP_ITEMS}
    here = os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(here, "sprites")
    if os.path.isdir(d):
        for fn in os.listdir(d):
            if fn.lower().endswith(".png"):
                known.add(fn[:-4])
    return known


class SaveData:
    def __init__(self):
        self.coins = BASE_COINS
        self.refunded = []        # убранные скины, за которые вернули монеты
        self.owned_flags = ["f_classic"]
        self.owned_bombs = ["b_classic"]
        self.owned_tiles = ["t_classic"]
        self.selected_flag = "f_classic"
        self.selected_bomb = "b_classic"
        self.selected_tile = "t_classic"
        self.best_times = [0.0, 0.0, 0.0]  # по сложностям, 0 = рекорда нет
        self.challenges_done = 0

    # --- покупки ---

    def owns(self, item_id):
        if item_id.startswith("f_"):
            return item_id in self.owned_flags
        if item_id.startswith("b_"):
            return item_id in self.owned_bombs
        return item_id in self.owned_tiles

    def add_owned(self, item_id, select=True):
        """Добавить скин в купленные; select=False — не надевать
        (покупка в магазине, надеть можно в инвентаре)."""
        if item_id.startswith("f_"):
            if item_id not in self.owned_flags:
                self.owned_flags.append(item_id)
            if select:
                self.selected_flag = item_id
        elif item_id.startswith("b_"):
            if item_id not in self.owned_bombs:
                self.owned_bombs.append(item_id)
            if select:
                self.selected_bomb = item_id
        else:
            if item_id not in self.owned_tiles:
                self.owned_tiles.append(item_id)
            if select:
                self.selected_tile = item_id

    def is_selected(self, item_id):
        return item_id in (self.selected_flag, self.selected_bomb, self.selected_tile)

    def record_time(self, diff_index, elapsed):
        """Возвращает True, если установлен новый рекорд."""
        best = self.best_times[diff_index]
        if best <= 0 or elapsed < best:
            self.best_times[diff_index] = elapsed
            return True
        return False

    # --- файл ---

    def _path(self):
        here = os.path.join(os.path.dirname(os.path.abspath(__file__)), SAVE_NAME)
        if os.access(os.path.dirname(here), os.W_OK):
            return here
        return os.path.join(os.path.expanduser("~"), SAVE_NAME)

    def save(self):
        data = {
            "coins": self.coins,
            "owned_flags": self.owned_flags,
            "owned_bombs": self.owned_bombs,
            "owned_tiles": self.owned_tiles,
            "selected_flag": self.selected_flag,
            "selected_bomb": self.selected_bomb,
            "selected_tile": self.selected_tile,
            "best_times": self.best_times,
            "challenges_done": self.challenges_done,
        }
        try:
            with open(self._path(), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    @classmethod
    def load(cls):
        s = cls()
        path = s._path()
        if not os.path.exists(path):
            # миграция со старой pygame-версии «Сапёр 2D»
            old = os.path.join(os.path.dirname(path), OLD_SAVE_NAME)
            if os.path.exists(old):
                path = old
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return s
        s.coins = int(data.get("coins", BASE_COINS))
        known = known_skin_ids()
        # скины, убранные из магазина (например, «Ледяной флаг» в патче 11):
        # если был куплен — монеты возвращаются; после сохранения его
        # в списке уже нет, так что возврат — ровно один раз
        for lst in ("owned_flags", "owned_bombs", "owned_tiles"):
            for i in data.get(lst, []) or []:
                if i in REMOVED_ITEMS and i not in known:
                    s.coins += int(REMOVED_ITEMS[i])
                    s.refunded.append(i)
        s.owned_flags = [i for i in data.get("owned_flags", ["f_classic"]) if i in known] or ["f_classic"]
        s.owned_bombs = [i for i in data.get("owned_bombs", ["b_classic"]) if i in known] or ["b_classic"]
        s.owned_tiles = [i for i in data.get("owned_tiles", ["t_classic"]) if i in known] or ["t_classic"]
        s.selected_flag = data.get("selected_flag", "f_classic")
        if s.selected_flag not in s.owned_flags:
            s.selected_flag = s.owned_flags[0]
        s.selected_bomb = data.get("selected_bomb", "b_classic")
        if s.selected_bomb not in s.owned_bombs:
            s.selected_bomb = s.owned_bombs[0]
        s.selected_tile = data.get("selected_tile", "t_classic")
        if s.selected_tile not in s.owned_tiles:
            s.selected_tile = s.owned_tiles[0]
        bt = data.get("best_times", [0, 0, 0])
        s.best_times = [float(bt[i]) if i < len(bt) else 0.0 for i in range(3)]
        s.challenges_done = int(data.get("challenges_done", 0))
        return s
