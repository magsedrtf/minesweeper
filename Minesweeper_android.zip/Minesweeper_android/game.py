# -*- coding: utf-8 -*-
"""Minesweeper — главный класс приложения (arcade).

Архитектура:
    board.py   — чистая логика поля (мины, flood-fill, аккорд), без графики
    sprites.py — работа со спрайтами: вся графика в PNG (папка sprites/)
    ui.py      — виджеты (кнопки-спрайты, ленты, надписи) на arcade
    game.py    — окна/экраны/ввод/раунд/взрывы (этот файл)
    sounds.py  — звуки WAV через arcade
    saveio.py  — сохранение прогресса

Меню по центру: круглая эмблема с бомбой, ленты-кнопки слегка заходят
на эмблему, справа косой срез «/». Всё меню чуть-чуть двигается за курсором.
Поле — классическое плоское с фаской, флажки анимированы кадрами PNG.
"""
import math
import os
import random

import arcade
from arcade.types import LRBT

import settings as st
import sprites as spr
import ui
import challenges as chal
import sounds as snd
import fieldfx
from board import Board
from saveio import SaveData
from sounds import Sounds


def fmt_time(t):
    s = max(0, int(t))
    return "{:02d}:{:02d}".format(s // 60, s % 60)


class Grid:
    """Плоская сетка клеток: квадратные ячейки, левый верхний угол (ox, oy)."""

    def __init__(self, cols, rows, S, ox, oy):
        self.cols, self.rows, self.S = cols, rows, int(S)
        self.ox, self.oy = int(ox), int(oy)
        self.w = self.cols * self.S
        self.h = self.rows * self.S

    def rect(self, x, y):
        return ui.Rect(self.ox + x * self.S, self.oy + y * self.S, self.S, self.S)

    def center(self, x, y):
        r = self.rect(x, y)
        return r.centerx, r.centery

    def center_arc(self, x, y):
        cx, cy = self.center(x, y)
        return cx, ui.Y(cy)

    def pick(self, px, py):
        x = int((px - self.ox) // self.S)
        y = int((py - self.oy) // self.S)
        if 0 <= x < self.cols and 0 <= y < self.rows:
            return x, y
        return None


class MinesweeperGame(arcade.Window):
    # Экран «ИГРАТЬ»: геометрия (виртуальные px, y вниз)
    DIFF_X = 360            # плашки сложности по центру (ширина 560)
    DIFF_X_OPEN = 28        # ...и после выбора — слева, не за экраном
    PANEL = (612, 104, 644, 508)   # панель испытаний справа: x, y, w, h
    CARD_STEP, CARD_H = 72, 64     # шаг и высота карточек испытаний (6 шт.)
    PLAY_GAP = 24           # зазор между плашками и въезжающей панелью
    PLAY_ACCENTS = ((84, 200, 110), (246, 160, 50), (236, 84, 70))
    CONFIRM_Y = 340         # центр панели подтверждения («ДА»/«НЕТ»)

    def __init__(self, windowed=False):
        super().__init__(st.SCREEN_W, st.SCREEN_H, "Minesweeper",
                         fullscreen=not windowed, resizable=True, vsync=True)
        ui.load_fonts()
        self.assets = spr.Assets()
        self.sounds = Sounds()
        self.save = SaveData.load()

        self.state = "menu"
        self.mouse = (st.SCREEN_W / 2, st.SCREEN_H / 2)

        self.diff_index = 1
        self.chal_diff_index = 1
        self.challenges = []       # набор испытаний раунда (ключи)
        self.chal_selected = set() # выбор галочками на экране испытаний
        self.modules = []          # модули испытаний (challenges.py)

        # Раунд
        self.board = None
        self.grid = None
        self.cell = 32
        self.play_time = 0.0
        self.timer_on = False
        self.blitz_left = 0.0
        self.ended = False
        self.exploding = False
        self.explosion_queue = []
        self.explosion_t = 0.0
        self.win_timer = 0.0
        self.overlay = None          # None | 'win' | 'lose'
        self.lose_reason = "mine"    # mine | time
        self.lose_title = "ВЗРЫВ!"
        self.lose_sub = ""
        self.win_stats = ""
        self.confirm_kind = None     # None | 'menu' | 'quit'
        self.hover = None

        # Испытание «ТАСОВКА»: idle -> waiting -> anim -> waiting ...
        # (общее состояние: модуль challenges.ShuffleModule им управляет)
        self.shuffle_phase = "idle"
        self.shuffle_t = 0.0
        self.shuffle_anim = None
        self._anim_local = {}      # спрайт -> локальная точка во время анимации
        self.shuffle_plan = None   # (vertical, k, side) следующей тасовки
        self.shuffle_zone = frozenset()  # клетки, которые улетят в ней
        self.shuffle_last = None   # параметры текущей тасовки (для модулей)
        # шахматка закрытых клеток: (x + y + checker_phase) % 2. Тасовка на
        # нечётное число клеток сдвигает фазу — сдвинутые клетки сохраняют
        # свой цвет, и шахматный порядок не сбивается
        self.checker_phase = 0

        # Испытание «ФУГАС» (общее состояние: challenges.FugasModule)
        self.fugas_phase = "idle"
        self.fugas_t = 0.0          # таймер фазы; в "armed" — общий фитиль бомб
        self.fugas_bombs = []       # активные временные бомбы (1 или 2)
        self.fugas_blink = 0.0
        self.fugas_text = None
        self.fugas_text_shadow = None

        # Испытание «ОРБИТА»: карта (поле целиком) вращается и летит по
        # восьмёрке. Камеры нет: зум и перетаскивание — часть трансформации
        # самой карты, поэтому клики всегда совпадают с видимыми клетками.
        self.orbit_u = 0.0          # параметр движения по восьмёрке (радианы)
        self.orbit_deg = 0.0        # угол вращения карты (градусы)
        self.orbit_zoom = 1.0       # масштаб карты «Орбиты»
        self.orbit_pan = [0.0, 0.0] # сдвиг карты (виртуальные px, y вверх)
        # «ТУМАН» (заполняется в _fog_build при старте раунда)
        self.fog_clouds = []
        self.fog_alpha = {}
        self.fog_lamp = False
        self.fog_lamp_k = 0.0
        self.fog_lift = 0.0
        self.fog_light = None
        self.fog_screen = []
        self.lamp_charge = 1.0
        self.lamp_dead = False
        self.lamp_flare = 0.0
        self.field_fx = None          # украшения/эффекты скина поля (fieldfx.py)
        self._orbit_frame = ([], [])   # повёрнутые точки рамки поля (Орбита)
        self._pan_active = False    # идёт перетаскивание карты (Shift+ЛКМ)
        self._pan_grab = (0.0, 0.0)  # курсор в момент захвата (y вверх)
        self._pan_orig = (0.0, 0.0)  # сдвиг карты в момент захвата
        self._shift_down = False
        self.mouse_win = (st.SCREEN_W / 2, st.SCREEN_H / 2)  # курсор в пикселях окна

        # Эффекты
        self.particles = []
        self.rings = []
        # взрыв бомбы: анимация (кадры explosion_NN.png) + разлёт осколков;
        # координаты — локальные координаты карты (летят вместе с ней)
        self.fx_booms = []
        self.fx_shards = []
        self.boom_list = arcade.SpriteList()
        self.shard_list = arcade.SpriteList()
        self.flash = 0.0
        self.shake = 0.0
        self.toast_s = ""
        self.toast_t = 0.0
        self._toast_text = None
        self.anim_t = 0.0
        # магазин/инвентарь: открытая страница каждой колонки
        self.shop_page = {}
        # экраны-списки (st.SCROLL_SCREENS): прокрутка каждой колонки, px.
        # scroll — текущая (плавно догоняет), scroll_target — куда едем
        self.scroll = {}
        self.scroll_target = {}
        self.scroll_cols = {}
        self._scroll_drag = None     # тянем полосу: (ключ, y захвата, прокрутка)
        self._scissor_ok = True

        # Параллакс меню: всё меню чуть-чуть двигается за курсором
        self.par = (0.0, 0.0)
        # Параллакс карты в игре (виртуальные px, y вниз): только поле,
        # HUD/оверлеи, фон и декор фона стоят на месте
        self.gpar = (0.0, 0.0)

        # Чит-код (вводится в инвентаре)
        self._cheat_buf = ""

        # Меню: эмблема по центру, ленты слегка заходят на неё
        self.badge_pos = (st.SCREEN_W // 2, st.MENU_BADGE_Y)
        self.badge_r = 138

        # Экран «ИГРАТЬ»: выбранная сложность (None — плашки по центру),
        # прогресс появления испытаний 0..1, яркость/размер плашек
        self.play_sel = None
        self.play_t = 0.0
        self.play_dim = [1.0] * len(st.DIFFICULTIES)
        self.play_zoom = [1.0] * len(st.DIFFICULTIES)
        self.play_accent = list(self.PLAY_ACCENTS[1])

        # Фоновый спрайт
        self.bg_sprite = arcade.Sprite(self.assets.background,
                                       scale=st.SCREEN_W / self.assets.background.width)
        self.bg_sprite.position = (st.SCREEN_W / 2, st.SCREEN_H / 2)
        # Декор фона: падающие белые полупрозрачные бомбы и флажки
        self._build_decor()

        # Спрайты поля
        self.cell_list = arcade.SpriteList()
        self.overlay_list = arcade.SpriteList()
        self.num_list = arcade.SpriteList()
        self._num_tex_cache = {}
        self.cell_sprites = {}
        self.flag_refs = []          # [(Sprite, skin), ...] для анимации
        self.overlay_coords = []     # координаты спрайтов overlay_list
        self.num_coords = []         # координаты спрайтов num_list
        self.hover_sprite = arcade.Sprite(self.assets.hover)
        self.hover_sprite.alpha = 46
        self._hover_on = False
        self._num_cache = {}
        self._frame_outer = []
        self._frame_inner = []

        # постоянные спрайты меню и HUD
        r = self.badge_r
        self.badge_shadow_sprite = arcade.Sprite(
            self.assets.badge_shadow, scale=(r * 2.1) / self.assets.badge_shadow.width)
        self.badge_sprite = arcade.Sprite(
            self.assets.badge, scale=(r * 2) / self.assets.badge.width)
        self.hud_bar_sprite = arcade.Sprite(
            self.assets.hud_bar, scale=st.SCREEN_W / self.assets.hud_bar.width)
        self.hud_bomb_sprite = arcade.Sprite(
            self.assets.bomb_icon("b_classic", 36), scale=36 / 96.0)
        self.result_panel_sprite = arcade.Sprite(
            self.assets.panel_result, scale=780 / self.assets.panel_result.width)
        self.confirm_panel_sprite = arcade.Sprite(
            self.assets.panel_confirm, scale=640 / self.assets.panel_confirm.width)
        self.toast_panel_sprite = arcade.Sprite(
            self.assets.panel_toast, scale=660 / self.assets.panel_toast.width)

        self.sounds.music_start()
        self.screens = {}
        self._build_ui()
        self._apply_camera()
        if getattr(self.save, "refunded", None):
            # убранный из магазина скин (патч 11: «Ледяной флаг») — монеты
            # вернули при загрузке; сохраняем сразу, чтобы не вернуть дважды
            back = sum(int(st.REMOVED_ITEMS.get(i, 0)) for i in self.save.refunded)
            self.save.save()
            self._toast("Ледяной флаг убран — возвращено {} монет".format(back))

    # ---------- Экран/окно/камера ----------

    def _apply_camera(self):
        """Letterbox: виртуальные 1280×720 вписываются в окно без искажений."""
        w, h = self.width, self.height
        zoom = min(w / st.SCREEN_W, h / st.SCREEN_H)
        vw, vh = st.SCREEN_W * zoom, st.SCREEN_H * zoom
        vx, vy = (w - vw) / 2, (h - vh) / 2
        self._vp = (vx, vy, zoom)
        if not hasattr(self, "cam"):
            self.cam = arcade.Camera2D(window=self)
        self.cam.viewport = LRBT(vx, vx + vw, vy, vy + vh)
        self.cam.projection = LRBT(0.0, float(st.SCREEN_W),
                                   0.0, float(st.SCREEN_H))
        self.cam.position = (0.0, 0.0)

    def on_resize(self, width, height):
        super().on_resize(width, height)
        self._apply_camera()

    def _to_virtual(self, x, y):
        """Пиксели окна -> виртуальные координаты (0,0 слева сверху)."""
        vx, vy, zoom = self._vp
        return ((x - vx) / zoom, st.SCREEN_H - (y - vy) / zoom)

    def _toggle_fullscreen(self):
        self.set_fullscreen(not self.fullscreen)

    # ---------- Интерфейс ----------

    def _build_ui(self):
        W = st.SCREEN_W

        # --- Главное меню: ленты по центру, слегка заходят на эмблему ---
        # (испытания теперь внутри «ИГРАТЬ» — отдельного пункта нет)
        rx, rw, rh, gap = W // 2 - 200, 400, 52, 12
        y0 = st.MENU_BADGE_Y + self.badge_r - 22
        menu_items = [
            ("ИГРАТЬ", lambda: self.goto("difficulty"), st.RIBBON_PLAY, "play"),
            ("МАГАЗИН", lambda: self.goto("shop"), st.RIBBON_SHOP, "shop"),
            ("ИНВЕНТАРЬ", lambda: self.goto("inventory"), st.RIBBON_BAG, "bag"),
            ("ВЫХОД", self._ask_quit, st.RIBBON_EXIT, "exit"),
        ]
        self.menu_ribbons = [
            ui.RibbonButton(rx, y0 + i * (rh + gap), rw, rh, lbl, cb, col, ik)
            for i, (lbl, cb, col, ik) in enumerate(menu_items)
        ]
        # заголовок: «MINESWEE» + анимированный флажок вместо «P» + «ER»
        lay = self._title_layout(W // 2, 84, 52)
        self.title_layout = lay
        self.title_left = ui.Label(lay["x0"], 84, lay["left"], 52, align="midleft")
        self.title_right = ui.Label(lay["er_x"], 84, lay["right"], 52, align="midleft")
        self.title_flag = arcade.Sprite(self.assets.flag_frames(self.save.selected_flag)[0])
        self.screens["menu"] = [
            self.title_left, self.title_right,
            *self.menu_ribbons,
        ]

        # --- «ИГРАТЬ»: сложность -> (плашки уезжают влево) -> испытания ---
        accents = ["green", "fire", "exit"]
        self.diff_buttons = []
        for i in range(len(st.DIFFICULTIES)):
            b = ui.Button(self.DIFF_X, 140 + i * 132, 560, 112, "", None,
                          accents[i], 32)
            b.sub_size = 21
            b.cb = (lambda idx=i: self._select_diff(idx))
            self.diff_buttons.append(b)
        px, py, pw, ph = self.PANEL
        pcx = px + pw // 2
        self.diff_title = ui.Label(640, 66, "ВЫБОР СЛОЖНОСТИ", 52)
        self.diff_head = ui.Label(self.DIFF_X_OPEN + 280, 66, "СЛОЖНОСТЬ", 44)
        self.chal_head = ui.Label(pcx, 66, "ИСПЫТАНИЯ", 44)
        self.chal_hint = ui.Label(
            pcx, py + 24, "Отметьте галочками — можно несколько сразу",
            16, st.CLR_DIM)
        # испытания: галочки на каждом, можно соединить несколько
        self.chal_cards = []
        for i, (key, title, desc, _) in enumerate(st.CHALLENGES):
            card = ui.CheckCard(
                px + 16, py + 44 + i * self.CARD_STEP, pw - 32, self.CARD_H,
                title, desc,
                key in self.chal_selected,
                lambda k=key: self._toggle_challenge(k))
            self.chal_cards.append(card)
        self.chal_mult_label = ui.Label(pcx, py + ph - 20, "", 19, st.CLR_GOLD)
        self.chal_start_btn = ui.Button(
            px + pw - 300, 620, 300, 68, "НАЧАТЬ", self._start_combined,
            "green", 26)
        self.diff_back_btn = ui.Button(40, 628, 220, 60, "НАЗАД",
                                       self._diff_back, "grey", 24)
        self.screens["difficulty"] = [
            self.diff_title, self.diff_head, self.chal_head, self.chal_hint,
            *self.diff_buttons,
            *self.chal_cards,
            self.chal_mult_label,
            self.chal_start_btn,
            self.diff_back_btn,
        ]
        self._play_panel = arcade.Sprite(self.assets.panel_chal)
        self._play_glow = arcade.Sprite(self.assets.panel_chal_glow)

        # --- Магазин/инвентарь наполняются динамически ---
        self.screens["shop"] = []
        self.screens["inventory"] = []

        # --- HUD игрового экрана (монеты — только в магазине) ---
        self.hud_mines = ui.Label(72, 28, "", 24, st.CLR_TEXT, align="midleft")
        self.hud_time = ui.Label(640, 30, "", 30, st.CLR_TEXT)
        self.hud_banner = ui.Label(640, 80, "", 18, st.CLR_GOLD)
        self.screens["game"] = [
            self.hud_mines, self.hud_time, self.hud_banner,
            ui.Button(1128, 8, 136, 42, "МЕНЮ", self._ask_menu, "panel", 20),
        ]

        # --- Оверлей победы ---
        self.win_stats_label = ui.Label(640, 350, "", 26, st.CLR_TEXT)
        self.screens["win"] = [
            ui.Label(640, 250, "ПОБЕДА!", 72, (110, 226, 130)),
            self.win_stats_label,
            ui.Button(410, 480, 220, 66, "ЗАНОВО", self._restart, "green", 26),
            ui.Button(650, 480, 220, 66, "В МЕНЮ", lambda: self.goto("menu"), "grey", 26),
        ]

        # --- Оверлей проигрыша ---
        self.lose_title_label = ui.Label(640, 250, "ВЗРЫВ!", 72, (255, 116, 96))
        self.lose_sub_label = ui.Label(640, 350, "", 24, st.CLR_TEXT)
        self.screens["lose"] = [
            self.lose_title_label,
            self.lose_sub_label,
            ui.Button(410, 480, 220, 66, "РЕСТАРТ", self._restart, "green", 26),
            ui.Button(650, 480, 220, 66, "В МЕНЮ", lambda: self.goto("menu"), "grey", 26),
        ]

        # --- Диалог подтверждения: панель 640×260 (y 210..470), кнопки
        # с отступом от нижнего края панели ---
        self.confirm_label = ui.Label(640, self.CONFIRM_Y - 48, "", 24, st.CLR_TEXT)
        by = self.CONFIRM_Y + 20
        self.screens["confirm"] = [
            self.confirm_label,
            ui.Button(430, by, 180, 62, "ДА", self._confirm_yes, "green", 26),
            ui.Button(670, by, 180, 62, "НЕТ", self._confirm_no, "grey", 26),
        ]

        self._refresh_challenge()
        self._refresh_shop()
        self._layout_play(0.0)

    # ---------- Экран «ИГРАТЬ»: сложность + испытания ----------

    def _select_diff(self, idx):
        """Клик по сложности: игра НЕ запускается — плашки плавно уезжают
        влево (невыбранные темнеют и чуть уменьшаются), справа появляются
        испытания и кнопка «НАЧАТЬ» (можно и без испытаний)."""
        if self.play_sel == idx:
            return
        self.play_sel = idx
        self.chal_diff_index = idx
        self._refresh_challenge()
        self.sounds.play("click")

    def _set_chal_diff(self, idx):
        """Совместимость: выбор сложности для набора испытаний."""
        self._select_diff(idx)

    def _diff_back(self):
        """«НАЗАД»: сначала сворачиваем испытания, потом — в меню."""
        if self.play_sel is not None:
            self.play_sel = None
            self.sounds.play("click")
        else:
            self.goto("menu")

    def _update_play(self, dt):
        target = 1.0 if self.play_sel is not None else 0.0
        step = dt / max(0.05, st.PLAY_REVEAL_T)
        if target < self.play_t:
            step *= 1.7                      # сворачивается быстрее
        if self.play_t < target:
            self.play_t = min(target, self.play_t + step)
        else:
            self.play_t = max(target, self.play_t - step)
        self._layout_play(dt)

    def _layout_play(self, dt):
        """Раскладка экрана «ИГРАТЬ» по прогрессу появления play_t (0..1).
        Каждый элемент появляется в свой момент (секунды от начала):
            0.00–0.42  плашки сложности уезжают влево, а панель испытаний
                       въезжает справа вплотную за ними — «выталкивает»
                       их (левый край панели идёт за правым краем плашек,
                       поэтому они никогда не перекрываются);
            0.00–0.34  «ВЫБОР СЛОЖНОСТИ» гаснет, проявляется «СЛОЖНОСТЬ»;
            0.18–0.48  заголовок «ИСПЫТАНИЯ» опускается сверху;
            0.28–0.74  карточки испытаний влетают справа по очереди;
            0.47–0.75  «НАЧАТЬ» и награда «выпрыгивают».
        При сворачивании всё идёт в обратном порядке."""
        T = self.play_t * 0.75
        # 1) плашки сложности: сдвиг влево, невыбранные — темнее и меньше
        p = _ease_in_out(_clamp01(T / 0.42))
        full = self.DIFF_X_OPEN - self.DIFF_X
        dx = full * p
        k = 1.0 if dt <= 0 else min(1.0, dt * 9.0)
        sel = self.play_sel
        for i, b in enumerate(self.diff_buttons):
            chosen = sel is None or i == sel
            td = 1.0 if chosen else st.PLAY_DIM
            tz = 1.0 if chosen else st.PLAY_SHRINK
            self.play_dim[i] += (td - self.play_dim[i]) * k
            self.play_zoom[i] += (tz - self.play_zoom[i]) * k
            b.shift = (dx, 0.0)
            b.dim = self.play_dim[i]
            b.zoom = self.play_zoom[i]
        if sel is not None:
            acc = self.PLAY_ACCENTS[sel % len(self.PLAY_ACCENTS)]
            self.play_accent = [a + (c - a) * k
                                for a, c in zip(self.play_accent, acc)]
        # 2) заголовок слева: плавная смена надписи на месте
        q_out = _ease_out(_clamp01(T / 0.16))           # старая гаснет
        q_in = _ease_out(_clamp01((T - 0.12) / 0.22))   # новая проявляется
        self.diff_title.shift = (dx, 0.0)
        self.diff_title.alpha = 255 * (1.0 - q_out)
        self.diff_head.shift = (dx - full, 0.0)
        self.diff_head.alpha = 255 * q_in
        # 3) панель въезжает справа вплотную за плашками
        px = self.PANEL[0]
        plate_right = self.DIFF_X + self.diff_buttons[0].rect.w + dx
        pdx = max(0.0, plate_right + self.PLAY_GAP - px)
        self._panel_dx = pdx
        self._panel_alpha = 255 * _ease_out(_clamp01(T / 0.16))
        # 4) заголовок и подсказка опускаются сверху (вместе с панелью)
        v = _ease_out(_clamp01((T - 0.18) / 0.30))
        self.chal_head.alpha = 255 * v
        self.chal_head.shift = (pdx, -26.0 * (1.0 - v))
        v2 = _ease_out(_clamp01((T - 0.24) / 0.28))
        self.chal_hint.alpha = 255 * v2
        self.chal_hint.shift = (pdx, -14.0 * (1.0 - v2))
        # 5) карточки влетают справа по очереди, с пружинкой
        for i, card in enumerate(self.chal_cards):
            # шаг подобран так, чтобы последняя (6-я) карточка успевала
            # к тому же моменту, что и раньше 5-я
            w = _clamp01((T - 0.28 - 0.18 * i / max(1, len(self.chal_cards) - 1))
                         / 0.28)
            e = _ease_out_back(w, 1.5)
            card.alpha = 255 * _clamp01(w * 1.8)
            card.shift = (pdx + 120.0 * (1.0 - e), 0.0)
            card.zoom = 0.94 + 0.06 * _ease_out(w)
        # 6) кнопка «НАЧАТЬ» и награда «выпрыгивают»
        z = _clamp01((T - 0.47) / 0.28)
        self.chal_start_btn.zoom = 0.6 + 0.4 * _ease_out_back(z, 1.8)
        self.chal_start_btn.alpha = 255 * _clamp01(z * 2.0)
        self.chal_start_btn.shift = (pdx, 0.0)
        self.chal_mult_label.alpha = 255 * _ease_out(z)
        self.chal_mult_label.shift = (pdx, 0.0)

    def _draw_play(self):
        """Экран «ИГРАТЬ»: заголовки, панель испытаний, плашки, кнопки."""
        widgets = self.screens["difficulty"]
        self._apply_par(widgets)
        for lb in (self.diff_title, self.diff_head, self.chal_head):
            lb.draw(self.mouse)
        self._draw_play_panel()
        self.chal_hint.draw(self.mouse)
        for b in self.diff_buttons:
            b.draw(self.assets, self.mouse)
        for card in self.chal_cards:
            card.draw(self.assets, self.mouse)
        self.chal_mult_label.draw(self.mouse)
        self.chal_start_btn.draw(self.assets, self.mouse)
        self.diff_back_btn.draw(self.assets, self.mouse)

    def _draw_play_panel(self):
        a = int(max(0, min(255, getattr(self, "_panel_alpha", 0))))
        if a <= 0:
            return
        px, py, pw, ph = self.PANEL
        w = pw
        cx = px + getattr(self, "_panel_dx", 0.0) + w / 2.0 + self.par[0]
        cy = ui.Y(py + ph / 2.0 + self.par[1])
        body, glow = self.assets.panel_chal, self.assets.panel_chal_glow
        self._play_panel.scale = (w / max(1, body.width), ph / max(1, body.height))
        self._play_panel.position = (cx, cy)
        self._play_panel.alpha = a
        arcade.draw_sprite(self._play_panel)
        # свечение рамки цвета сложности по бокам — с патча 11 выключено
        # (settings.CHAL_PANEL_GLOW = True — вернуть)
        if not getattr(st, "CHAL_PANEL_GLOW", False):
            return
        m = 28.0                                   # поле свечения, px
        self._play_glow.scale = ((w + 2 * m) / max(1, glow.width),
                                 (ph + 2 * m) / max(1, glow.height))
        self._play_glow.position = (cx, cy)
        self._play_glow.color = tuple(int(c) for c in self.play_accent)
        self._play_glow.alpha = int(a * 0.85)
        arcade.draw_sprite(self._play_glow)

    def _toggle_challenge(self, key):
        """Галочка испытания: отмечаем/снимаем — наборы соединяются."""
        if key in self.chal_selected:
            self.chal_selected.discard(key)
        else:
            self.chal_selected.add(key)
        for card, (k, _, _, _) in zip(self.chal_cards, st.CHALLENGES):
            card.checked = k in self.chal_selected
        self._refresh_challenge()
        self.sounds.play("click")

    def _start_combined(self):
        """«НАЧАТЬ»: раунд выбранной сложности со всеми отмеченными
        испытаниями; без галочек — обычная игра."""
        keys = [k for k, _, _, _ in st.CHALLENGES if k in self.chal_selected]
        self.start_game(self.chal_diff_index, keys or None)

    def _refresh_challenge(self):
        diff_key = st.DIFFICULTIES[self.chal_diff_index][0]
        # карточки: название · множитель, описание; галочки — как выбрано
        for card, (key, title, desc, _) in zip(self.chal_cards, st.CHALLENGES):
            card.checked = key in self.chal_selected
            card.title = "{} · награда ×{:g}".format(
                title, st.challenge_mult(key, diff_key))
            card.sub = desc
        # итоговый множитель набора — произведение множителей
        keys = [k for k, _, _, _ in st.CHALLENGES if k in self.chal_selected]
        total = chal.combined_mult(keys, diff_key)
        if keys:
            self.chal_mult_label.set_text(
                "НАГРАДА: ×{:g}  (сложность ×{:g})".format(
                    total, st.diff_chal_mult(diff_key)), st.CLR_GOLD)
            self.chal_start_btn.label = "НАЧАТЬ · ×{:g}".format(total)
        else:
            self.chal_mult_label.set_text(
                "Без испытаний — обычная игра на рекорд", st.CLR_DIM)
            self.chal_start_btn.label = "НАЧАТЬ"
        self.chal_start_btn.enabled = True
        self.chal_start_btn.bg = "green"

    def _diff_labels(self):
        out = []
        for i, (_, name, cols, rows, mines, _) in enumerate(st.DIFFICULTIES):
            best = self.save.best_times[i]
            rec = fmt_time(best) if best > 0 else "—"
            out.append("{}\n{} × {} · {} мин · рекорд: {}".format(
                name, cols, rows, mines, rec))
        return out

    def _refresh_shop(self):
        self._refresh_shop_screen("shop", True)
        self._refresh_shop_screen("inventory", False)

    def _refresh_shop_screen(self, state, is_shop):
        widgets = [
            ui.Label(640, 56, "МАГАЗИН" if is_shop else "ИНВЕНТАРЬ", 48),
        ]
        # монеты показываются ТОЛЬКО в магазине
        if is_shop:
            widgets.append(ui.Label(st.SCREEN_W - 56, 30,
                                    "МОНЕТЫ: {}".format(self.save.coins), 26,
                                    st.CLR_GOLD, align="midright"))
            widgets.append(ui.Icon(st.SCREEN_W - 38, 30, self.assets.coin, 30))
            widgets.append(ui.Label(640, 694,
                "Монеты дают победы: чем сложнее поле и испытание, тем больше награда",
                19, st.CLR_DIM))
        else:
            widgets.append(ui.Label(640, 694,
                "",
                19, st.CLR_DIM))

        # три колонки «иконка + кнопка», вся сетка — строго по центру экрана
        columns = [("flag", "ФЛАЖКИ"), ("bomb", "БОМБЫ"), ("tile", "ПОЛЕ")]
        icon, gap_i, bw, gap_c = 56, 10, 304, 30
        group = icon + gap_i + bw
        left = (st.SCREEN_W - (3 * group + 2 * gap_c)) // 2
        per = st.SHOP_PER_PAGE
        self.shop_cols = getattr(self, "shop_cols", {})
        # список с прокруткой (инвентарь) вместо страниц
        scroll = state in st.SCROLL_SCREENS
        vt, vb = st.SCROLL_VIEW
        for col, (kind, header) in enumerate(columns):
            x0 = left + col * (group + gap_c)
            widgets.append(ui.Label(x0 + group // 2, 106, header, 26, st.CLR_GOLD))
            rows = self._shop_rows(kind, is_shop)
            key = (state, kind)
            if scroll:
                # все строки подряд; видна полоса vt..vb, остальное — колесом
                # мыши или полосой прокрутки справа от колонки
                pages, page = 1, 0
                view = ui.Rect(x0 - 6, vt, group + 16, vb - vt)
                mx = max(0.0, 148 + 92.0 * len(rows) - 18 - (vb - 8))
                self.scroll_cols[key] = {
                    "view": view, "max": mx, "n": len(rows),
                    "bar": ui.Rect(x0 + group + 8, vt + 8, 8, vb - vt - 16)}
                t = min(max(0.0, self.scroll_target.get(key, 0.0)), mx)
                self.scroll_target[key] = t
                self.scroll[key] = min(max(0.0, self.scroll.get(key, t)), mx)
                self.shop_cols[key] = (ui.Rect(x0, 90, group + 24, vb - 90), 1)
                shown = rows
            else:
                # страницы: по SHOP_PER_PAGE строк, листаются стрелками ◀ ▶
                # у заголовка или колесом мыши над колонкой
                pages = max(1, (len(rows) + per - 1) // per)
                page = min(max(0, self.shop_page.get(key, 0)), pages - 1)
                self.shop_page[key] = page
                self.shop_cols[key] = (ui.Rect(x0, 90, group, 148 + per * 92 - 90),
                                       pages)
                shown = rows[page * per:(page + 1) * per]
            if pages > 1:
                for dx, arrow, step in ((0, "◀", -1), (group - 40, "▶", 1)):
                    ab = ui.Button(x0 + dx, 89, 40, 34, arrow,
                                   lambda k=kind, d=step: self._shop_flip(k, d),
                                   "panel", 18, st.CLR_GOLD)
                    ab.hover_k = 1.1
                    ab.page_arrow = (kind, step)
                    widgets.append(ab)
                widgets.append(ui.Label(x0 + group - 48, 107,
                                        "{}/{}".format(page + 1, pages), 17,
                                        st.CLR_DIM, align="midright"))
            for r, (iid, title, price, custom) in enumerate(shown):
                y = 148 + r * 92
                owned = custom or self.save.owns(iid)
                selected = self.save.is_selected(iid)
                bx = x0 + icon + gap_i
                if is_shop and not owned:
                    # магазин: только покупка
                    afford = self.save.coins >= price
                    label = "{}\n{} — КУПИТЬ".format(
                        title, "{} монет".format(price) if price else "бесплатно")
                    b = ui.Button(bx, y, bw, 74, label,
                                  lambda i=iid: self._shop_buy(i),
                                  "green" if afford else "dark", 19,
                                  st.CLR_TEXT if afford else st.CLR_DIM)
                    b.sub_size = 17
                elif is_shop:
                    # уже куплено — в магазине не надевается (это в инвентаре)
                    b = ui.Button(bx, y, bw, 74, "{}\nКУПЛЕНО ✓".format(title),
                                  None, "panel", 19, (138, 206, 150))
                    b.sub_size = 17
                    b.enabled = False
                elif selected:
                    b = ui.Button(bx, y, bw, 74, "{}\nВЫБРАНО".format(title),
                                  lambda i=iid: self._inv_select(i), "selected", 19,
                                  st.CLR_GOLD)
                    b.sub_size = 17
                    b.enabled = False
                else:
                    b = ui.Button(bx, y, bw, 74, "{}\nВЫБРАТЬ".format(title),
                                  lambda i=iid: self._inv_select(i), "panel", 19)
                    b.sub_size = 17
                widgets.append(b)
                if kind == "flag":
                    tex = self.assets.flag_icon(iid, 56)
                elif kind == "bomb":
                    tex = self.assets.bomb_icon(iid, 56)
                else:
                    tex = self.assets.tile_icon(iid.replace("t_", "", 1)
                                                if iid.startswith("t_") else iid)
                ic = ui.Icon(x0 + icon // 2, y + 37, tex, icon) if tex else None
                if ic is not None:
                    widgets.append(ic)
                if scroll:
                    for wd in (b, ic):
                        if wd is not None:
                            wd.scroll_key = key
                            wd.row_y = y
                            wd.clip = self.scroll_cols[key]["view"]
        self.screens[state] = widgets
        if scroll:
            self._scroll_apply(state)

    def _shop_rows(self, kind, is_shop):
        """Строки колонки kind: [(id, название, цена, свой_png), ...]."""
        rows = [(it[0], it[1], it[2], False) for it in st.SHOP_ITEMS
                if it[3] == kind and (is_shop or self.save.owns(it[0]))]
        if not is_shop:
            rows += [(sid, self.assets.skin_title(sid), 0, True)
                     for sid in self.assets.custom_skins(kind)]
        return rows

    def _shop_flip(self, kind, step, state=None):
        """Листаем страницу колонки (по кругу)."""
        state = state or self.state
        info = getattr(self, "shop_cols", {}).get((state, kind))
        pages = info[1] if info else 1
        if pages <= 1:
            return
        self.shop_page[(state, kind)] = (self.shop_page.get((state, kind), 0)
                                         + step) % pages
        self._refresh_shop_screen(state, state == "shop")
        self.sounds.play("click")

    def _shop_reveal(self, state, item_id):
        """Открыть страницу, на которой лежит item_id (True — нашли)."""
        kind = {"f": "flag", "b": "bomb", "t": "tile"}.get(item_id[:1])
        rows = self._shop_rows(kind, state == "shop")
        for i, row in enumerate(rows):
            if row[0] == item_id:
                if state in st.SCROLL_SCREENS:
                    # список: докрутить так, чтобы строка была целиком видна
                    self._refresh_shop_screen(state, state == "shop")
                    key = (state, kind)
                    vt, vb = st.SCROLL_VIEW
                    top, bot = 148 + 92 * i, 148 + 92 * i + 74
                    s = self.scroll_target.get(key, 0.0)
                    if top - s < vt + 8:
                        s = top - vt - 8
                    elif bot - s > vb - 8:
                        s = bot - vb + 8
                    self._scroll_set(key, s, instant=True)
                    return True
                self.shop_page[(state, kind)] = i // st.SHOP_PER_PAGE
                self._refresh_shop_screen(state, state == "shop")
                return True
        return False

    # ---------- Прокрутка списков (инвентарь) ----------

    def _scroll_set(self, key, value, instant=False):
        """Куда прокрутить колонку key (с ограничением 0..max)."""
        info = self.scroll_cols.get(key)
        mx = info["max"] if info else 0.0
        v = min(max(0.0, float(value)), mx)
        self.scroll_target[key] = v
        if instant:
            self.scroll[key] = v
            self._scroll_apply(key[0])
        return v

    def _scroll_update(self, dt):
        """Плавная прокрутка: текущее положение экспоненциально догоняет цель."""
        if not self.scroll_target:
            return
        k = 1.0 - math.exp(-st.SCROLL_SMOOTH * max(0.0, dt))
        moved = False
        for key, t in self.scroll_target.items():
            s = self.scroll.get(key, 0.0)
            if s == t:
                continue
            s = t if abs(t - s) < 0.4 else s + (t - s) * k
            self.scroll[key] = s
            moved = True
        if moved and self.state in st.SCROLL_SCREENS:
            self._scroll_apply(self.state)

    def _scroll_apply(self, state):
        """Сдвинуть строки списка на прокрутку; строки у края полосы
        плавно гаснут, совсем ушедшие — не рисуются и не кликаются."""
        for wd in self.screens.get(state, ()):
            key = getattr(wd, "scroll_key", None)
            if key is None:
                continue
            s = self.scroll.get(key, 0.0)
            wd.shift = (0.0, -s)
            c = wd.clip
            top = wd.row_y - s
            vis = (min(top + 74, c.bottom) - max(top, c.y)) / 74.0
            vis = max(0.0, min(1.0, vis))
            wd.visible = vis > 0.0
            wd.alpha = 255 * vis * vis * (3.0 - 2.0 * vis)

    def _scroll_thumb(self, key):
        """Ползунок полосы прокрутки: (y, h) в px сверху или None."""
        info = self.scroll_cols.get(key)
        if not info or info["max"] <= 0:
            return None
        bar = info["bar"]
        view_h = info["view"].h
        h = max(40.0, bar.h * view_h / (view_h + info["max"]))
        f = self.scroll.get(key, 0.0) / info["max"]
        return bar.y + (bar.h - h) * f, h

    def _scroll_press(self, pos):
        """ЛКМ по полосе прокрутки: тянем ползунок (или прыгаем к месту)."""
        for key, info in self.scroll_cols.items():
            if key[0] != self.state:
                continue
            th = self._scroll_thumb(key)
            if th is None:
                continue
            bar = info["bar"]
            if not (bar.x - 8 <= pos[0] < bar.right + 8
                    and bar.y - 6 <= pos[1] < bar.bottom + 6):
                continue
            ty, h = th
            if not (ty <= pos[1] < ty + h):
                # клик мимо ползунка — ползунок центрируется под курсором
                f = (pos[1] - h / 2.0 - bar.y) / max(1.0, bar.h - h)
                self._scroll_set(key, f * info["max"], instant=True)
            self._scroll_drag = (key, pos[1], self.scroll.get(key, 0.0))
            return True
        return False

    def _scroll_drag_to(self, pos):
        key, y0, s0 = self._scroll_drag
        info = self.scroll_cols.get(key)
        th = self._scroll_thumb(key)
        if not info or th is None or key[0] != self.state:
            self._scroll_drag = None
            return
        span = max(1.0, info["bar"].h - th[1])
        self._scroll_set(key, s0 + (pos[1] - y0) * info["max"] / span, instant=True)

    def _draw_scrollbars(self):
        for key, info in self.scroll_cols.items():
            if key[0] != self.state:
                continue
            th = self._scroll_thumb(key)
            if th is None:
                continue
            bar = info["bar"]
            r = bar.w / 2.0
            cx = bar.x + r
            self._pill(cx, bar.y, bar.bottom, r, (255, 255, 255, 26))
            hot = (self._scroll_drag is not None and self._scroll_drag[0] == key) or (
                bar.x - 8 <= self.mouse[0] < bar.right + 8
                and th[0] <= self.mouse[1] < th[0] + th[1])
            self._pill(cx, th[0], th[0] + th[1], r,
                       st.CLR_GOLD if hot else (196, 204, 222, 170))

    @staticmethod
    def _pill(cx, top, bot, r, color):
        """Вертикальная «таблетка» (y сверху вниз)."""
        arcade.draw_lrbt_rectangle_filled(cx - r, cx + r, ui.Y(bot - r),
                                          ui.Y(top + r), color)
        arcade.draw_circle_filled(cx, ui.Y(top + r), r, color)
        arcade.draw_circle_filled(cx, ui.Y(bot - r), r, color)

    def _draw_scroll_screen(self, widgets):
        """Экран-список: обычные виджеты, затем строки каждой колонки —
        под «ножницами» (scissor) по видимой полосе."""
        cols = {}
        for wd in widgets:
            key = getattr(wd, "scroll_key", None)
            if key is None:
                if isinstance(wd, (ui.Button, ui.CheckCard)):
                    wd.draw(self.assets, self.mouse)
                else:
                    wd.draw(self.mouse)
            else:
                cols.setdefault(key, []).append(wd)
        for key, items in cols.items():
            info = self.scroll_cols.get(key)
            clipped = info is not None and self._scissor(info["view"])
            for wd in items:
                if isinstance(wd, ui.Button):
                    wd.draw(self.assets, self.mouse)
                else:
                    wd.draw(self.mouse)
            if clipped:
                self._scissor(None)
        self._draw_scrollbars()

    def _scissor(self, rect):
        """Обрезка рисования по виртуальному Rect (None — снять).
        Если драйвер/версия arcade не умеют — строки просто гаснут у края."""
        if not self._scissor_ok:
            return False
        try:
            if rect is None:
                self.ctx.scissor = None
                return True
            vx, vy, z = self._vp
            x = vx + (rect.x + self.par[0]) * z
            y = vy + (st.SCREEN_H - rect.bottom - self.par[1]) * z
            self.ctx.scissor = (int(x), int(y), int(math.ceil(rect.w * z)),
                                int(math.ceil(rect.h * z)))
            return True
        except Exception:
            self._scissor_ok = False
            try:
                self.ctx.scissor = None
            except Exception:
                pass
            return False

    def _shop_wheel(self, pos, scroll_y):
        """Колесо мыши над колонкой магазина/инвентаря листает её."""
        for (state, kind), (rect, pages) in getattr(self, "shop_cols", {}).items():
            if state != self.state or not rect.collidepoint(pos):
                continue
            if state in st.SCROLL_SCREENS:
                # список: колесо плавно прокручивает колонку
                key = (state, kind)
                self._scroll_set(key, self.scroll_target.get(key, 0.0)
                                 - scroll_y * st.SCROLL_STEP)
                return True
            if pages > 1:
                self._shop_flip(kind, -1 if scroll_y > 0 else 1)
                return True
        return False

    def _shop_click(self, item_id):
        """Совместимость: в магазине — покупка, в инвентаре — выбор."""
        if self.state == "shop":
            self._shop_buy(item_id)
        else:
            self._inv_select(item_id)

    def _shop_buy(self, item_id):
        """МАГАЗИН: только покупка — скин попадает в инвентарь, но не
        надевается (надеть можно в ИНВЕНТАРЕ)."""
        item = st.item_by_id(item_id)
        if item is None:
            return
        iid, title, price, _ = item
        if self.save.owns(iid):
            return
        if self.save.coins < price:
            self._toast("Не хватает монет")
            return
        self.save.coins -= price
        self.save.add_owned(iid, select=False)
        self.save.save()
        self._refresh_shop()
        self._toast("Куплено: {} — наденьте в инвентаре".format(title))
        self.sounds.play("flag")

    def _inv_select(self, item_id):
        """ИНВЕНТАРЬ: надеть купленный (или свой PNG-) скин."""
        item = st.item_by_id(item_id)
        if item is None:
            # пользовательский скин из папки sprites/ — уже доступен, выбираем
            if item_id.startswith("f_"):
                if item_id not in self.save.owned_flags:
                    self.save.owned_flags.append(item_id)
                self.save.selected_flag = item_id
            elif item_id.startswith("t_"):
                if item_id not in self.save.owned_tiles:
                    self.save.owned_tiles.append(item_id)
                self.save.selected_tile = item_id
            else:
                if item_id not in self.save.owned_bombs:
                    self.save.owned_bombs.append(item_id)
                self.save.selected_bomb = item_id
            self.save.save()
            self._refresh_shop()
            self._toast("Выбрано: " + self.assets.skin_title(item_id))
            self.sounds.play("click")
            return
        iid, title, _, _ = item
        if not self.save.owns(iid) or self.save.is_selected(iid):
            return
        self.save.add_owned(iid)  # уже куплено — просто надеваем
        self.save.save()
        self._refresh_shop()
        self._toast("Выбрано: " + title)
        self.sounds.play("click")

    def _unlock_all_skins(self):
        """ """
        for iid, _, _, _ in st.SHOP_ITEMS:
            if iid.startswith("f_") and iid not in self.save.owned_flags:
                self.save.owned_flags.append(iid)
            elif iid.startswith("b_") and iid not in self.save.owned_bombs:
                self.save.owned_bombs.append(iid)
            elif iid.startswith("t_") and iid not in self.save.owned_tiles:
                self.save.owned_tiles.append(iid)
        self.save.save()
        self._refresh_shop()
        self._toast("Все скины разблокированы!")
        self.sounds.play("win")

    # ---------- Навигация ----------

    def goto(self, state):
        # испытания теперь — часть экрана «ИГРАТЬ» (совместимость)
        open_chal = state == "challenge"
        if open_chal:
            state = "difficulty"
        self.state = state
        self.overlay = None
        self.confirm_kind = None
        self.exploding = False
        self.explosion_queue = []
        self.shuffle_phase = "idle"
        self.shuffle_anim = None
        self._anim_local = {}
        self.fugas_phase = "idle"
        self.fugas_bombs = []
        self.shuffle_plan = None
        self.shuffle_zone = frozenset()
        self.gpar = (0.0, 0.0)
        self._clear_fx()
        if state == "difficulty":
            labels = self._diff_labels()
            for b, lbl in zip(self.diff_buttons, labels):
                b.label = lbl
            # экран открывается свёрнутым: плашки по центру
            self.play_sel = None
            self.play_t = 0.0
            self.play_dim = [1.0] * len(self.diff_buttons)
            self.play_zoom = [1.0] * len(self.diff_buttons)
            if open_chal:
                self.play_sel = self.chal_diff_index
                self.play_t = 1.0
                self.play_accent = list(self.PLAY_ACCENTS[self.play_sel])
            self._refresh_challenge()
            self._layout_play(0.0)
        if state in ("shop", "inventory"):
            self._scroll_drag = None
            for key in list(self.scroll_target):
                if key[0] == state:       # список открывается с начала
                    self.scroll_target[key] = self.scroll[key] = 0.0
            self._refresh_shop()
        self.sounds.play("click")

    def _ask_menu(self):
        self.confirm_kind = "menu"
        self.confirm_label.set_text(
            "Выйти в главное меню?\nПрогресс текущего раунда будет потерян")

    def _ask_quit(self):
        self.confirm_kind = "quit"
        self.confirm_label.set_text("Выйти из игры?")

    def _confirm_yes(self):
        kind = self.confirm_kind
        self.confirm_kind = None
        if kind == "quit":
            self.close()
        else:
            self.goto("menu")

    def _confirm_no(self):
        self.confirm_kind = None

    # ---------- Раунд ----------

    def start_game(self, diff_index, challenges=None):
        """Старт раунда. challenges — испытания для СОЕДИНЕНИЯ: None,
        один ключ-строка или список ключей (например, ["orbit", "shuffle"]).
        Модули испытаний строятся в порядке кадра: орбита, тасовка, фугас."""
        if challenges is None:
            challenges = []
        elif isinstance(challenges, str):
            challenges = [challenges]
        allowed = [k for k, _, _, _ in st.CHALLENGES]
        challenges = [k for k in allowed if k in set(challenges)]
        self.diff_index = diff_index
        if challenges:
            self.chal_diff_index = diff_index
            self.chal_selected = set(challenges)
        _, _, cols, rows, mines, blitz = st.DIFFICULTIES[diff_index]
        self.board = Board(cols, rows, mines)
        self.challenges = challenges

        # классическое плоское поле: подбираем размер клетки под экран
        S = int(max(20, min(46, (st.SCREEN_H - st.HUD_H - 88) / rows,
                               (st.SCREEN_W - 96) / cols)))
        self.cell = S
        ox = (st.SCREEN_W - cols * S) // 2
        oy = st.HUD_H + 18 + (st.SCREEN_H - st.HUD_H - 36 - rows * S) // 2
        self.grid = Grid(cols, rows, S, ox, oy)

        self.play_time = 0.0
        self.blitz_left = blitz if "blitz" in challenges else 0.0
        self.timer_on = True
        self.ended = False
        self.exploding = False
        self.explosion_queue = []
        self.explosion_t = 0.0
        self.win_timer = 0.0
        self.overlay = None
        self.confirm_kind = None
        self.particles = []
        self.rings = []
        self._clear_fx()
        self.flash = 0.0
        self.shake = 0.0
        self.hover = None
        self._cheat_buf = ""

        # Испытание «ФУГАС»: idle -> priming(5с) -> waiting(1-5с) ->
        # -> armed(отсчёт 2.000с) -> клик (обезвредить) или взрыв ->
        # -> cooldown(5с) -> waiting ... (до конца партии)
        self.fugas_phase = "idle"
        self.fugas_t = 0.0
        self.fugas_bombs = []         # временные бомбы: клетка, спрайты, возраст
        self.fugas_blink = 0.0        # для мигания
        self.fugas_text = None
        self.fugas_text_shadow = None

        # Испытание «ТАСОВКА»: idle (до первого открытия) -> waiting
        # (период SHUFFLE_INTERVAL) -> anim (полоса улетает, новая прилетает)
        # -> waiting ... — и так до конца партии
        self.shuffle_phase = "idle"
        self.shuffle_t = 0.0
        self.shuffle_anim = None
        self._anim_local = {}
        self.shuffle_plan = None
        self.shuffle_zone = frozenset()
        self.shuffle_last = None
        self.checker_phase = 0
        self.gpar = (0.0, 0.0)

        # Испытание «ОРБИТА»: карта сразу летит по восьмёрке; лёгкое
        # отдаление, чтобы было видно и карту, и запас под восьмёрку;
        # приближать/отдалять и двигать карту можно в любой момент.
        self.orbit_u = random.uniform(0, math.tau)
        self.orbit_deg = 0.0
        self.orbit_pan = [0.0, 0.0]
        self._pan_active = False
        self.hover_sprite.angle = 0.0
        if "fog" in challenges:
            # «ТУМАН»: камера приближена (и дальше не отдаляется) —
            # settings.FOG_ZOOM (число или словарь по сложностям)
            self.orbit_zoom = self._fog_zoom()
        elif "orbit" in challenges:
            a, bq = st.ORBIT_SIZE, st.ORBIT_SIZE * st.ORBIT_SQUASH
            fit = min((st.SCREEN_W - 80) / (self.grid.w + 2 * a),
                      (st.SCREEN_H - st.HUD_H - 72) / (self.grid.h + 2 * bq))
            self.orbit_zoom = max(st.ORBIT_ZOOM_MIN, min(1.0, fit))
        else:
            self.orbit_zoom = 1.0

        # Модули испытаний: три точки входа у каждого (challenges.py),
        # порядок кадра — ОРБИТА, ТАСОВКА, ФУГАС, затем БЛИЦ/ДИВЕРСАНТ.
        self.modules = chal.build_modules(self, challenges)

        self._build_field()
        if self._map_mode():
            self._orbit_apply()
        self._fog_build()
        self.state = "game"
        title = st.DIFFICULTIES[diff_index][1]
        titles = dict((k, t) for k, t, _, _ in st.CHALLENGES)
        if challenges:
            title = " + ".join(titles[k] for k in challenges) + " · " + title
        if "fog" in challenges:
            self._toast("ТУМАН! ПРОБЕЛ — лампа. Потряси мышкой — зарядить")
        elif "orbit" in challenges:
            self._toast("ОРБИТА! Колесо мыши — зум, Shift+ЛКМ — двигать карту")
        else:
            self._toast(title)
        self.sounds.play("click")

    def _restart(self):
        self.start_game(self.diff_index, list(self.challenges))

    # ---------- События испытаний (игра — «хаб») ----------

    def _fire_first_open(self, coord):
        """OnFirstCellOpened(): один раз после открытия первой ячейки."""
        for m in self.modules:
            m.on_first_cell_opened(coord)

    def _fire_cell_changed(self, coord, kind):
        """OnCellChanged(cell): открытие, флажок, взрыв одной клетки."""
        for m in self.modules:
            m.on_cell_changed(coord, kind)

    def _fire_board_changed(self, reason):
        """OnBoardChanged(): тасовка, взрыв фугаса — сдвиг всего поля."""
        for m in self.modules:
            m.on_board_changed(reason)

    def _build_field(self):
        """Спрайты клеток и рамки поля (arcade.SpriteList)."""
        b, V = self.board, self.grid
        tile = self.save.selected_tile.replace("t_", "", 1)
        self.cell_list.clear()
        self.overlay_list.clear()
        self.cell_sprites = {}
        self.flag_refs = []
        self._anim_local = {}   # локальные смещения анимации тасовки — сброс
        closed_t = self.assets.tile_closed(tile)
        closed2_t = self.assets.tile_closed2(tile)
        scale = self.cell / closed_t.width
        self._cell_base_scale = scale
        for y in range(b.rows):
            for x in range(b.cols):
                # шахматная раскладка: чётные диагонали — обычная клетка,
                # нечётные — тёмный вариант (t_<скин>_closed2.png)
                tex = closed_t if self._checker(x, y) == 0 else closed2_t
                sp = arcade.Sprite(tex, scale=scale)
                sp.position = V.center_arc(x, y)
                self.cell_sprites[(x, y)] = sp
                self.cell_list.append(sp)
        self._cell_states = {}
        self._sync_cells()
        self._frame_outer, self._frame_inner = ui.field_frame_points(V)
        # украшения и эффекты скина поля (трава, снег, перекати-поле, ...)
        self.field_fx = fieldfx.FieldFX(self, tile)

    def _checker(self, x, y):
        """Цвет закрытой клетки в шахматке: 0 — обычная, 1 — тёмная.
        Фаза checker_phase меняется при тасовке на нечётное число клеток,
        поэтому сдвинутая часть поля сохраняет свои цвета, а прилетевшая
        полоса продолжает тот же шахматный порядок."""
        return (x + y + self.checker_phase) % 2

    def closed_texture(self, x, y):
        """Текстура закрытой клетки (x, y) с учётом шахматки."""
        tile = self.save.selected_tile.replace("t_", "", 1)
        if self._checker(x, y) == 0:
            return self.assets.tile_closed(tile)
        return self.assets.tile_closed2(tile)

    def _tile_textures(self):
        tile = self.save.selected_tile.replace("t_", "", 1)
        return (self.assets.tile_closed(tile),
                self.assets.tile_closed2(tile),
                self.assets.tile_open(tile),
                self.assets.scorch)

    def _sync_cells(self):
        """Обновляем текстуры клеток по состоянию доски."""
        closed_t, closed2_t, open_t, _ = self._tile_textures()
        b = self.board
        for y in range(b.rows):
            for x in range(b.cols):
                c = b.cell(x, y)
                # цвет шахматки — часть состояния: кэш обязан знать, КАКАЯ
                # закрытая текстура нарисована, иначе после сдвига поля
                # перекраска не случится и шахматка собьётся
                if c.exploded:
                    # взорвалась НАСТОЯЩАЯ мина (не временная бомба фугаса):
                    # клетка чуть темнее и красная (settings.BOOM_CELL_*)
                    state = "boom"
                elif c.revealed:
                    state = "open"
                else:
                    state = "closed%d" % self._checker(x, y)
                if self._cell_states.get((x, y)) != state:
                    self._cell_states[(x, y)] = state
                    sp = self.cell_sprites[(x, y)]
                    if state == "boom":
                        tex = self.assets.tile_boom(
                            self.save.selected_tile.replace("t_", "", 1))
                    elif state == "open":
                        tex = open_t
                    elif state == "closed0":
                        tex = closed_t
                    else:
                        tex = closed2_t
                    sp.texture = tex
        self._sync_numbers()
        self._sync_overlays()
        # «ОРБИТА»: пересобранные спрайты (цифры, бомбы, флажки) обязаны
        # остаться приклеенными к карте — в том числе после взрыва/победы,
        # когда движение карты уже остановлено и _update_orbit молчит.
        if self._orbit_on():
            self._orbit_apply()

    def _sync_overlays(self):
        """Флажки и взорвавшиеся бомбы — спрайты поверх клеток."""
        b, V = self.board, self.grid
        self.overlay_list.clear()
        self.overlay_coords = []
        self.flag_refs = []
        bomb_tex = self.assets.bomb_icon(self.save.selected_bomb, 96)
        scale_b = self.cell * st.BOMB_SCALE / bomb_tex.width
        self._overlay_base_scales = []
        for y in range(b.rows):
            for x in range(b.cols):
                c = b.cell(x, y)
                if c.exploded and st.BOOM_LEAVE_BOMB:
                    tex = bomb_tex
                    sp = arcade.Sprite(tex, scale=scale_b)
                    sp.position = V.center_arc(x, y)
                    self.overlay_list.append(sp)
                    self.overlay_coords.append((x, y))
                    self._overlay_base_scales.append(scale_b)
                elif c.flagged and not c.exploded:
                    skin = self.save.selected_flag
                    frames = self.assets.flag_frames(skin)
                    tex = frames[0] if frames else self.assets.flag_icon(skin, 96)
                    sc = self.cell * 0.98 / tex.width
                    sp = arcade.Sprite(tex, scale=sc)
                    sp.position = V.center_arc(x, y)
                    self.overlay_list.append(sp)
                    self.overlay_coords.append((x, y))
                    self._overlay_base_scales.append(sc)
                    self.flag_refs.append((sp, skin))

    def cell_center(self, x, y):
        """Экранные координаты центра клетки (для эффектов), y вниз.
        В «Орбите» точка берётся с учётом вращения и смещения поля."""
        if self._orbit_on():
            wx, wy = self._orbit_local_to_world(*self.grid.center_arc(x, y))
            return (wx, st.SCREEN_H - wy)     # обратно в систему «y вниз»
        return self.grid.center(x, y)

    def _cell_at(self, pos):
        if self.board is None or self.grid is None:
            return None
        if self._orbit_on():
            lx, ly = self._orbit_pick(self.mouse_win)   # виртуальные, y вниз
            return self.grid.pick(lx, ly)
        # поле нарисовано со сдвигом параллакса — клик ищем с тем же сдвигом
        gx, gy = self.gpar
        return self.grid.pick(pos[0] - gx, pos[1] - gy)

    def _win_to_world_px(self, x, y):
        """Пиксели окна -> виртуальные координаты (y вверх) — мир «Орбиты»."""
        vx, vy = self._to_virtual(x, y)
        return (vx, st.SCREEN_H - vy)

    def _toast(self, s):
        self.toast_s = s
        self.toast_t = 2.0

    # ---------- Ввод ----------

    def on_mouse_motion(self, x, y, dx, dy):
        self.mouse_win = (x, y)
        self.mouse = self._to_virtual(x, y)
        if self._scroll_drag is not None:
            self._scroll_drag_to(self.mouse)
        # «ОРБИТА»: Shift+ЛКМ тянет саму карту — карта следует за курсором 1:1
        if self._pan_active and self._orbit_on():
            w = self._win_to_world_px(x, y)
            self.orbit_pan = [self._pan_orig[0] + w[0] - self._pan_grab[0],
                              self._pan_orig[1] + w[1] - self._pan_grab[1]]
            self._orbit_apply()   # карта едет целиком, даже после конца партии

    def on_mouse_press(self, x, y, button, modifiers):
        self.mouse_win = (x, y)
        pos = self._to_virtual(x, y)
        self.mouse = pos
        if button == arcade.MOUSE_BUTTON_LEFT:
            # «ОРБИТА»: Shift+ЛКМ — двигаем камеру, клик по клеткам отключён
            if (self._orbit_on() and (modifiers & arcade.key.MOD_SHIFT)
                    and not self.confirm_kind):
                if not self.overlay and not self.ended and not self.exploding:
                    if self._route_ui(pos, self.screens["game"]):
                        return
                self._pan_active = True
                self._pan_grab = self._win_to_world_px(x, y)
                self._pan_orig = tuple(self.orbit_pan)
                return
            self._left_click(pos)
        elif button == arcade.MOUSE_BUTTON_RIGHT:
            self._right_click(pos)

    def on_mouse_release(self, x, y, button, modifiers):
        if button == arcade.MOUSE_BUTTON_LEFT:
            self._pan_active = False
            self._scroll_drag = None

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        if self.state in ("shop", "inventory") and scroll_y and not self.confirm_kind:
            self._shop_wheel(self._to_virtual(x, y), scroll_y)
            return
        # колесо мыши приближает/отдаляет карту только в «Орбите»
        if (self._orbit_on() and scroll_y and not self.confirm_kind):
            self._orbit_zoom_at(x, y, st.ORBIT_WHEEL_STEP ** scroll_y)

    def on_key_release(self, key, modifiers):
        if key in (arcade.key.LSHIFT, arcade.key.RSHIFT):
            self._shift_down = False

    def on_key_press(self, key, modifiers):
        if key in (arcade.key.LSHIFT, arcade.key.RSHIFT):
            self._shift_down = True
        if key == arcade.key.F11:
            self._toggle_fullscreen()
        elif key == arcade.key.ESCAPE:
            if self.confirm_kind:
                self.confirm_kind = None
            elif self.state == "game" and (self.ended or self.exploding):
                pass
            elif self.state == "game":
                self._ask_menu()
            elif self.state == "difficulty":
                self._diff_back()            # сначала свернуть испытания
            elif self.state != "menu":
                self.goto("menu")
            else:
                self._ask_quit()
        elif key == arcade.key.SPACE and self.exploding:
            self._skip_explosions()
        elif key == arcade.key.SPACE and self._fog_on() and not self.confirm_kind:
            self._fog_toggle_lamp()
        elif key in (arcade.key.EQUAL, arcade.key.NUM_ADD):
            # приближение карты — только в «Орбите»
            if self._orbit_on() and not self.confirm_kind:
                self._orbit_zoom_at(st.SCREEN_W / 2, st.SCREEN_H / 2,
                                    st.ORBIT_KEY_STEP)
        elif key in (arcade.key.MINUS, arcade.key.NUM_SUBTRACT):
            if self._orbit_on() and not self.confirm_kind:
                self._orbit_zoom_at(st.SCREEN_W / 2, st.SCREEN_H / 2,
                                    1.0 / st.ORBIT_KEY_STEP)
        elif key == arcade.key.M:
            self.sounds.music_toggle()
            self._toast("Музыка включена" if self.sounds.music_on
                        else "Музыка выключена")
        elif self.state == "inventory" and not self.confirm_kind:
            # чит-код: набирается по буквам в инвентаре
            if ord("a") <= key <= ord("z"):
                self._cheat_buf = (self._cheat_buf + chr(key))[-len(st.CHEAT_CODE):]
                if self._cheat_buf == st.CHEAT_CODE:
                    self._cheat_buf = ""
                    self._unlock_all_skins()

    def _route_ui(self, pos, widgets):
        for w in reversed(widgets):
            # кнопки и карточки-галочки (у надписей hit нет)
            if hasattr(w, "hit") and w.hit(pos):
                if w.cb:
                    w.cb()
                return True
        return False

    def _left_click(self, pos):
        if self._pan_active:
            return                       # камера двигается — клики выключены
        if self.confirm_kind:
            self._route_ui(pos, self.screens["confirm"])
            return
        if self.state == "game":
            if self.overlay == "win":
                self._route_ui(pos, self.screens["win"])
                return
            if self.overlay == "lose":
                self._route_ui(pos, self.screens["lose"])
                return
            if self._route_ui(pos, self.screens["game"]):
                return
            if self.ended or self.exploding or self.shuffle_phase == "anim":
                return
            c = self._cell_at(pos)
            if c:
                self._open_cell(*c)
            return
        if self.state in st.SCROLL_SCREENS and self._scroll_press(pos):
            return
        self._route_ui(pos, self.screens[self.state])

    def _right_click(self, pos):
        if (self.state != "game" or self.confirm_kind or self.ended
                or self.exploding or self.shuffle_phase == "anim"):
            return
        if "noflags" in self.challenges:
            self._toast("В этом испытании флажки отключены")
            return
        c = self._cell_at(pos)
        if c and self.board.toggle_flag(*c):
            self.sounds.play("flag")
            self._sync_cells()
            self._fire_cell_changed(c, "flag")

    def _open_cell(self, x, y):
        b = self.board
        c = b.cell(x, y)
        if not b.mines_placed:
            b.place_mines(x, y)
            # OnFirstCellOpened(): модули включают свои механизмы
            # (фугас встаёт на взвод, тасовка запускает таймер)
            self._fire_first_open((x, y))
        if self.fugas_phase == "armed" and self._fugas_index((x, y)) >= 0:
            self._fugas_defuse((x, y))
            return
        if c.revealed:
            opened, mine = b.chord(x, y)
            if mine is not None:
                self._sync_cells()
                self._hit_mine(mine)
                return
            if opened:
                self.sounds.play("click")
                self._sync_cells()
                for coord in opened:
                    self._fire_cell_changed(coord, "open")
                self._check_win()
            return
        if c.flagged:
            return
        opened = b.reveal(x, y)
        if opened is None:
            self._sync_cells()
            self._hit_mine((x, y))
            return
        if opened:
            self.sounds.play("click")
        self._sync_cells()
        for coord in opened or ():
            self._fire_cell_changed(coord, "open")
        self._check_win()

    # ---------- Испытание «ФУГАС» ----------

    @property
    def fugas_bomb(self):
        """Клетка первой активной временной бомбы (или None)."""
        return self.fugas_bombs[0]["coord"] if self.fugas_bombs else None

    @property
    def fugas_sprite(self):
        """Спрайт первой активной временной бомбы (или None)."""
        return self.fugas_bombs[0]["sprite"] if self.fugas_bombs else None

    def _fugas_index(self, coord):
        for i, bomb in enumerate(self.fugas_bombs):
            if bomb["coord"] == coord:
                return i
        return -1

    def _fugas_cycle(self):
        """Шаг 1 розыгрыша: случайная секунда срабатывания 1..5."""
        self.fugas_phase = "waiting"
        self.fugas_t = float(random.randint(1, st.FUGAS_CYCLE_MAX))

    def _make_temp_bomb(self, coord):
        """Временная бомба того же размера, что и настоящие
        (cell * BOMB_SCALE), + красная копия поверх — ею бомба «краснеет»."""
        skin = self.save.selected_bomb
        tex = self.assets.bomb_icon(skin, 96)
        scale = self.cell * st.BOMB_SCALE / tex.width
        sp = arcade.Sprite(tex, scale=scale)
        red = arcade.Sprite(self.assets.bomb_red(skin), scale=scale)
        red.alpha = 0
        return {"coord": coord, "sprite": sp, "red": red, "scale": scale,
                "age": 0.0, "seed": random.uniform(0.0, math.tau)}

    def _fugas_spawn(self, count=None):
        """Шаг 4: временная бомба на случайной уже открытой клетке
        (с шансом FUGAS_DOUBLE_CHANCE — сразу две). Если до тасовки
        осталось меньше SHUFFLE_FUGAS_GUARD секунд, клетки будущей зоны
        тасовки исключаются — тасовка бомбу не собьёт."""
        danger = self._shuffle_danger_zone()
        opened = [(x, y) for y in range(self.board.rows)
                  for x in range(self.board.cols)
                  if self.board.cell(x, y).revealed
                  and not self.board.cell(x, y).exploded
                  and (x, y) not in danger]
        if not opened:
            self._fugas_cycle()
            return
        if count is None:
            count = 2 if random.random() < st.FUGAS_DOUBLE_CHANCE else 1
        count = max(1, min(int(count), len(opened)))
        coords = random.sample(opened, count)
        self.fugas_bombs = [self._make_temp_bomb(c) for c in coords]
        self.fugas_phase = "armed"
        self.fugas_t = st.FUGAS_FUSE
        self.fugas_blink = 0.0
        if self.fugas_text is None:
            self.fugas_text = arcade.Text(
                "", 0, 0, (255, 255, 255, 255), ui.ps(15),
                font_name="DejaVu Sans", bold=True,
                anchor_x="center", anchor_y="center")
            self.fugas_text_shadow = arcade.Text(
                "", 0, 0, (20, 6, 6, 220), ui.ps(15),
                font_name="DejaVu Sans", bold=True,
                anchor_x="center", anchor_y="center")
        size = ui.ps(max(12, int(self.cell * 0.42)))
        self.fugas_text.font_size = size
        self.fugas_text_shadow.font_size = size
        self.sounds.play("click")
        if count > 1:
            self._toast("ДВОЙНОЙ ФУГАС! Обезвредь обе бомбы!")
        else:
            self._toast("ФУГАС! Обезвредь бомбу — кликни по ней!")

    def _fugas_defuse(self, coord=None):
        """Успешный клик: бомба исчезла, ячейка открыта. Когда обезврежены
        все бомбы розыгрыша — цикл заново (шаг 1)."""
        i = self._fugas_index(coord) if coord is not None else 0
        if i < 0 or not self.fugas_bombs:
            return
        bomb = self.fugas_bombs.pop(i)
        x, y = bomb["coord"]
        cx, cy = self.cell_center(x, y)
        for _ in range(9):
            a = random.uniform(0, math.tau)
            sp = random.uniform(40, 130)
            life = random.uniform(0.25, 0.5)
            self.particles.append([
                cx, cy, math.cos(a) * sp, math.sin(a) * sp - 40,
                life, life, random.uniform(1.5, 3.5), (150, 230, 160)])
        self.sounds.play("flag")
        if not self.fugas_bombs:
            self._fugas_cycle()

    def _fugas_explode(self):
        """Фитиль догорел: взрываются все оставшиеся бомбы розыгрыша
        (эффект + перемешивание зоны 3×3). Затем с шансом
        FUGAS_CHAIN_CHANCE новая бомба появляется сразу же, иначе —
        кулдаун FUGAS_COOLDOWN."""
        bombs, self.fugas_bombs = self.fugas_bombs, []
        for bomb in bombs:
            x, y = bomb["coord"]
            # анимация взрыва на бомбе + бомба рассыпается на осколки
            self._spawn_boom((x, y), 1.0)
            self.board.reshuffle_zone(x, y)
        self.shake = max(self.shake, 6.0)
        self.sounds.play(random.choice(["boom1", "boom2", "boom3"]), 0.8)
        self._sync_cells()
        # OnBoardChanged(): поле изменилось (зона 3×3 закрыта и перемешана)
        self._fire_board_changed("fugas_boom")
        if random.random() < st.FUGAS_CHAIN_CHANCE:
            self._fugas_spawn()           # бомба сразу же после взрыва
            if self.fugas_phase == "armed":
                self._toast("ВЗРЫВ! И сразу новый фугас — кликни!")
                return
        self.fugas_phase = "cooldown"
        self.fugas_t = st.FUGAS_COOLDOWN
        self._toast("ВЗРЫВ! Зона 3×3 закрыта, мины перемешаны")

    # ---------- Испытание «ТАСОВКА» ----------

    def _shuffle_pick(self):
        """Случайные параметры тасовки: ориентация (50/50: вертикальная —
        тасуем столбцы, горизонтальная — строки), ширина зоны по таблице
        шансов для срезаемой стороны, сторона улёта (50/50). Полоса всегда
        улетает через свой край экрана — навстречу ей с противоположной
        стороны прилетает новая."""
        b = self.board
        vertical = random.random() < 0.5
        n = b.cols if vertical else b.rows
        widths, weights = st.shuffle_width_table(n)
        k = max(1, min(int(random.choices(widths, weights=weights)[0]), n - 1))
        side = "high" if random.random() < 0.5 else "low"
        return vertical, k, side

    def _plan_shuffle(self):
        """Таймер тасовки запущен — СРАЗУ решаем, где будет следующая
        тасовка. Зная зону заранее, «Фугас» не сажает на неё бомбы в
        последние SHUFFLE_FUGAS_GUARD секунд, и тасовка их не сбивает."""
        self.shuffle_plan = self._shuffle_pick()
        self.shuffle_zone = frozenset(self._strip_coords(*self.shuffle_plan))

    def _shuffle_danger_zone(self):
        """Клетки, куда сейчас нельзя ставить временную бомбу: зона
        ближайшей тасовки, если до неё меньше SHUFFLE_FUGAS_GUARD секунд
        (и не меньше фитиля бомбы + запас — бомба успеет догореть)."""
        if "shuffle" not in self.challenges or self.shuffle_phase != "waiting":
            return frozenset()
        guard = max(st.SHUFFLE_FUGAS_GUARD, st.FUGAS_FUSE + 0.5)
        if self.shuffle_t > guard:
            return frozenset()
        return self.shuffle_zone

    def _strip_coords(self, vertical, k, side):
        """Координаты клеток улетевшей полосы (до тасовки)."""
        b = self.board
        if vertical:
            xs = range(b.cols - k, b.cols) if side == "high" else range(k)
            return [(x, y) for y in range(b.rows) for x in xs]
        ys = range(b.rows - k, b.rows) if side == "high" else range(k)
        return [(x, y) for y in ys for x in range(b.cols)]

    def _shuffle_start(self):
        """Таймер истёк: запускаем тасовку. Логика меняется мгновенно
        («за картой»), спрайты летят по фазам: вылет -> сдвиг + прилёт.
        Анимация всегда работает в ЛОКАЛЬНЫХ координатах поля, поэтому
        «Орбита» может продолжать крутить и двигать карту целиком."""
        b, V, S = self.board, self.grid, self.cell
        # зона выбрана заранее — при запуске таймера (_plan_shuffle)
        plan = self.shuffle_plan or self._shuffle_pick()
        self.shuffle_plan = None
        self.shuffle_zone = frozenset()
        vertical, k, side = plan
        n_side = b.cols if vertical else b.rows
        k = max(1, min(int(k), n_side - 1))
        strip = self._strip_coords(vertical, k, side)
        strip_set = set(strip)
        d = k if side == "high" else -k     # сдвиг оставшейся части

        # OnBoardChanged("shuffle_start"): уезжающая зона обнуляется; фугас
        # снимает бомбы только в ней, остальные едут вместе с полем
        self.shuffle_last = {"vertical": vertical, "k": k, "side": side,
                             "d": d, "strip": frozenset(strip_set)}
        self._fire_board_changed("shuffle_start")

        # 1) снимок спрайтов улетевшей полосы: клетки, флажки, цифры
        #    (локальные точки поля, не экрана — карта может быть повёрнута)
        #    out_meta: крутится ли спрайт вместе с картой (клетки — да,
        #    флажки и цифры — вертикальные) и его базовый масштаб
        out = []
        out_meta = {}
        for coord in strip:
            sp = self.cell_sprites.pop(coord, None)
            self._cell_states.pop(coord, None)
            lx, ly = V.center_arc(*coord)
            if sp:
                self.cell_list.remove(sp)
                out.append((sp, lx, ly))
                out_meta[id(sp)] = (True, self._cell_base_scale)
        for sp, coord, base in list(zip(self.overlay_list, self.overlay_coords,
                                        self._overlay_base_scales)):
            if coord in strip_set:
                self.overlay_list.remove(sp)
                out.append((sp, V.center_arc(*coord)[0], V.center_arc(*coord)[1]))
                out_meta[id(sp)] = (False, base)
        for sp, coord, base in list(zip(self.num_list, self.num_coords,
                                        self._num_base_scales)):
            if coord in strip_set:
                self.num_list.remove(sp)
                out.append((sp, V.center_arc(*coord)[0], V.center_arc(*coord)[1]))
                out_meta[id(sp)] = (False, base)

        # 2) логика: обмен полос; авт-открытие безопасной клетки в новой
        #    полосе — тоже «за картой», пока идёт анимация (и даже если
        #    поле в этот момент крутится — открытие работает как обычно)
        slot = b.shuffle_swap(vertical, k, side)
        b.shuffle_auto_open(slot)

        # 3) спрайты: оставшаяся часть получает новые ключи (сдвиг),
        #    для новой полосы создаются свежие клетки. Кэш состояний
        #    (_cell_states) обязан переехать вместе со спрайтами: он должен
        #    отражать то, что реально нарисовано, иначе _sync_cells сочтёт
        #    перекраску ненужной, и открытые клетки будут выглядеть закрытыми
        #    Шахматка: сдвиг на нечётное число клеток меняет фазу — так
        #    сдвинутые клетки сохраняют свой цвет, а новая полоса
        #    продолжает тот же шахматный порядок (раньше на нечётных
        #    сдвигах шахматка сбивалась)
        self.checker_phase = (self.checker_phase - d) % 2
        new_map = {}
        new_states = {}
        for (x, y), sp in self.cell_sprites.items():
            nk = (x + d, y) if vertical else (x, y + d)
            new_map[nk] = sp
            new_states[nk] = self._cell_states.get((x, y))
        for coord in slot:
            # свежий спрайт действительно закрыт — и своего цвета шахматки
            new_states[coord] = "closed%d" % self._checker(*coord)
        self.cell_sprites = new_map
        self._cell_states = new_states
        tile = self.save.selected_tile.replace("t_", "", 1)
        closed_t = self.assets.tile_closed(tile)
        scale = S / closed_t.width
        for coord in slot:
            tex = self.closed_texture(*coord)
            sp = arcade.Sprite(tex, scale=scale)
            sp.position = V.center_arc(*coord)
            self.cell_sprites[coord] = sp
            self.cell_list.append(sp)

        # 4) синхронизируем поле с новым состоянием (текстуры, флажки,
        #    цифры — все в итоговых позициях)
        self._sync_cells()

        # 5) группы анимации; векторы в виртуальных координатах (y вниз),
        #    для arcade вертикаль переворачивается. Векторы задают смещение
        #    в локальных координатах поля: улетевшая полоса уходит за край
        #    КАРТЫ, а не экрана — трансформация карты переносит её сама.
        out_v, slide_v, enter_v = st.shuffle_vecs(
            b.cols, b.rows, S, V.ox, V.oy, vertical, k, side)
        ov = (out_v[0], -out_v[1])
        sv = (slide_v[0], -slide_v[1])
        ev = (enter_v[0], -enter_v[1])
        if self._orbit_on():
            # карта повёрнута/уменьшена/смещена: «до края экрана» в
            # локальных координатах не хватает — полоса пропадала прямо
            # на экране. Берём дистанцию, гарантирующую уход за кадр.
            ov, ev = self._shuffle_offscreen_vecs(ov, ev, vertical)

        slot_set = set(slot)
        slide = []
        for coord, sp in self.cell_sprites.items():
            if coord not in slot_set:
                fx, fy = V.center_arc(*coord)   # финальная позиция клетки
                slide.append((sp, fx, fy))
        for sp, coord in zip(self.overlay_list, self.overlay_coords):
            if coord not in slot_set:
                fx, fy = V.center_arc(*coord)
                slide.append((sp, fx, fy))
        for sp, coord in zip(self.num_list, self.num_coords):
            if coord not in slot_set:
                fx, fy = V.center_arc(*coord)
                slide.append((sp, fx, fy))
        arrive = []
        for c in slot:
            sp = self.cell_sprites[c]
            fx, fy = V.center_arc(*c)
            arrive.append((sp, fx, fy))
        for sp, coord in zip(self.num_list, self.num_coords):
            if coord in slot_set:
                fx, fy = V.center_arc(*coord)
                arrive.append((sp, fx, fy))

        # стартовые позиции: оставшаяся часть ещё на старом месте,
        # новая полоса — целиком за краем карты с противоположной стороны
        self._anim_local = {}
        for sp, x, y in slide:
            self._place(sp, x - sv[0], y - sv[1])
            self._anim_local[id(sp)] = (x - sv[0], y - sv[1])
        for sp, x, y in arrive:
            self._place(sp, x - ev[0], y - ev[1])
            self._anim_local[id(sp)] = (x - ev[0], y - ev[1])

        self.shuffle_anim = {
            "stage": "out", "t": 0.0, "out": out, "out_meta": out_meta,
            "slide": slide, "arrive": arrive, "ov": ov, "sv": sv, "ev": ev,
            "slot": slot,
        }
        self.shuffle_phase = "anim"
        self.hover = None
        self._hover_on = False
        self.sounds.play("click")
        self._toast("ТАСОВКА!")

    def _shuffle_offscreen_vecs(self, ov, ev, vertical):
        """«ОРБИТА»: векторы вылета/прилёта такой длины, что полоса
        гарантированно уходит ЗА КАДР и прилетает ИЗ-ЗА КАДРА при любом
        повороте карты. Критерий не зависит от угла: точка дальше от центра
        карты, чем самый дальний угол экрана, — точно за экраном. Запас
        покрывает движение по восьмёрке за время анимации, размер клетки,
        тряску и параллакс. Направления (вдоль осей карты) — прежние."""
        mx, my = self._orbit_map_center()
        z = max(1e-3, self.orbit_zoom)
        far = max(math.hypot(px - mx, py - my)
                  for px in (0.0, float(st.SCREEN_W))
                  for py in (0.0, float(st.SCREEN_H)))
        drift = (math.hypot(st.ORBIT_SIZE, st.ORBIT_SIZE * st.ORBIT_SQUASH)
                 * st.ORBIT_MOVE_SPEED * (st.SHUFFLE_FLY_T + st.SHUFFLE_SWAP_T))
        margin = (drift + self.cell * z + st.SHUFFLE_MARGIN
                  + st.GAME_PARALLAX_MAX + 8.0)
        half = (self.grid.w if vertical else self.grid.h) / 2.0
        dist = (far + margin) / z + half      # локальные px

        def stretch(v):
            n = math.hypot(v[0], v[1])
            if n < 1e-9:
                return v
            k = max(1.0, dist / n)            # только удлиняем
            return (v[0] * k, v[1] * k)

        return stretch(ov), stretch(ev)

    @staticmethod
    def _ease_in(p):
        """Плавный разгон (кубический): мягкий старт, быстрый уход."""
        p = max(0.0, min(1.0, p))
        return p * p * p

    @staticmethod
    def _ease_out(p):
        """Плавное торможение (кубическое): долгий мягкий довод до места."""
        p = max(0.0, min(1.0, p))
        return 1.0 - (1.0 - p) ** 3

    def _update_shuffle_anim(self, dt):
        """Фаза 1 «улетает» -> сразу фаза 2 «сдвиг оставшейся части +
        прилёт новой» (без пауз, как портал). Все позиции — локальные
        координаты поля: карта «Орбиты» в это время крутится и едет."""
        a = self.shuffle_anim
        if a is None:
            self.shuffle_phase = "waiting"
            self.shuffle_t = st.SHUFFLE_INTERVAL
            self._plan_shuffle()
            return
        a["t"] += dt
        if a["stage"] == "out":
            p = self._ease_in(a["t"] / st.SHUFFLE_FLY_T)
            dx, dy = a["ov"][0] * p, a["ov"][1] * p
            orbit = self._orbit_on()
            meta = a.get("out_meta", {})
            for sp, x, y in a["out"]:
                self._place(sp, x + dx, y + dy)
                if orbit:
                    # улетающие клетки повёрнуты ВМЕСТЕ с картой (раньше
                    # угол замирал, и клетки крутились вокруг своей оси)
                    rot, base = meta.get(id(sp), (False, None))
                    if rot:
                        sp.angle = -self.orbit_deg
                    if base is not None:
                        sp.scale = base * self.orbit_zoom
            if a["t"] >= st.SHUFFLE_FLY_T:
                a["stage"] = "in"
                a["t"] = 0.0
                a["out"] = []            # улетевшие больше не нужны
            return
        p = self._ease_out(a["t"] / st.SHUFFLE_SWAP_T)
        q = 1.0 - p
        for sp, x, y in a["slide"]:
            lx, ly = x - a["sv"][0] * q, y - a["sv"][1] * q
            self._place(sp, lx, ly)
            self._anim_local[id(sp)] = (lx, ly)
        for sp, x, y in a["arrive"]:
            lx, ly = x - a["ev"][0] * q, y - a["ev"][1] * q
            self._place(sp, lx, ly)
            self._anim_local[id(sp)] = (lx, ly)
        if a["t"] >= st.SHUFFLE_SWAP_T:
            self._shuffle_finish()

    def _shuffle_finish(self):
        """Тасовка завершена: всё на итоговых местах, таймер — заново."""
        a = self.shuffle_anim
        if a:
            for sp, x, y in a["slide"] + a["arrive"]:
                self._place(sp, x, y)
            a["out"] = []
        self._anim_local = {}
        self.shuffle_anim = None
        self.shuffle_phase = "waiting"
        self.shuffle_t = st.SHUFFLE_INTERVAL
        self._plan_shuffle()     # зона следующей тасовки — сразу
        self._sync_cells()
        # OnBoardChanged("shuffle_end"): фугас запускает свой цикл заново
        self._fire_board_changed("shuffle_end")
        self._check_win()   # авт-открытие могло открыть последнее безопасное

    def _shuffle_abort(self):
        """Партия закончилась посреди анимации — мгновенно доводим тасовку."""
        if self.shuffle_phase == "anim":
            self._shuffle_finish()

    # ---------- Испытание «ОРБИТА» ----------

    def _map_mode(self):
        """Карта — единое целое со своей трансформацией (зум, сдвиг,
        поворот): в «Орбите» и в «Тумане» (там камера чуть приближена)."""
        return "orbit" in self.challenges or "fog" in self.challenges

    def _orbit_on(self):
        """Трансформация карты активна: выбрана «Орбита» и/или «Туман»
        (в соединении — тоже). Движение по восьмёрке — только в «Орбите»."""
        return self.state == "game" and self._map_mode()

    def _zoom_min(self):
        """Предел отдаления: в «Тумане» дальше стартового зума нельзя."""
        if "fog" in self.challenges:
            return self._fog_zoom()
        return st.ORBIT_ZOOM_MIN

    def _fog_zoom(self):
        """Стартовый (и минимальный) зум «Тумана» для текущей сложности."""
        return st.fog_zoom(st.DIFFICULTIES[self.diff_index][0])

    def _orbit_params(self):
        """Геометрия «Орбиты» в виртуальных координатах (y вверх):
        центр поля, угол вращения (рад) и смещение по восьмёрке."""
        V = self.grid
        cx = V.ox + V.w / 2.0
        cy = st.SCREEN_H - (V.oy + V.h / 2.0)
        if "orbit" not in self.challenges:
            return cx, cy, 0.0, 0.0, 0.0      # «Туман» без «Орбиты»: карта стоит
        th = math.radians(self.orbit_deg)
        a = st.ORBIT_SIZE
        bq = a * st.ORBIT_SQUASH
        ox = a * math.cos(self.orbit_u)
        oy = bq * math.sin(self.orbit_u) * math.cos(self.orbit_u)
        if "fog" in self.challenges:
            # «Туман» + «Орбита»: камера чуть-чуть следует за картой —
            # карта уезжает по восьмёрке не так далеко
            k = 1.0 - st.FOG_FOLLOW
            ox, oy = ox * k, oy * k
        return cx, cy, th, ox, oy

    def _orbit_map_center(self):
        """Точка экрана, где сейчас центр карты (y вверх)."""
        cx, cy, th, ox, oy = self._orbit_params()
        return (cx + ox + self.orbit_pan[0],
                cy + oy + self.orbit_pan[1])

    def _orbit_local_to_world(self, x, y):
        """Локальная точка поля (y вверх) -> точка экрана: поворот карты
        вокруг её центра, масштаб зумом, плюс восьмёрка и перетаскивание."""
        cx, cy, th, ox, oy = self._orbit_params()
        mx = cx + ox + self.orbit_pan[0]
        my = cy + oy + self.orbit_pan[1]
        dx, dy = x - cx, y - cy
        c, s = math.cos(th), math.sin(th)
        z = self.orbit_zoom
        return (mx + z * (dx * c - dy * s), my + z * (dx * s + dy * c))

    def _orbit_world_to_local(self, x, y):
        """Точка экрана (y вверх) -> локальная точка поля (обратное)."""
        cx, cy, th, ox, oy = self._orbit_params()
        mx = cx + ox + self.orbit_pan[0]
        my = cy + oy + self.orbit_pan[1]
        dx = (x - mx) / self.orbit_zoom
        dy = (y - my) / self.orbit_zoom
        c, s = math.cos(th), -math.sin(th)
        return (cx + dx * c - dy * s, cy + dx * s + dy * c)

    def _orbit_pick(self, win_xy):
        """Пиксели окна -> клеточные координаты поля (y вниз)."""
        vx, vy = self._to_virtual(*win_xy)
        vx, vy = vx - self.gpar[0], vy - self.gpar[1]   # параллакс карты
        lx, ly = self._orbit_world_to_local(vx, st.SCREEN_H - vy)
        return lx, st.SCREEN_H - ly

    def _orbit_zoom_at(self, win_x, win_y, factor):
        """Зум вокруг точки экрана: точка карты под курсором не съезжает."""
        vx, vy = self._to_virtual(win_x, win_y)
        vx, vy = vx - self.gpar[0], vy - self.gpar[1]   # параллакс карты
        w = (vx, st.SCREEN_H - vy)
        z0 = self.orbit_zoom
        z1 = max(self._zoom_min(), min(st.ORBIT_ZOOM_MAX, z0 * factor))
        if z1 == z0:
            return
        m = self._orbit_map_center()
        k = z1 / z0
        m1 = (w[0] + (m[0] - w[0]) * k, w[1] + (m[1] - w[1]) * k)
        self.orbit_pan = [self.orbit_pan[0] + m1[0] - m[0],
                          self.orbit_pan[1] + m1[1] - m[1]]
        self.orbit_zoom = z1
        self._orbit_apply()   # зум работает и после конца партии

    def _cam_begin(self, sx=0.0, sy=0.0):
        """Letterbox-камера перед отрисовкой: только тряска. Зум/панорама
        «Орбиты» — часть трансформации самой карты, камера их не трогает."""
        self.cam.zoom = 1.0
        self.cam.position = (-sx, -sy)

    def _place(self, sp, lx, ly):
        """Поставить спрайт в локальную точку поля. Без «Орбиты» это просто
        координаты сетки; с «Орбитой» — через трансформацию карты: крутится
        и едет КАРТА целиком, спрайты приклеены к ней."""
        if self._orbit_on():
            sp.position = self._orbit_local_to_world(lx, ly)
        else:
            sp.position = (lx, ly)

    def _sprite_local(self, sp, coord):
        """Локальная точка спрайта: центр клетки, либо смещённая точка,
        если спрайт сейчас летит в анимации тасовки (тасовка работает
        в локальных координатах, поэтому совместима с «Орбитой»)."""
        return self._anim_local.get(id(sp)) or self.grid.center_arc(*coord)

    def _orbit_apply(self):
        """Расставить спрайты по текущему положению карты. Карта — единое
        целое: клетки и рамка вращаются вместе с ней (общий поворот вокруг
        центра карты), а цифры и флажки остаются вертикальными — крутится
        карта, а не содержимое клеток. Летящие в тасовке спрайты берут
        локальную точку из _anim_local — они тоже приклеены к карте."""
        V = self.grid
        deg = -self.orbit_deg     # текстура arcade: плюс крутит по часовой
        z = self.orbit_zoom
        for (x, y), sp in self.cell_sprites.items():
            sp.position = self._orbit_local_to_world(
                *self._sprite_local(sp, (x, y)))
            sp.angle = deg
            sp.scale = self._cell_base_scale * z
        for sp, base, (x, y) in zip(self.overlay_list,
                                    self._overlay_base_scales,
                                    self.overlay_coords):
            sp.position = self._orbit_local_to_world(
                *self._sprite_local(sp, (x, y)))
            sp.scale = base * z   # флажки и бомбы — вертикальные
        for sp, base, (x, y) in zip(self.num_list,
                                    self._num_base_scales,
                                    self.num_coords):
            sp.position = self._orbit_local_to_world(
                *self._sprite_local(sp, (x, y)))
            sp.scale = base * z   # цифры — вертикальные
        self._orbit_frame = (
            [self._orbit_local_to_world(px, py) for px, py in self._frame_outer],
            [self._orbit_local_to_world(px, py) for px, py in self._frame_inner])

    # ---------- Испытание «ТУМАН» ----------

    def _fog_on(self):
        return self.state == "game" and "fog" in self.challenges

    def _fog_hidden(self, coord):
        """Клетка сейчас под туманом (подсветку рисуем поверх него)."""
        return (self._fog_on() and bool(self.fog_clouds)
                and self.fog_alpha.get(coord, 0.0) * (1 - self.fog_lift) > 0.5)

    def _fog_build(self):
        """Сплошной туман: много крупных мягких облаков (≈FOG_BLOB клетки)
        на «дрожащей» сетке с шагом FOG_STEP — они сильно перекрываются,
        поэтому клеток под туманом не видно. Облака приклеены к карте
        (едут с ней, крутятся, зумятся), сами медленно клубятся; за краем
        поля туман плавно редеет. Поверх дрейфуют широкие гряды."""
        self.fog_list = arcade.SpriteList()
        self.fog_wisp_list = arcade.SpriteList()
        self.fog_clouds = []     # облака тумана (словари)
        self.fog_alpha = {}      # coord -> плотность тумана в центре клетки 0..1
        self.fog_out = []        # облака над улетающей полосой тасовки
        self.fog_wisps = []
        self.fog_lamp = False
        self.fog_lamp_k = 0.0    # плавное появление лампы 0..1
        self.fog_light = None    # где свет лампы (мир, y вверх)
        self.fog_lift = 0.0      # конец партии: туман рассеялся 0..1
        self.fog_t = 0.0
        self.lamp_angle = 0.0
        self._lamp_prev = None
        # заряд лампы 1 -> 0 (LAMP_BURN_T), на нуле — гаснет; зажечь снова —
        # потрясти мышкой (ShakeDetector)
        self.lamp_charge = 1.0
        self.lamp_dead = False
        self.lamp_flare = 0.0
        self.lamp_shake = ShakeDetector()
        self.fog_screen = []     # облака по всему экрану (вне карты тоже)
        self.fog_screen_list = arcade.SpriteList()
        if "fog" not in self.challenges or self.grid is None:
            return
        V = self.grid
        rng = random.Random(V.cols * 1000 + V.rows)
        texs = self.assets.fog_clouds
        step, mg = st.FOG_STEP, st.FOG_MARGIN
        ny = int(math.ceil((V.rows + 2 * mg) / step)) + 1
        nx = int(math.ceil((V.cols + 2 * mg) / step)) + 1
        for j in range(ny):
            for i in range(nx):
                u = -mg + (i + 0.5 * (j % 2)) * step + rng.uniform(-0.3, 0.3) * step
                v = -mg + j * step + rng.uniform(-0.3, 0.3) * step
                out = max(0.0, -u, u - V.cols, -v, v - V.rows)
                edge = 1.0 - _smooth(0.0, mg + 0.4, out)
                if edge <= 0.02:
                    continue
                sp = arcade.Sprite(texs[rng.randrange(len(texs))])
                self.fog_list.append(sp)
                self.fog_clouds.append({
                    "sp": sp, "u": u, "v": v, "edge": edge, "m": 1.0,
                    "ph": rng.uniform(0.0, math.tau), "rot": rng.uniform(0.0, 360.0),
                    "size": st.FOG_BLOB * rng.uniform(0.85, 1.15),
                    "lum": rng.uniform(0.9, 1.0)})
        for y in range(V.rows):
            for x in range(V.cols):
                self.fog_alpha[(x, y)] = 1.0
        for i in range(st.FOG_WISPS):
            sp = arcade.Sprite(self.assets.fog_wisp)
            self.fog_wisp_list.append(sp)
            self.fog_wisps.append({
                "sp": sp, "u": rng.uniform(-0.2, 1.2), "v": rng.uniform(0.05, 0.95),
                "du": rng.uniform(0.010, 0.022) * rng.choice((-1, 1)),
                "size": rng.uniform(4.5, 7.0), "ph": rng.uniform(0, math.tau),
                "m": 1.0})
        self._fog_build_screen(rng)
        self.lamp_sprite = arcade.Sprite(self.assets.lamp)
        self.lamp_glow_sprite = arcade.Sprite(self.assets.lamp_glow)
        self.lamp_glow_top = arcade.Sprite(self.assets.lamp_glow)
        self.fog_dark_sprite = arcade.Sprite(self.assets.fog_dark)
        # виньетка: строится по FOG_VIGNETTE_SIZE; None — берём
        # sprites/fog_vignette.png как есть
        vsize = getattr(st, "FOG_VIGNETTE_SIZE", None)
        self.fog_vignette_sprite = arcade.Sprite(
            self.assets.vignette(vsize) if vsize is not None
            else self.assets.fog_vignette)
        self._fog_place()

    def _fog_build_screen(self, rng):
        """Туман по всему экрану — по бокам и сверху от карты тоже.
        Облака стоят в координатах экрана (карта может ехать и крутиться
        под ними), крупнее и реже облаков карты (FOG_SCREEN_STEP клеток);
        у лампы они тоже расходятся."""
        self.fog_screen = []
        self.fog_screen_list = arcade.SpriteList()
        if st.FOG_SCREEN <= 0.0:
            return
        cell = self.grid.S * self.orbit_zoom
        # не мельче ~96 px: на мелких клетках облаков иначе слишком много
        step = max(96.0, cell * st.FOG_SCREEN_STEP)
        mg = 1.4 * step
        self.fog_screen_step = step
        nx = int(math.ceil((st.SCREEN_W + 2 * mg) / step)) + 1
        ny = int(math.ceil((st.SCREEN_H + 2 * mg) / step)) + 1
        texs = self.assets.fog_clouds
        for j in range(ny):
            for i in range(nx):
                x = -mg + (i + 0.5 * (j % 2)) * step + rng.uniform(-0.3, 0.3) * step
                y = -mg + j * step + rng.uniform(-0.3, 0.3) * step
                sp = arcade.Sprite(texs[rng.randrange(len(texs))])
                self.fog_screen_list.append(sp)
                self.fog_screen.append({
                    "sp": sp, "x": x, "y": y, "m": 1.0,
                    "ph": rng.uniform(0.0, math.tau), "rot": rng.uniform(0.0, 360.0),
                    "size": step * 2.6 * rng.uniform(0.9, 1.1),     # px
                    "lum": rng.uniform(0.86, 0.97)})

    def _fog_toggle_lamp(self):
        """ПРОБЕЛ: лампа в курсоре вкл/выкл (во время партии). Погасшую
        (заряд кончился) пробелом не зажечь — только потрясти мышкой."""
        if self.ended or self.exploding or not self.fog_clouds:
            return
        if self.lamp_dead and not self.fog_lamp:
            self._toast("Лампа погасла — потряси мышкой!")
            return
        self.fog_lamp = not self.fog_lamp
        self.sounds.play("click")

    def _lamp_relight(self):
        """Тряхнули мышкой: лампа снова горит в полную силу."""
        self.lamp_charge = 1.0
        self.lamp_dead = False
        self.fog_lamp = True
        self.lamp_flare = 1.0
        self.sounds.play("click")
        self._toast("Лампа снова горит!")

    def _lamp_recharge(self):
        """Тряхнули мышкой, когда лампа ещё горит (или выключена с зарядом):
        заряд снова полный — в ЛЮБОЙ момент, без надписей, только свет
        вспыхивает. Погасшую лампу зажигает _lamp_relight."""
        if self.lamp_dead:
            self._lamp_relight()
            return
        was_on = self.fog_lamp
        if was_on and self.lamp_charge >= 0.999:
            return
        self.lamp_charge = 1.0
        self.fog_lamp = True
        self.lamp_flare = 1.0
        self.sounds.play("click")

    def _lamp_burn(self, dt):
        """Лампа горит — заряд тает; на нуле гаснет (нужна тряска)."""
        if not self.fog_lamp or self.ended or self.exploding:
            return
        self.lamp_charge = max(0.0, self.lamp_charge - dt / max(0.1, st.LAMP_BURN_T))
        if self.lamp_charge <= 0.0:
            self.fog_lamp = False
            self.lamp_dead = True
            self._toast("Лампа погасла — потряси мышкой!")

    def _lamp_r(self):
        """Доля полного радиуса света сейчас: сжимается вместе с зарядом
        до LAMP_DIM_R; после подзарядки тряской — короткая вспышка."""
        return (st.LAMP_DIM_R + (1.0 - st.LAMP_DIM_R) * self.lamp_charge
                + 0.12 * max(0.0, self.lamp_flare))

    def _lamp_glow(self):
        """Доля полной яркости света: тускнеет вместе с зарядом; под
        конец (заряд < 15 %) лампа ещё и мерцает, будто вот-вот погаснет."""
        c = self.lamp_charge
        g = st.LAMP_DIM_GLOW + (1.0 - st.LAMP_DIM_GLOW) * c
        if c < 0.15:
            t = self.fog_t
            g *= 1.0 - (0.15 - c) / 0.15 * 0.45 * (
                0.5 + 0.5 * math.sin(t * 31.0) * math.sin(t * 17.0 + 1.3))
        return g

    def _lamp_ang(self):
        """Угол фонаря (по часовой, градусы): качание + лёгкое покачивание."""
        return self.lamp_angle + 3.0 * math.sin(self.fog_t * 2.2)

    def _lamp_light_screen(self):
        """Где светится стекло фонаря на экране (y вверх): ручка — ровно на
        кончике курсора, стекло — ниже по оси фонаря."""
        px = self.mouse[0] + st.LAMP_OFFSET[0]
        py = ui.Y(self.mouse[1] + st.LAMP_OFFSET[1])
        r = math.radians(self._lamp_ang())
        L = st.LAMP_H * st.LAMP_LIGHT
        return px - L * math.sin(r), py - L * math.cos(r)

    def _lamp_light_world(self):
        """То же в координатах мира карты (с поправкой на параллакс)."""
        x, y = self._lamp_light_screen()
        gx, gy = self.gpar
        return x - gx, y + gy

    def _fog_mask(self, d):
        """Видимая плотность тумана на расстоянии d клеток от лампы (0..1):
        ближе FOG_LAMP_R0 — чисто, дальше FOG_LAMP_R1 — сплошной туман
        (оба радиуса сжимаются, пока лампа гаснет — _lamp_r)."""
        r = self._lamp_r()
        return _smooth(st.FOG_LAMP_R0 * r, st.FOG_LAMP_R1 * r, d)

    def _fog_cloud_mask(self, d):
        """Прозрачность облака по расстоянию его центра от лампы. Облака
        большие и перекрываются, поэтому гасим их с запасом — тогда
        видимый туман у клетки совпадает с _fog_mask (подобрано замером)."""
        r = self._lamp_r()
        return _smooth(st.FOG_LAMP_R0 * r + 0.9, st.FOG_LAMP_R1 * r + 0.5, d)

    def _fog_update(self, dt):
        """Кадр «Тумана»: где свет лампы, плотность тумана (плавно
        расходится и сходится), конец партии (рассеивается), качание."""
        if not self.fog_clouds or self.state != "game":
            return
        self.fog_t += dt
        if self.ended or self.exploding:
            self.fog_lift = min(1.0, self.fog_lift + dt / st.FOG_LIFT_T)
        # лампа: заряд тает; тряска в любой момент заряжает её заново
        # (погасшую — зажигает, выключенную — включает)
        self._lamp_burn(dt)
        self.lamp_flare = max(0.0, self.lamp_flare - dt / max(0.05, st.LAMP_FLARE_T))
        m = self.mouse
        if self._lamp_prev is not None:
            shook = self.lamp_shake.feed(m[0] - self._lamp_prev[0],
                                         m[1] - self._lamp_prev[1], self.fog_t)
            if (shook and not self.ended
                    and not self.exploding and not self.confirm_kind):
                self._lamp_recharge()
        on = self.fog_lamp and not self.ended and not self.exploding
        self.fog_lamp_k += ((1.0 if on else 0.0) - self.fog_lamp_k) * min(1.0, dt * 10.0)
        # фонарь качается, когда курсор двигается (как на ручке)
        m = self.mouse
        if self._lamp_prev is not None and dt > 0:
            vx = (m[0] - self._lamp_prev[0]) / dt
            target = max(-24.0, min(24.0, vx * 0.03))
        else:
            target = 0.0
        self._lamp_prev = m
        self.lamp_angle += (target - self.lamp_angle) * min(1.0, dt * 6.0)
        self.fog_light = self._lamp_light_world() if on else None
        k = min(1.0, dt * st.FOG_FADE_SPEED)
        cell = max(1e-6, self.grid.S * self.orbit_zoom)
        L = self.fog_light
        for c, a in self.fog_alpha.items():
            if L is None:
                target = 1.0
            else:
                p = self._fog_cell_world(c)
                target = self._fog_mask(math.hypot(p[0] - L[0], p[1] - L[1]) / cell)
            self.fog_alpha[c] = a + (target - a) * k
        for w in self.fog_wisps:
            w["u"] += w["du"] * dt
            if w["u"] > 1.25:
                w["u"] -= 1.5
            elif w["u"] < -0.25:
                w["u"] += 1.5
        self._fog_place(k)

    def _fog_cell_world(self, coord):
        sp = self.cell_sprites.get(coord)
        if sp is not None:
            return sp.position
        return self._orbit_local_to_world(*self.grid.center_arc(*coord))

    def _fog_xform(self):
        """Трансформация карты на этот кадр: локальные клетки (u, v; y вниз)
        -> мир. Возвращает функцию (u, v) -> (x, y)."""
        V = self.grid
        cx, cy, th, ox, oy = self._orbit_params()
        mx = cx + ox + self.orbit_pan[0]
        my = cy + oy + self.orbit_pan[1]
        c, s = math.cos(th), math.sin(th)
        z = self.orbit_zoom
        S, x0, y0, H = V.S, V.ox, V.oy, st.SCREEN_H

        def f(u, v):
            dx = x0 + u * S - cx
            dy = H - (y0 + v * S) - cy
            return mx + z * (dx * c - dy * s), my + z * (dx * s + dy * c)
        return f

    def _fog_place(self, k=1.0):
        """Позиции, размер, цвет и прозрачность облаков на текущий кадр."""
        V = self.grid
        z = self.orbit_zoom
        t = self.fog_t
        f = self._fog_xform()
        cell = V.S * z
        deg = -self.orbit_deg
        lift = 1.0 - self.fog_lift
        L = self.fog_light
        lk = self.fog_lamp_k
        fr, fg, fb = st.FOG_COLOR
        wr, wg, wb = st.FOG_WARM
        rl = self._lamp_r()
        R0, WR = st.FOG_LAMP_R0 * rl + 0.9, st.FOG_WARM_R * rl
        lk = lk * self._lamp_glow()
        tex_w = max(1, self.fog_clouds[0]["sp"].texture.width) if self.fog_clouds else 1
        for cl in self.fog_clouds:
            ph = cl["ph"]
            u = cl["u"] + 0.22 * math.sin(t * 0.21 + ph)
            v = cl["v"] + 0.16 * math.sin(t * 0.17 + ph * 1.7)
            x, y = f(u, v)
            sp = cl["sp"]
            sp.position = (x, y)
            sp.scale = cell * cl["size"] / tex_w * (1.0 + 0.05 * math.sin(t * 0.7 + ph))
            sp.angle = deg + cl["rot"] + 8.0 * math.sin(t * 0.13 + ph)
            if L is not None:
                d = math.hypot(x - L[0], y - L[1]) / cell
                target = self._fog_cloud_mask(d)
                warm = lk * (1.0 - _smooth(R0, WR, d)) * 0.9
            else:
                target, warm = 1.0, 0.0
            cl["m"] += (target - cl["m"]) * k
            lum = cl["lum"]
            col = (int((fr + (wr - fr) * warm) * lum),
                   int((fg + (wg - fg) * warm) * lum),
                   int((fb + (wb - fb) * warm) * lum))
            if col != cl.get("col"):          # меняем, только если надо
                cl["col"] = col
                sp.color = col
            a = int(255 * max(0.0, min(1.0, cl["edge"] * cl["m"] * lift)))
            if a != sp.alpha:
                sp.alpha = a
        self._fog_place_screen(k, cell, L, lift, lk, R0, WR, tex_w)
        # улетающая полоса тасовки — тоже под туманом
        outs = []
        if self.shuffle_phase == "anim" and self.shuffle_anim:
            seen = set()
            for sp, x, y in self.shuffle_anim.get("out", ()):
                key = (int(round(x)), int(round(y)))
                if key not in seen:
                    seen.add(key)
                    outs.append(sp.position)
        texs = self.assets.fog_clouds
        while len(self.fog_out) < len(outs):
            sp = arcade.Sprite(texs[len(self.fog_out) % len(texs)])
            sp.color = st.FOG_COLOR
            self.fog_list.append(sp)
            self.fog_out.append(sp)
        for i, sp in enumerate(self.fog_out):
            if i < len(outs):
                sp.position = outs[i]
                sp.scale = cell * st.FOG_BLOB * 0.8 / tex_w
                sp.angle = deg + 37.0 * i
                m = 1.0
                if L is not None:
                    m = self._fog_cloud_mask(
                        math.hypot(outs[i][0] - L[0], outs[i][1] - L[1]) / cell)
                sp.alpha = int(255 * m * lift)
            else:
                sp.alpha = 0
        # широкие гряды дрейфуют над полем; у лампы — тают
        wtex = max(1, self.assets.fog_wisp.width)
        for w in self.fog_wisps:
            u = w["u"] * V.cols
            v = w["v"] * V.rows + 0.3 * math.sin(t * 0.11 + w["ph"])
            x, y = f(u, v)
            sp = w["sp"]
            sp.position = (x, y)
            sp.scale = cell * w["size"] / wtex
            sp.angle = deg + 4.0 * math.sin(t * 0.09 + w["ph"])
            env = _smooth(-0.25, 0.1, w["u"]) * (1.0 - _smooth(0.9, 1.25, w["u"]))
            a = st.FOG_WISP_ALPHA * env * (0.75 + 0.25 * math.sin(t * 0.5 + w["ph"]))
            target = 1.0
            if L is not None:
                target = _smooth(st.FOG_LAMP_R0 * rl + 1.4, st.FOG_LAMP_R1 * rl + 2.5,
                                 math.hypot(x - L[0], y - L[1]) / cell)
            w["m"] += (target - w["m"]) * k
            sp.color = st.FOG_WISP_COLOR
            sp.alpha = int(255 * max(0.0, min(1.0, a * w["m"] * lift)))

    def _fog_place_screen(self, k, cell, L, lift, lk, R0, WR, tex_w):
        """Облака по всему экрану: стоят на месте (чуть клубятся), у лампы
        расходятся и теплеют — как облака над картой, но реже и крупнее."""
        if not self.fog_screen:
            return
        t = self.fog_t
        cam = self.cam.position
        fr, fg, fb = st.FOG_COLOR
        wr, wg, wb = st.FOG_WARM
        dens = max(0.0, min(1.0, st.FOG_SCREEN)) * lift
        rl = self._lamp_r()
        step = self.fog_screen_step
        sc = step * 2.6 / max(1e-6, cell)           # размер облака в клетках
        # облако гаснет с запасом на свой радиус — дыра у лампы та же
        q0, q1 = st.FOG_LAMP_R0 * rl + 0.36 * sc, st.FOG_LAMP_R1 * rl + 0.32 * sc
        for cl in self.fog_screen:
            ph = cl["ph"]
            x = cl["x"] + cam[0] + 0.30 * step * math.sin(t * 0.13 + ph)
            y = cl["y"] + cam[1] + 0.22 * step * math.sin(t * 0.11 + ph * 1.7)
            sp = cl["sp"]
            sp.position = (x, y)
            sp.scale = cl["size"] / tex_w * (1.0 + 0.05 * math.sin(t * 0.6 + ph))
            sp.angle = cl["rot"] + 7.0 * math.sin(t * 0.1 + ph)
            if L is not None:
                d = math.hypot(x - L[0], y - L[1]) / cell
                target = _smooth(q0, q1, d)
                warm = lk * (1.0 - _smooth(R0, WR + 1.0, d)) * 0.8
            else:
                target, warm = 1.0, 0.0
            cl["m"] += (target - cl["m"]) * k
            lum = cl["lum"]
            col = (int((fr + (wr - fr) * warm) * lum),
                   int((fg + (wg - fg) * warm) * lum),
                   int((fb + (wb - fb) * warm) * lum))
            if col != cl.get("col"):
                cl["col"] = col
                sp.color = col
            a = int(255 * max(0.0, min(1.0, dens * cl["m"])))
            if a != sp.alpha:
                sp.alpha = a

    def _draw_fog(self):
        """Тёплый свет на клетках, туман, гряды, жёлтый ореол поверх,
        темнота вдали от лампы, тёмные края экрана, подсветка клетки."""
        V = self.grid
        cell = V.S * self.orbit_zoom
        lift = 1.0 - self.fog_lift
        glow_k = self.fog_lamp_k * lift
        L = self._lamp_light_world() if glow_k > 0.01 else None
        flick = 0.93 + 0.07 * math.sin(self.fog_t * 13.0) * math.sin(self.fog_t * 7.3)
        gw = max(1, self.assets.lamp_glow.width)
        # лампа гаснет: свет сжимается (rl) и тускнеет (gl)
        rl, gl = self._lamp_r(), self._lamp_glow()
        if L is not None:
            g = self.lamp_glow_sprite           # свет падает на клетки
            g.position = L
            g.scale = cell * 4.6 * rl / gw
            g.alpha = int(120 * glow_k * gl * flick)
            arcade.draw_sprite(g)
        self.fog_screen_list.draw()             # туман по всему экрану
        self.fog_list.draw()
        self.fog_wisp_list.draw()
        if L is not None:
            g = self.lamp_glow_top              # жёлтый ореол в тумане
            g.position = L
            g.scale = cell * 2.0 * st.FOG_WARM_R * rl / gw
            g.alpha = int(80 * glow_k * gl * flick)
            arcade.draw_sprite(g)
        # темнота: вдали от лампы туман тонет во мраке; без лампы — весь.
        # Спрайт темноты огромный (дыра — малая доля текстуры), поэтому
        # всегда закрывает весь экран: никаких стыков с прямоугольниками.
        cam = self.cam.position
        scr = (st.SCREEN_W / 2.0 + cam[0], st.SCREEN_H / 2.0 + cam[1])
        da = st.FOG_DARK * lift
        lk = self.fog_lamp_k if L is not None else 0.0
        if da > 0.004:
            if lk < 0.999:
                B = 4000.0
                arcade.draw_lrbt_rectangle_filled(
                    -B, B, -B, B, (0, 0, 8, int(255 * da * (1.0 - lk))))
            if lk > 0.001:
                hs = cell * st.FOG_DARK_R * rl / DARK_FULL_R * flick ** 0.3
                ds = self.fog_dark_sprite
                ds.position = L
                ds.scale = 2.0 * hs / max(1, self.assets.fog_dark.width)
                ds.alpha = int(255 * da * lk)
                arcade.draw_sprite(ds)
        # виньетка: тёмные края экрана (FOG_VIGNETTE — сила,
        # FOG_VIGNETTE_SIZE — как далеко к центру); ровно по экрану
        va = int(255 * max(0.0, min(1.0, st.FOG_VIGNETTE)) * lift)
        if va > 0:
            vs = self.fog_vignette_sprite
            vt = vs.texture
            vs.position = scr
            vs.scale = ((st.SCREEN_W + 4) / max(1, vt.width),
                        (st.SCREEN_H + 4) / max(1, vt.height))
            vs.alpha = va
            arcade.draw_sprite(vs)
        if self._hover_on:
            arcade.draw_sprite(self.hover_sprite)

    def _draw_lamp(self):
        """Фонарь висит на кончике курсора (верх кольца-ручки — ровно в
        точке курсора) и качается при движении."""
        if not self.fog_clouds or self.overlay:
            return
        dead = self.lamp_dead and not self.ended and not self.exploding
        if self.fog_lamp_k <= 0.02 and not dead:
            return
        sp = self.lamp_sprite
        h = float(st.LAMP_H)
        sp.scale = h / max(1, self.assets.lamp.height)
        ang = self._lamp_ang()
        px = self.mouse[0] + st.LAMP_OFFSET[0]
        py = ui.Y(self.mouse[1] + st.LAMP_OFFSET[1])
        r = math.radians(ang)
        sp.position = (px - h / 2.0 * math.sin(r), py - h / 2.0 * math.cos(r))
        sp.angle = ang
        if dead:
            # погасла: фонарь в курсоре тёмный — подсказка «потряси»
            sp.color = (120, 116, 128)
            sp.alpha = max(int(255 * self.fog_lamp_k), 230)
        else:
            g = int(170 + 85 * self._lamp_glow())
            sp.color = (255, g, g)
            sp.alpha = int(255 * self.fog_lamp_k)
        arcade.draw_sprite(sp)

    # ---------- Взрыв бомбы: анимация + осколки ----------

    def _clear_fx(self):
        self.fx_booms = []
        self.fx_shards = []
        self.boom_list.clear()
        self.shard_list.clear()

    def _spawn_boom(self, coord, power=1.0, skin=None):
        """Взрыв бомбы на клетке coord: анимация взрыва (кадры
        sprites/explosion_NN.png) прямо на бомбе, а сама бомба
        рассыпается на DEBRIS_COUNT осколков — немного и недалеко;
        осколки плавно тают. Координаты — локальные координаты карты:
        в «Орбите» взрыв летит и крутится вместе с полем."""
        if self.grid is None:
            return
        x, y = coord
        lx, ly = self.grid.center_arc(x, y)
        p = max(0.5, min(1.5, float(power)))
        frames = self.assets.explosion
        if frames:
            sp = arcade.Sprite(frames[0])
            size = self.cell * st.BOOM_SIZE * (0.9 + 0.1 * p)
            self.fx_booms.append({"sp": sp, "t": 0.0, "lx": lx, "ly": ly,
                                  "scale": size / max(1, frames[0].width),
                                  "ang": random.uniform(0.0, 360.0)})
            self.boom_list.append(sp)
        skin = skin or self.save.selected_bomb
        btex = self.assets.bomb_icon(skin, 96)
        bscale = self.cell * st.BOMB_SCALE / max(1, btex.width)
        for tex, ox, oy in self.assets.bomb_shards(skin, st.DEBRIS_COUNT):
            if math.hypot(ox, oy) < 1e-3:
                a = random.uniform(0.0, math.tau)
            else:
                a = math.atan2(oy, ox)          # летит «от центра» бомбы
            a += random.uniform(-0.35, 0.35)
            lo, hi = st.DEBRIS_DIST
            dist = random.uniform(lo, hi) * self.cell * (0.85 + 0.15 * p)
            sp = arcade.Sprite(tex, scale=bscale)
            self.fx_shards.append({
                "sp": sp, "t": 0.0,
                "life": random.uniform(*st.DEBRIS_LIFE),
                "cx": lx, "cy": ly,
                "ox": ox * bscale, "oy": oy * bscale,
                "dx": math.cos(a) * dist, "dy": math.sin(a) * dist,
                "spin": random.uniform(-1.0, 1.0) * st.DEBRIS_SPIN,
                "scale": bscale})
            self.shard_list.append(sp)
        self._place_fx()

    def _update_fx(self, dt):
        if not self.fx_booms and not self.fx_shards:
            return
        frames = self.assets.explosion
        for b in self.fx_booms[:]:
            b["t"] += dt
            fi = int(b["t"] * st.BOOM_FPS)
            if fi >= len(frames):
                self.fx_booms.remove(b)
                self.boom_list.remove(b["sp"])
            else:
                b["sp"].texture = frames[fi]
        for sh in self.fx_shards[:]:
            sh["t"] += dt
            if sh["t"] >= st.DEBRIS_HOLD + sh["life"]:
                self.fx_shards.remove(sh)
                self.shard_list.remove(sh["sp"])
        self._place_fx()

    def _fx_world(self, lx, ly):
        if self._orbit_on():
            return self._orbit_local_to_world(lx, ly)
        return (lx, ly)

    def _place_fx(self):
        """Позиции/поворот/прозрачность спрайтов взрыва на текущий кадр."""
        orbit = self._orbit_on()
        z = self.orbit_zoom if orbit else 1.0
        tilt = -self.orbit_deg if orbit else 0.0
        for b in self.fx_booms:
            sp = b["sp"]
            sp.position = self._fx_world(b["lx"], b["ly"])
            sp.scale = b["scale"] * z
            sp.angle = b["ang"] + tilt
        hold = st.DEBRIS_HOLD
        fade_from = 1.0 - st.DEBRIS_FADE
        for sh in self.fx_shards:
            t = sh["t"]
            if t < hold:
                # бомба ещё целая: мгновение «вздувается» перед разлётом
                e, ang, alpha, shade = 0.0, 0.0, 255, 255
                grow = 1.0 + 0.10 * (t / hold)
            else:
                tau = _clamp01((t - hold) / max(1e-6, sh["life"]))
                e = _ease_out(tau, 3.0)          # быстро вылетают, тормозят
                grow = 1.10 - 0.32 * e
                ang = sh["spin"] * e
                fade = _smooth01((tau - fade_from) / max(1e-6, st.DEBRIS_FADE))
                alpha = int(255 * (1.0 - fade))  # плавно тают в конце
                shade = int(255 - 110 * e)       # чуть темнеют («обгорели»)
            lx = sh["cx"] + sh["ox"] * grow + sh["dx"] * e
            ly = sh["cy"] + sh["oy"] * grow + sh["dy"] * e
            sp = sh["sp"]
            sp.position = self._fx_world(lx, ly)
            sp.scale = sh["scale"] * grow * z
            sp.angle = ang + tilt
            sp.color = (shade, shade, shade)
            sp.alpha = max(0, min(255, alpha))

    # ---------- Взрывы ----------

    def _hit_mine(self, first):
        self._shuffle_abort()
        self.ended = True
        self.timer_on = False
        self.lose_reason = "mine"
        self.hover = None
        self._hover_on = False
        mines = self.board.mine_list()
        mines.sort(key=lambda m: (m[0] - first[0]) ** 2 + (m[1] - first[1]) ** 2)
        self.explosion_queue = []
        delay = 0.0
        for i, m in enumerate(mines):
            if i == 0:
                self.explosion_queue.append((m[0], m[1], 0.0, 1.35))
            else:
                if delay == 0.0:
                    delay = 0.6
                else:
                    delay += 0.16
                self.explosion_queue.append((m[0], m[1], delay, 1.0))
        self.explosion_t = 0.0
        self.exploding = True

    def _time_up(self):
        self._shuffle_abort()
        self.ended = True
        self.timer_on = False
        self.lose_reason = "time"
        self.hover = None
        self._hover_on = False
        self.explosion_queue = []
        delay = 0.0
        for m in self.board.mine_list():
            self.explosion_queue.append((m[0], m[1], delay, 0.8))
            delay += 0.08
        self.explosion_t = 0.0
        self.exploding = True

    def _skip_explosions(self):
        """Пробел: мгновенно детонируем все оставшиеся мины — без звуков."""
        if not self.exploding:
            return
        while self.explosion_queue:
            x, y, _, power = self.explosion_queue.pop(0)
            self._detonate(x, y, min(power, 0.9), silent=True)
        self.exploding = False
        self._finish_lose()

    def _detonate(self, x, y, power, silent=False):
        b = self.board
        c = b.cell(x, y)
        if c.flagged:
            b.flags_used -= 1
            c.flagged = False
        c.revealed = True
        c.exploded = True
        # OnCellChanged(): клетка взорвалась
        self._fire_cell_changed((x, y), "explode")
        # анимация взрыва на бомбе + бомба рассыпается на осколки
        self._spawn_boom((x, y), power)
        self.shake = max(self.shake, 7.0 * power)
        if power > 1.2:
            self.flash = 1.0
        self._sync_cells()
        if not silent:
            self.sounds.play(random.choice(["boom1", "boom2", "boom3"]), 0.9)

    def _finish_lose_text(self):
        if self.lose_reason == "time":
            return ("ВРЕМЯ ВЫШЛО!",
                    "Блиц не пройден: время истекло.\nУтешительная награда: +{} монет".format(st.LOSS_REWARD))
        return ("ВЗРЫВ!",
                "Бомбы детонировали по цепочке.\nУтешительная награда: +{} монет".format(st.LOSS_REWARD))

    def _finish_lose(self):
        title, sub = self._finish_lose_text()
        self.save.coins += st.LOSS_REWARD
        self.save.save()
        self.lose_title_label.set_text(title)
        self.lose_sub_label.set_text(sub)
        self.overlay = "lose"
        self.sounds.play("lose")

    def _check_win(self):
        if self.ended or self.board is None or not self.board.all_safe_revealed():
            return
        self.ended = True
        self.timer_on = False
        self.hover = None
        self._hover_on = False
        # классика: на победном экране все мины помечены флажками
        for x, y in self.board.mine_list():
            c = self.board.cell(x, y)
            if not c.flagged:
                c.flagged = True
                self.board.flags_used += 1
        self._sync_cells()
        mines = self.board.mines
        # награда: множители выбранных испытаний ПЕРЕМНОЖАЮТСЯ и умножаются
        # на множитель сложности (settings.DIFF_CHAL_MULT)
        diff_key = st.DIFFICULTIES[self.diff_index][0]
        mult = chal.combined_mult(self.challenges, diff_key)
        coins = st.win_reward(mines, mult)
        record = False
        if self.challenges:
            self.save.challenges_done += len(self.challenges)
        else:
            record = self.save.record_time(self.diff_index, self.play_time)
        self.save.coins += coins
        self.save.save()
        stats = "Время: {}   Монеты: +{}   награда ×{:g}".format(
            fmt_time(self.play_time), coins, mult)
        if record:
            stats += "\nНОВЫЙ РЕКОРД!"
        if self.challenges:
            titles = dict((k, t) for k, t, _, _ in st.CHALLENGES)
            joined = " + ".join(titles[k] for k in self.challenges)
            if len(self.challenges) == 1:
                stats += "\nИспытание «{}» пройдено!".format(joined)
            else:
                stats += "\nИспытания «{}» пройдены!".format(joined)
        self.win_stats = stats
        self.win_timer = 0.45
        self.sounds.play("win")

    # ---------- Обновление ----------

    def on_update(self, dt):
        self.anim_t += dt
        self._scroll_update(dt)

        # музыка: в партии — трек по сложности и испытаниям, иначе — меню
        self.sounds.music_play(self._music_track())
        self.sounds.update(dt)

        # параллакс: меню чуть-чуть тянется за курсором
        tx = max(-st.PARALLAX_MAX, min(st.PARALLAX_MAX,
                (self.mouse[0] - st.SCREEN_W / 2) * st.PARALLAX_K))
        ty = max(-st.PARALLAX_MAX, min(st.PARALLAX_MAX,
                (self.mouse[1] - st.SCREEN_H / 2) * st.PARALLAX_K))
        k = min(1.0, dt * 5.0)
        self.par = (self.par[0] + (tx - self.par[0]) * k,
                    self.par[1] + (ty - self.par[1]) * k)

        # параллакс карты в игре — тот же приём, но совсем чуть-чуть
        if self.state == "game":
            gtx = max(-st.GAME_PARALLAX_MAX, min(st.GAME_PARALLAX_MAX,
                      (self.mouse[0] - st.SCREEN_W / 2) * st.GAME_PARALLAX_K))
            gty = max(-st.GAME_PARALLAX_MAX, min(st.GAME_PARALLAX_MAX,
                      (self.mouse[1] - st.SCREEN_H / 2) * st.GAME_PARALLAX_K))
            self.gpar = (self.gpar[0] + (gtx - self.gpar[0]) * k,
                         self.gpar[1] + (gty - self.gpar[1]) * k)

        # декор фона: бомбы и флажки падают сверху вниз
        self._update_decor(dt)

        # экран «ИГРАТЬ»: плашки уезжают, испытания появляются
        if self.state == "difficulty":
            self._update_play(dt)

        # таймер партии
        if self.state == "game" and self.timer_on and not self.ended:
            self.play_time += dt

        # испытания: порядок кадра — ОРБИТА, ТАСОВКА, ФУГАС, БЛИЦ, ДИВЕРСАНТ;
        # после модулей — отрисовка + камера (on_draw)
        for m in self.modules:
            m.on_update(dt)

        # цепочка взрывов
        if self.exploding:
            self.explosion_t += dt
            while self.explosion_queue and self.explosion_queue[0][2] <= self.explosion_t:
                x, y, _, power = self.explosion_queue.pop(0)
                self._detonate(x, y, power)
            if not self.explosion_queue:
                self.exploding = False
                self._finish_lose()

        if self.win_timer > 0:
            self.win_timer -= dt
            if self.win_timer <= 0:
                self.win_stats_label.set_text(self.win_stats)
                self.overlay = "win"

        # частицы
        for p in self.particles[:]:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 420 * dt
            p[4] -= dt
            if p[4] <= 0:
                self.particles.remove(p)
        for r in self.rings[:]:
            r[2] += dt
            if r[2] >= r[3]:
                self.rings.remove(r)
        # взрывы: кадры анимации и разлёт осколков
        self._update_fx(dt)
        # украшения/эффекты скина поля — едут за спрайтами клеток
        if self.state == "game" and self.field_fx is not None:
            self.field_fx.update(dt)
        self.shake = max(0.0, self.shake - dt * 22.0)
        self.flash = max(0.0, self.flash - dt * 4.0)
        if self.toast_t > 0:
            self.toast_t -= dt

        # hover
        self.hover = None
        if (self.state == "game" and not self.ended and not self.confirm_kind
                and self.shuffle_phase != "anim"
                and not self._pan_active
                and not (self._orbit_on() and self._shift_down)):
            self.hover = self._cell_at(self.mouse)
        if self.hover and (not self.board.cell(*self.hover).revealed
                           or self._fog_hidden(self.hover)):
            # в «Тумане» подсветка рисуется поверх тумана и для открытых
            # клеток тоже — по ней нельзя угадать, что под туманом
            x, y = self.hover
            self._hover_on = True
            base = self.cell / self.assets.hover.width
            self.hover_sprite.scale = base * (self.orbit_zoom
                                              if self._orbit_on() else 1.0)
            if self._orbit_on():
                wx, wy = self._orbit_local_to_world(*self.grid.center_arc(x, y))
                self.hover_sprite.position = (wx, wy)
                self.hover_sprite.angle = -self.orbit_deg
            else:
                self.hover_sprite.position = self.grid.center_arc(x, y)
                self.hover_sprite.angle = 0.0
        else:
            self._hover_on = False

        # анимация флажков: подмена кадров (все кадры — PNG-спрайты)
        if self.flag_refs:
            frames_cache = {}
            for sp, skin in self.flag_refs:
                fr = frames_cache.get(skin)
                if fr is None:
                    fr = (self.assets.flag_frames(skin),
                          int(self.anim_t * self.assets.flag_fps(skin)))
                    frames_cache[skin] = fr
                frames, fi = fr
                if len(frames) > 1:
                    sp.texture = frames[fi % len(frames)]

    # ---------- Отрисовка ----------

    def on_draw(self):
        # очистка всего окна (letterbox-полосы тоже)
        self.ctx.viewport = (0, 0, int(self.width), int(self.height))
        self.clear((8, 10, 16))

        sx = sy = 0.0
        if self.state == "game" and self.shake > 0.3:
            sx = random.uniform(-self.shake, self.shake)
            sy = random.uniform(-self.shake, self.shake)
        # фон и падающие бомбы/флажки — за курсором не двигаются
        self._cam_begin(sx, sy)   # только тряска
        self.cam.use()
        self._draw_bg()

        if self.state == "game":
            # карта: тряска + лёгкий параллакс за курсором (y вниз -> вверх)
            gx, gy = self.gpar
            if self.field_fx is not None:
                # поле ERROR «лагает»: короткая дрожь (только картинка)
                jx, jy = self.field_fx.jitter
                gx, gy = gx + jx, gy + jy
            self._cam_begin(sx + gx, sy - gy)
            self.cam.use()
            self._draw_game_world()
        elif self.state == "menu":
            self._draw_menu()
        else:
            self._draw_menu_state()

        # HUD и оверлеи — без тряски, без зума и панорамы
        self.cam.position = (0.0, 0.0)
        self.cam.zoom = 1.0
        self.cam.use()
        if self.state == "game":
            self._draw_game_hud()
        if self.confirm_kind:
            self._draw_confirm()
        self._draw_toast()

    # ---------- Меню ----------

    def _apply_par(self, widgets, k=1.0):
        for wd in widgets:
            wd.off = (self.par[0] * k, self.par[1] * k)

    @staticmethod
    def _title_layout(cx, cy, size, text="MINESWEEPER", flag_at=8):
        """Раскладка заголовка, где буква text[flag_at] — флажок.
        Меряем тем же шрифтом (DejaVu Sans Bold, px), что и рисуем:
        x0 — левый край, p_x/p_w — место буквы, er_x — начало хвоста,
        base — базовая линия, cap — высота заглавной (y сверху вниз)."""
        left, letter, right = text[:flag_at], text[flag_at], text[flag_at + 1:]
        try:
            from PIL import ImageFont
            font = ImageFont.truetype(os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "fonts", "DejaVuSans-Bold.ttf"), int(size))
            w_left = font.getlength(left)
            w_lp = font.getlength(left + letter)
            w_all = font.getlength(text)
            asc, desc = font.getmetrics()
            cap = -font.getbbox(letter, anchor="ls")[1]
        except Exception:
            w_left, w_lp, w_all = (size * 0.72 * k for k in
                                   (len(left), len(left) + 1, len(text)))
            asc, desc, cap = size * 0.93, size * 0.24, size * 0.73
        x0 = cx - w_all / 2.0
        # базовая линия — как у pyglet (arcade.Text, anchor_y="center"):
        # однострочный текст он центрирует не по (asc - desc) / 2, а так —
        # верх = asc // 2 - descent // 4 (descent < 0). Раньше флажок
        # из-за этого висел над буквами на ~desc / 4 px.
        base = cy + asc - asc // 2 - math.ceil(desc / 4.0)
        return {"left": left, "right": right, "x0": x0,
                "p_x": x0 + w_left, "p_w": w_lp - w_left,
                "er_x": x0 + w_lp, "base": float(base),
                "cap": float(cap)}

    def _update_title_flag(self):
        """Флажок-«P» в заголовке: скин из инвентаря, анимирован;
        высота непрозрачной части = высоте буквы, низ — на базовой линии."""
        skin = self.save.selected_flag
        frames = self.assets.flag_frames(skin)
        sp = self.title_flag
        if not frames:
            sp.visible = False
            return
        fi = int(self.anim_t * self.assets.flag_fps(skin)) % len(frames)
        sp.texture = frames[fi]
        (l, t, r, b), (tw, th) = self.assets.flag_bbox(skin)
        lay = self.title_layout
        k = lay["cap"] * st.TITLE_FLAG_K / max(1, b - t)
        sp.scale = k
        par = self.par
        cx = lay["p_x"] + lay["p_w"] / 2.0 - ((l + r) / 2.0 - tw / 2.0) * k
        # низ флажка — на базовой линии букв (+ TITLE_FLAG_DROP px вниз)
        cy = lay["base"] + st.TITLE_FLAG_DROP - (b - th / 2.0) * k
        sp.position = (cx + par[0], ui.Y(cy) - par[1])

    def _draw_menu(self):
        par = self.par
        # эмблема с бомбой; тень и эмблема — спрайты
        bx, by = self.badge_pos
        r = self.badge_r
        self.badge_shadow_sprite.position = (bx + par[0] * 1.5,
                                             ui.Y(by + r * 0.95) - par[1] * 1.5)
        arcade.draw_sprite(self.badge_shadow_sprite)
        self.badge_sprite.position = (bx + par[0] * 1.5, ui.Y(by) - par[1] * 1.5)
        arcade.draw_sprite(self.badge_sprite)

        self._apply_par(self.screens["menu"])
        for wd in self.screens["menu"]:
            if not isinstance(wd, ui.RibbonButton):
                wd.draw(self.mouse)
        self._update_title_flag()
        arcade.draw_sprite(self.title_flag)

        # ленты поверх эмблемы
        for b in self.menu_ribbons:
            b.draw(self.assets, self.mouse)

    def _draw_menu_state(self):
        """Промежуточные экраны: «ИГРАТЬ» (сложность + испытания), магазин,
        инвентарь."""
        if self.state == "difficulty":
            self._draw_play()
            return
        self._apply_par(self.screens[self.state])
        if self.state in st.SCROLL_SCREENS:
            self._draw_scroll_screen(self.screens[self.state])
            return
        for wd in self.screens[self.state]:
            if isinstance(wd, (ui.Button, ui.CheckCard)):
                wd.draw(self.assets, self.mouse)
            else:
                wd.draw(self.mouse)

    # ---------- Игра ----------

    def _draw_bg(self):
        """Фон + декор (падающие белые бомбы и флажки) — во всех экранах."""
        arcade.draw_sprite(self.bg_sprite)
        self.decor_list.draw()

    # ---------- Декор фона ----------

    def _build_decor(self):
        """Белые полупрозрачные силуэты бомб и флажков для фона."""
        self.decor_list = arcade.SpriteList()
        self.decor = []
        texs = []
        for name in st.BG_DECOR_SPRITES:
            tex = self.assets.silhouette(name)
            if tex is not None:
                texs.append((name.startswith("f_"), tex))
        self._decor_texs = texs
        if not texs:
            return
        for _ in range(st.BG_DECOR_COUNT):
            is_flag, tex = random.choice(texs)
            sp = arcade.Sprite(tex)
            d = {"sp": sp, "flag": is_flag, "tex": tex}
            self._decor_respawn(d, y=random.uniform(0, st.SCREEN_H))
            self.decor.append(d)
            self.decor_list.append(sp)

    def _decor_respawn(self, d, y=None):
        """Новые параметры падения; y=None — сразу над верхним краем."""
        lo, hi = st.BG_DECOR_SIZE
        size = random.uniform(lo, hi)
        depth = (size - lo) / float(max(1, hi - lo))   # 0 — далеко, 1 — близко
        sp = d["sp"]
        sp.scale = size / float(max(1, d["tex"].width))
        a0, a1 = st.BG_DECOR_ALPHA
        sp.alpha = int(a0 + (a1 - a0) * depth)
        v0, v1 = st.BG_DECOR_SPEED
        d["size"] = size
        d["speed"] = (v0 + (v1 - v0) * depth) * random.uniform(0.85, 1.15)
        d["x0"] = random.uniform(0, st.SCREEN_W)
        d["y"] = st.SCREEN_H + size if y is None else y
        d["amp"] = random.uniform(6.0, 20.0)          # покачивание вбок
        d["freq"] = random.uniform(0.35, 0.9)
        d["ph"] = random.uniform(0.0, math.tau)
        d["ang0"] = random.uniform(-25.0, 25.0)
        d["spin"] = random.uniform(-30.0, 30.0)       # бомбы медленно крутятся
        d["t"] = 0.0
        self._decor_place(d)

    def _decor_place(self, d):
        sp, t = d["sp"], d["t"]
        sp.position = (d["x0"] + d["amp"] * math.sin(d["ph"] + t * d["freq"]),
                       d["y"])
        if d["flag"]:   # флажок плавно раскачивается
            sp.angle = d["ang0"] * 0.6 + 14.0 * math.sin(d["ph"] + t * d["freq"] * 1.3)
        else:
            sp.angle = d["ang0"] + d["spin"] * t

    def _update_decor(self, dt):
        for d in self.decor:
            d["t"] += dt
            d["y"] -= d["speed"] * dt        # arcade: y вверх — падаем вниз
            if d["y"] < -d["size"]:
                self._decor_respawn(d)
            else:
                self._decor_place(d)

    def _draw_game_world(self):
        b, V = self.board, self.grid

        # рамка поля — две «утопленные» кромки (в «Орбите» летит с полем)
        if self._orbit_on():
            outer, inner = self._orbit_frame
        else:
            outer, inner = self._frame_outer, self._frame_inner
        arcade.draw_polygon_filled(outer, (60, 62, 58))
        arcade.draw_polygon_filled(inner, (112, 114, 108))

        # подсветка клетки под курсором (в «Тумане» — поверх тумана)
        fog = self._fog_on() and bool(self.fog_clouds)
        if self._hover_on and not fog:
            arcade.draw_sprite(self.hover_sprite)

        # клетки (arcade.SpriteList — один пакетный вызов)
        self.cell_list.draw()
        # флажки и бомбы
        self.overlay_list.draw()

        # выпуклые числа (пакетный SpriteList)
        self.num_list.draw()

        # улетевшая полоса во время анимации тасовки (поверх поля)
        if self.shuffle_phase == "anim" and self.shuffle_anim:
            for sp, _, _ in self.shuffle_anim["out"]:
                arcade.draw_sprite(sp)

        # скин поля: украшения на закрытых клетках, блёстки, перекати-поле,
        # «лаг» ERROR — под туманом (по ним не угадать закрытые клетки)
        fx = self.field_fx
        if fx is not None:
            fx.draw_ground()

        # «ТУМАН»: тёплый свет лампы, облака тумана, гряды, ореол,
        # темнота и тёмные края, подсветка; временные бомбы и взрывы —
        # поверх тумана
        if fog:
            self._draw_fog()

        # снег / лепестки сакуры — поверх поля и тумана
        if fx is not None:
            fx.draw_air()

        # фугас: временные бомбы с отсчётом поверх поля
        if self.fugas_phase == "armed":
            for bomb in self.fugas_bombs:
                self._draw_temp_bomb(bomb)

        # взрывы: анимация на бомбе, поверх — разлетающиеся осколки
        self.boom_list.draw()
        self.shard_list.draw()

        # частицы и ударные волны (встроенные круги arcade)
        for p in self.particles:
            k = max(0.0, p[4] / p[5]) if p[5] else 0.0
            if len(p) > 7:   # цвет задан (например, зелёные брызги обезвреживания)
                col = p[7]
            else:
                col = (int(255 * k + 90 * (1 - k)),
                       int(140 * k + 40 * (1 - k)), int(40 * k))
            arcade.draw_circle_filled(p[0], ui.Y(p[1]),
                                      max(1.0, p[6] * k + 1), col)
        for r in self.rings:
            k = r[2] / r[3]
            rr = r[4] * k
            if rr > 2:
                arcade.draw_circle_outline(r[0], ui.Y(r[1]), rr, (255, 200, 120),
                                           max(1, int(4 * (1 - k))))

        if self.flash > 0:
            # с запасом: мир сдвинут тряской и параллаксом
            arcade.draw_lrbt_rectangle_filled(
                -40, st.SCREEN_W + 40, -40, st.SCREEN_H + 40,
                (255, 180, 90, int(60 * self.flash)))

    def _num_texture(self, n, h):
        """Цифра клетки высотой h px -> (текстура, масштаб спрайта).
        Цифры — векторные PNG sprites/num_<n>.png (гладкие, в духе
        minesweeper.online): уменьшаются сглаживанием LANCZOS с запасом x2,
        чтобы оставаться чёткими при зуме; высота самой цифры (без прозрачных
        полей) на экране = h. На тёмных скинах поля — светлый вариант.
        Нет PNG — запасная цифра шрифтом."""
        tile = self.save.selected_tile.replace("t_", "", 1)
        dark = self.assets.tile_is_dark(tile)
        key = (n, h, dark)
        hit = self._num_tex_cache.get(key)
        if hit is not None:
            return hit
        from PIL import Image, ImageDraw, ImageFont
        img = self.assets.digit_image(n)
        if img is not None:
            bb = img.getchannel("A").getbbox() or (0, 0, img.width, img.height)
            gh = max(1, bb[3] - bb[1])
            px = min(float(gh), 2.0 * h)          # высота цифры в текстуре
            f = px / gh
            big = img if f >= 0.999 else img.resize(
                (max(1, int(round(img.width * f))), max(1, int(round(img.height * f)))),
                Image.LANCZOS)
            f = big.height / float(img.height)
            if dark:
                r, g, b, a = big.split()
                lift = lambda v: int(v + (255 - v) * st.NUM_DARK_LIFT)
                big = Image.merge("RGBA", (r.point(lift), g.point(lift),
                                           b.point(lift), a))
            tex = arcade.Texture(big, hash="numv_{}_{}_{}".format(n, h, int(dark)))
            hit = (tex, h / (gh * f))
            self._num_tex_cache[key] = hit
            return hit
        col = st.NUM_COLORS[n]
        dark_c = _dark(col, 0.35)
        d = max(2, h // 12)
        font_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "fonts", "DejaVuSans-Bold.ttf")
        font = ImageFont.truetype(font_path, h)
        bbox = font.getbbox(str(n))
        w_, hh = bbox[2] - bbox[0], bbox[3] - bbox[1]
        img = Image.new("RGBA", (w_ + d, hh + d), (0, 0, 0, 0))
        dr = ImageDraw.Draw(img)
        dr.text((d - bbox[0], d - bbox[1]), str(n), font=font, fill=dark_c)
        dr.text((-bbox[0], -bbox[1]), str(n), font=font, fill=col)
        tex = arcade.Texture(img, hash="num_{}_{}".format(n, h))
        hit = (tex, 1.0)
        self._num_tex_cache[key] = hit
        return hit

    def _sync_numbers(self):
        """Числа на открытых клетках — спрайты в пакетном SpriteList."""
        b, V = self.board, self.grid
        self.num_list.clear()
        self.num_coords = []
        self._num_base_scales = []
        h = max(6, int(round(V.S * st.NUM_SIZE)))
        for y in range(b.rows):
            for x in range(b.cols):
                c = b.cell(x, y)
                if c.revealed and not c.exploded and c.adj > 0:
                    tex, sc = self._num_texture(c.adj, h)
                    sp = arcade.Sprite(tex, scale=sc)
                    sp.position = V.center_arc(x, y)
                    self.num_list.append(sp)
                    self.num_coords.append((x, y))
                    self._num_base_scales.append(sc)

    def _draw_game_hud(self):
        b = self.board
        # полоса HUD — спрайт
        self.hud_bar_sprite.position = (st.SCREEN_W / 2, ui.Y(st.HUD_H / 2))
        arcade.draw_sprite(self.hud_bar_sprite)
        self.hud_bomb_sprite.position = (44, ui.Y(28))
        arcade.draw_sprite(self.hud_bomb_sprite)

        self.hud_mines.set_text("МИНЫ: {}".format(b.mines_left()))
        if "blitz" in self.challenges:
            self.hud_time.set_text(fmt_time(self.blitz_left))
            low = self.blitz_left < 10 and not self.ended
            self.hud_time.color = (255, 120, 90) if low else st.CLR_TEXT
        else:
            self.hud_time.set_text(fmt_time(self.play_time))
            self.hud_time.color = st.CLR_TEXT
        if self.fugas_phase == "armed":
            self.hud_banner.set_text(
                "ОБЕЗВРЕДЬ ОБЕ!" if len(self.fugas_bombs) > 1 else "ОБЕЗВРЕДЬ!",
                (255, 120, 90))
        else:
            self.hud_banner.set_text(self._banner_text())
        for wd in self.screens["game"]:
            if isinstance(wd, ui.Button):
                wd.draw(self.assets, self.mouse)
            else:
                wd.draw(self.mouse)

        # фонарь в курсоре («ТУМАН») — под оверлеями
        if self._fog_on():
            self._draw_lamp()

        # ---- оверлеи ----
        if self.overlay == "win":
            self._draw_result(True)
        elif self.overlay == "lose":
            self._draw_result(False)

    def _draw_result(self, is_win):
        arcade.draw_lrbt_rectangle_filled(
            0, st.SCREEN_W, 0, st.SCREEN_H,
            (16, 110, 44, 118) if is_win else (150, 16, 16, 118))
        self.result_panel_sprite.position = (st.SCREEN_W // 2, ui.Y(360))
        arcade.draw_sprite(self.result_panel_sprite)
        for wd in self.screens["win" if is_win else "lose"]:
            if isinstance(wd, ui.Button):
                wd.draw(self.assets, self.mouse)
            else:
                wd.draw(self.mouse)

    def _music_track(self):
        """Какой трек должен играть сейчас (см. sounds.track_for)."""
        if self.state == "game" and self.board is not None:
            return snd.track_for(self.diff_index, self.challenges)
        return "music"

    def _banner_text(self):
        # одиночное испытание — подробная подсказка, как раньше
        if len(self.challenges) == 1:
            c = self.challenges[0]
            if c == "blitz":
                return "БЛИЦ"
            if c == "noflags":
                return "ДИВЕРСАНТ"
            if c == "fugas":
                return "ФУГАС"
            if c == "orbit":
                return "ОРБИТА"
            if c == "fog":
                if self.lamp_dead and not self.fog_lamp:
                    return "ТУМАН · лампа погасла — потряси мышкой!"
                # сколько осталось заряда — не пишем: видно по свету
                return "ТУМАН · ПРОБЕЛ — лампа {} · потряси мышкой — зарядить".format(
                    "ВКЛ" if self.fog_lamp else "ВЫКЛ")
            if c == "shuffle":
                if self.shuffle_phase == "anim":
                    return "ТАСОВКА!"
                if self.shuffle_phase == "waiting":
                    return "ТАСОВКА · следующая через {} с".format(
                        max(1, int(math.ceil(self.shuffle_t))))
                return "ТАСОВКА · откройте первую ячейку"
        # соединение испытаний — краткие статусы всех модулей через «|»
        parts = []
        for key, _, _, _ in st.CHALLENGES:
            if key not in self.challenges:
                continue
            if key == "blitz":
                parts.append("БЛИЦ {}".format(fmt_time(self.blitz_left)))
            elif key == "noflags":
                parts.append("БЕЗ ФЛАЖКОВ")
            elif key == "fugas":
                if self.fugas_phase == "armed":
                    parts.append("ФУГАС {:.1f}с".format(self.fugas_t))
                else:
                    parts.append("ФУГАС")
            elif key == "shuffle":
                if self.shuffle_phase == "anim":
                    parts.append("ТАСОВКА!")
                elif self.shuffle_phase == "waiting":
                    parts.append("ТАСОВКА через {}с".format(
                        max(1, int(math.ceil(self.shuffle_t)))))
                else:
                    parts.append("ТАСОВКА")
            elif key == "orbit":
                parts.append("ОРБИТА")
            elif key == "fog":
                if self.lamp_dead and not self.fog_lamp:
                    parts.append("ТУМАН · ЛАМПА ПОГАСЛА")
                else:
                    parts.append("ТУМАН" + (" · ЛАМПА" if self.fog_lamp else ""))
        return "   |   ".join(parts)

    def _fugas_motion(self, bomb):
        """Как временная бомба дёргается и мигает в этот кадр.
        Возвращает (dx, dy, угол, масштаб, red): dx/dy — смещение в долях
        координат карты (px), red 0..1 — насколько бомба сейчас красная.
            * тряска появления (FUGAS_SPAWN_SHAKE_T);
            * пока тикает фитиль — мелкая дрожь, к концу сильнее;
            * каждые FUGAS_TICK секунд — резкий рывок + красная вспышка;
            * сильное мигание красным, всё чаще к концу фитиля."""
        cell = float(self.cell)
        ph = bomb["seed"]
        jx = jy = jang = 0.0
        age, T = bomb["age"], st.FUGAS_SPAWN_SHAKE_T
        if age < T:
            k = (1.0 - age / T) ** 2
            amp = cell * st.FUGAS_SPAWN_SHAKE * k
            jx += amp * math.sin(age * 75.0 + ph)
            jy += amp * math.cos(age * 61.0 + ph * 1.7)
            jang += 9.0 * k * math.sin(age * 58.0 + ph)
        fuse = max(1e-6, st.FUGAS_FUSE)
        el = max(0.0, fuse - max(0.0, self.fugas_t))     # сколько уже тикает
        urg = _clamp01(el / fuse)
        # постоянная мелкая дрожь
        tr = cell * st.FUGAS_TREMOR * (0.5 + urg)
        jx += tr * math.sin(el * 83.0 + ph * 2.3)
        jy += tr * math.cos(el * 71.0 + ph * 3.1)
        jang += 160.0 * st.FUGAS_TREMOR * (0.5 + urg) * math.sin(el * 67.0 + ph)
        # «тик»: резкий рывок в случайную сторону, быстро затухает
        kick = 0.0
        pop = 1.0
        if st.FUGAS_TICK > 0:
            n = int(el / st.FUGAS_TICK)
            since = el - n * st.FUGAS_TICK
            if n >= 1:
                kick = math.exp(-since / 0.07)
                th = ph * 7.3 + n * 2.39996          # каждый тик — в свою сторону
                a = cell * st.FUGAS_TICK_SHAKE * kick * math.cos(since * 50.0)
                jx += a * math.cos(th)
                jy += a * math.sin(th)
                jang += (14.0 if n % 2 else -14.0) * kick * math.cos(since * 44.0)
                pop += 0.12 * kick
        # мигание красным: частота растёт от FUGAS_BLINK_HZ[0] к [1]
        f0, f1 = st.FUGAS_BLINK_HZ
        phase = math.tau * (f0 * el + (f1 - f0) * el * el / (2.0 * fuse))
        wave = 0.5 + 0.5 * math.cos(phase)                 # 1 — красная
        red = _smooth01((wave - 0.25) / 0.5)               # почти «вкл/выкл»
        red = max(red, kick)
        return jx, jy, jang, pop, red

    def _draw_temp_bomb(self, bomb):
        """Временная бомба: мигающая красная клетка, бомба того же размера,
        что и настоящие (BOMB_SCALE); трясётся при появлении, дрожит и
        дёргается на каждом тике, сильно мигает красным; отсчёт
        2.000→0.001. В «Орбите» клетка рисуется повёрнутой вместе с картой;
        во время тасовки бомба едет вместе со своей клеткой."""
        x, y = bomb["coord"]
        cell_sp = self.cell_sprites.get((x, y))
        if cell_sp is not None:
            lx, ly = self._sprite_local(cell_sp, (x, y))
        else:
            lx, ly = self.grid.center_arc(x, y)
        jx, jy, jang, pop, red_k = self._fugas_motion(bomb)
        if self._orbit_on():
            z = self.orbit_zoom
            cx, cy = self._orbit_local_to_world(lx, ly)
            tilt = -self.orbit_deg
            S = self.cell * z
            bomb_pos = self._orbit_local_to_world(lx + jx, ly + jy)
            text_pos = self._orbit_local_to_world(lx, ly - self.cell * 0.30)
        else:
            z = 1.0
            cx, cy = lx, ly
            tilt, S = 0.0, float(self.cell)
            bomb_pos = (lx + jx, ly + jy)
            text_pos = (lx, ly - self.cell * 0.30)
        t = max(0.0, self.fugas_t)
        frac = t / st.FUGAS_FUSE if st.FUGAS_FUSE else 0.0
        # мигающий красный фон клетки (поворачивается вместе с полем)
        arcade.draw_rect_filled(arcade.rect.XYWH(cx, cy, S, S),
                                (255, 40, 28, int(40 + 180 * red_k)),
                                tilt_angle=tilt)
        # пульсирующая рамка вокруг клетки
        arcade.draw_rect_outline(arcade.rect.XYWH(cx, cy, S - 2, S - 2),
                                 (255, 90, 66, 255),
                                 max(2, int(2 + 3 * red_k)), tilt_angle=tilt)
        # бомба — по центру клетки, размер как у настоящих; сильно мигает
        # красным (красная копия поверх) и дёргается
        sp, red = bomb["sprite"], bomb["red"]
        for s_ in (sp, red):
            s_.position = bomb_pos
            s_.angle = tilt + jang
            s_.scale = bomb["scale"] * z * pop
        red.alpha = int(25 + 230 * red_k)
        arcade.draw_sprite(sp)
        arcade.draw_sprite(red)
        # отсчёт с миллисекундами: 2.000 … 0.001 (текст — экрану, читать легче)
        if self.fugas_text:
            value = "{:.3f}".format(t)
            if self.fugas_text_shadow:
                self.fugas_text_shadow.value = value
                self.fugas_text_shadow.position = (text_pos[0] + 1.5,
                                                   text_pos[1] - 1.5)
                self.fugas_text_shadow.draw()
            self.fugas_text.value = value
            self.fugas_text.position = text_pos
            self.fugas_text.color = (255,
                                     int(80 + 175 * frac),
                                     int(80 + 175 * frac), 255)
            self.fugas_text.draw()

    def _draw_confirm(self):
        arcade.draw_lrbt_rectangle_filled(0, st.SCREEN_W, 0, st.SCREEN_H,
                                          (0, 0, 0, 140))
        self.confirm_panel_sprite.position = (st.SCREEN_W // 2,
                                              ui.Y(self.CONFIRM_Y))
        arcade.draw_sprite(self.confirm_panel_sprite)
        for wd in self.screens["confirm"]:
            if isinstance(wd, ui.Button):
                wd.draw(self.assets, self.mouse)
            else:
                wd.draw(self.mouse)

    def _toast_width(self, s):
        """Ширина надписи всплывашки (px) — мерим тем же шрифтом."""
        cache = self.__dict__.setdefault("_toast_w_cache", {})
        if s not in cache:
            try:
                from PIL import ImageFont
                font = ImageFont.truetype(os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "fonts", "DejaVuSans-Bold.ttf"), 22)
                cache[s] = max(font.getlength(line) for line in s.split("\n"))
            except Exception:
                cache[s] = 13.0 * len(s)
        return cache[s]

    def _draw_toast(self):
        if self.toast_t > 0 and self.toast_s:
            a = min(1.0, self.toast_t / 0.5)
            ps = self.toast_panel_sprite
            # длинная надпись — панель растягивается (края не искажаются)
            need = self._toast_width(self.toast_s) + 80
            base = self.assets.panel_toast
            if need > 660:
                k = 660.0 / max(1, base.width)
                w = int(math.ceil(need / 40.0)) * 40
                tex = self.assets.panel_stretch("panel_toast.png", w / k)
                if tex is not None and ps.texture is not tex:
                    ps.texture = tex
                ps.scale = k
            elif ps.texture is not base:
                ps.texture = base
                ps.scale = 660 / max(1, base.width)
            ps.alpha = int(255 * a)
            ps.position = (st.SCREEN_W // 2, ui.Y(634))
            arcade.draw_sprite(ps)
            if self._toast_text is None:
                self._toast_text = arcade.Text(
                    "", st.SCREEN_W // 2, ui.Y(634), (240, 244, 252, 255),
                    ui.ps(22), font_name="DejaVu Sans", bold=True,
                    anchor_x="center", anchor_y="center")
            self._toast_text.value = self.toast_s
            self._toast_text.color = (240, 244, 252, int(255 * a))
            self._toast_text.draw()


class ShakeDetector:
    """«Потряси мышкой»: быстрые рывки туда-обратно. Считаем смены
    направления по каждой оси; рывок засчитывается, если до разворота
    курсор прошёл не меньше LAMP_SHAKE_DIST px. Набралось
    LAMP_SHAKE_COUNT разворотов за LAMP_SHAKE_WINDOW секунд — тряска."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.turns = []                     # моменты разворотов
        self.sign = [0, 0]                  # текущее направление по x / y
        self.run = [0.0, 0.0]               # пройдено в этом направлении
        self.start = [0.0, 0.0]             # когда начался этот рывок

    def feed(self, dx, dy, t):
        """Сдвиг курсора за кадр (px) и время t (с). True — тряска."""
        win = float(st.LAMP_SHAKE_WINDOW)
        for ax, d in enumerate((dx, dy)):
            if abs(d) < 0.5:
                continue
            sg = 1 if d > 0 else -1
            if sg == self.sign[ax]:
                self.run[ax] += abs(d)
                continue
            # разворот: прошлый рывок был длинным и быстрым?
            if (self.sign[ax] != 0 and self.run[ax] >= st.LAMP_SHAKE_DIST
                    and t - self.start[ax] <= win):
                self.turns.append(t)
            self.sign[ax] = sg
            self.run[ax] = abs(d)
            self.start[ax] = t
        self.turns = [u for u in self.turns if t - u <= win]
        if len(self.turns) >= int(st.LAMP_SHAKE_COUNT):
            self.reset()
            return True
        return False


DARK_FULL_R = 0.08   # sprites/fog_dark.png: темнота полная с этой доли радиуса


def _clamp01(v):
    return 0.0 if v <= 0.0 else (1.0 if v >= 1.0 else v)


def _smooth01(p):
    p = _clamp01(p)
    return p * p * (3.0 - 2.0 * p)


def _smooth(a, b, x):
    """Плавный шаг: 0 при x <= a, 1 при x >= b."""
    return _smooth01((x - a) / (b - a)) if b != a else (0.0 if x < a else 1.0)


def _ease_out(p, k=3.0):
    p = _clamp01(p)
    return 1.0 - (1.0 - p) ** k


def _ease_in_out(p):
    p = _clamp01(p)
    return 4 * p * p * p if p < 0.5 else 1 - (-2 * p + 2) ** 3 / 2


def _ease_out_back(p, s=1.70158):
    """Плавный выход с небольшим «перелётом» за 1 и возвратом."""
    p = _clamp01(p)
    u = p - 1.0
    return 1.0 + (s + 1.0) * u * u * u + s * u * u


def _dark(color, k):
    return (max(0, min(255, int(color[0] * k))),
            max(0, min(255, int(color[1] * k))),
            max(0, min(255, int(color[2] * k))))
