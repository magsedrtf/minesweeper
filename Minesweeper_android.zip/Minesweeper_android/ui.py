# -*- coding: utf-8 -*-
"""Интерфейс Minesweeper на arcade: кнопки-спрайты, ленты, надписи.

Все виджеты рисуются PNG-спрайтами (sprites/) и встроенным текстом arcade.
Виртуальные координаты — как в классике: (0,0) слева сверху, y вниз.
Перевод в координаты arcade (y вверх) делает функция Y().
"""
import math
import os

import arcade

import settings as st

# pyglet измеряет шрифт в пунктах (1 pt = 4/3 px), pygame — в пикселях.
FONT_K = 0.75

_FONT_LOADED = False


def load_fonts():
    """Регистрируем DejaVu из fonts/ — одинаково на Windows/Linux/macOS."""
    global _FONT_LOADED
    if _FONT_LOADED:
        return
    here = os.path.dirname(os.path.abspath(__file__))
    for name in ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf"):
        p = os.path.join(here, "fonts", name)
        if os.path.exists(p):
            try:
                arcade.load_font(p)
            except Exception:
                pass
    _FONT_LOADED = True


def Y(y):
    """Экранная y (сверху вниз) -> координата arcade (снизу вверх)."""
    return st.SCREEN_H - y


def ps(px):
    """Размер шрифта pygame (px) -> размер arcade (pt)."""
    return px * FONT_K


class Rect:
    """Прямоугольник в виртуальных координатах (0,0 — левый верх)."""

    __slots__ = ("x", "y", "w", "h")

    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    @property
    def centerx(self):
        return self.x + self.w // 2

    @property
    def centery(self):
        return self.y + self.h // 2

    @property
    def right(self):
        return self.x + self.w

    @property
    def bottom(self):
        return self.y + self.h

    def collidepoint(self, pos):
        return (self.x <= pos[0] < self.x + self.w and
                self.y <= pos[1] < self.y + self.h)


def _rounded_path(pts, radii, segs=7):
    """Контур выпуклого многоугольника со скруглёнными углами
    (порт из pygame-версии — тот же алгоритм)."""
    n = len(pts)
    cx = sum(p[0] for p in pts) / n
    cy = sum(p[1] for p in pts) / n

    def inward(a, b):
        ex, ey = b[0] - a[0], b[1] - a[1]
        L = math.hypot(ex, ey) or 1.0
        nx, ny = -ey / L, ex / L
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        if nx * (cx - mx) + ny * (cy - my) < 0:
            nx, ny = -nx, -ny
        return nx, ny

    def project(a, b, p):
        ex, ey = b[0] - a[0], b[1] - a[1]
        L2 = ex * ex + ey * ey or 1.0
        k = max(0.0, min(1.0, ((p[0] - a[0]) * ex + (p[1] - a[1]) * ey) / L2))
        return (a[0] + ex * k, a[1] + ey * k)

    corners = []
    for i in range(n):
        r = radii[i]
        a, b, c = pts[i - 1], pts[i], pts[(i + 1) % n]
        n1 = inward(a, b)
        n2 = inward(b, c)
        x1, y1 = a[0] + n1[0] * r, a[1] + n1[1] * r
        x2, y2 = b[0] + n1[0] * r, b[1] + n1[1] * r
        x3, y3 = b[0] + n2[0] * r, b[1] + n2[1] * r
        x4, y4 = c[0] + n2[0] * r, c[1] + n2[1] * r
        den = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3)
        if abs(den) < 1e-9:
            cen = (b[0] + (n1[0] + n2[0]) * r / 2, b[1] + (n1[1] + n2[1]) * r / 2)
        else:
            t = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / den
            cen = (x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
        corners.append((project(a, b, cen), cen, project(b, c, cen), b, r))

    out = []
    for t1, cen, t2, b, r in corners:
        out.append(t1)
        a1 = math.atan2(t1[1] - cen[1], t1[0] - cen[0])
        a2 = math.atan2(t2[1] - cen[1], t2[0] - cen[0])
        d = a2 - a1
        while d > math.pi:
            d -= 2 * math.pi
        while d < -math.pi:
            d += 2 * math.pi
        mid = a1 + d / 2
        if math.cos(mid) * (b[0] - cen[0]) + math.sin(mid) * (b[1] - cen[1]) < 0:
            d += 2 * math.pi if d < 0 else -2 * math.pi
        for k in range(segs + 1):
            ang = a1 + d * k / segs
            out.append((cen[0] + math.cos(ang) * r, cen[1] + math.sin(ang) * r))
    return out


class Label:
    """Многострочная надпись: строки — arcade.Text, позиция обновляется
    без пересоздания (текст меняется через set_text)."""

    def __init__(self, x, y, s, size, color=st.CLR_TEXT, align="center", bold=True):
        self.pos = (x, y)
        self.size = size
        self.color = color
        self.align = align
        self.bold = bold
        self.visible = True
        self.off = (0, 0)
        self.shift = (0, 0)   # смещение анимации (не путать с off — параллаксом)
        self.alpha = 255      # прозрачность надписи 0..255 (для появления)
        self._alpha_applied = 255
        self.s = None
        self._lines = []      # [(Text, базовый_x, базовая_y_arcade), ...]
        self.set_text(s)

    def set_text(self, s, color=None):
        if color is not None:
            self.color = color
        key = (s, self.color)
        if key == self.s:
            return
        self.s = key
        self._lines = []
        if not s:
            return
        lines = s.split("\n")
        lh = int(self.size * 1.4)
        x = self.pos[0]
        y = self.pos[1] - (len(lines) * lh) // 2 + lh // 2
        anchors = {"center": ("center", "center"),
                   "midleft": ("left", "center"),
                   "midright": ("right", "center"),
                   "topleft": ("left", "top")}
        ax, ay = anchors.get(self.align, ("center", "center"))
        for i, ln in enumerate(lines):
            by = Y(y + i * lh)
            self._lines.append((arcade.Text(
                ln, x, by, self.color, ps(self.size), font_name="DejaVu Sans",
                bold=self.bold, anchor_x=ax, anchor_y=ay), x, by))
        self._base_color = self.color
        self._alpha_applied = 255 if len(self.color) < 4 else self.color[3]

    def draw(self, mouse=None):
        if not self.visible or self.alpha <= 0:
            return
        a = int(max(0, min(255, self.alpha)))
        if a != self._alpha_applied:
            col = tuple(self.color[:3]) + (a,)
            for t, _, _ in self._lines:
                t.color = col
            self._alpha_applied = a
        dx = self.off[0] + self.shift[0]
        dy = self.off[1] + self.shift[1]
        for t, bx, by in self._lines:
            t.position = (bx + dx, by - dy)
            t.draw()


class Icon:
    """Неподвижный спрайт (иконка скина) в интерфейсе."""

    def __init__(self, x, y, texture, target=None):
        self.pos = (x, y)
        self.visible = True
        self.off = (0, 0)
        self.shift = (0.0, 0.0)   # сдвиг прокрутки списка (инвентарь)
        self.alpha = 255
        self.clip = None          # Rect видимой части списка (или None)
        self.sprite = arcade.Sprite(texture)
        if target and texture.width:
            self.sprite.scale = target / texture.width
        self.sprite.position = (x, Y(y))

    def draw(self, mouse=None):
        if not self.visible or self.alpha <= 0:
            return
        self.sprite.position = (self.pos[0] + self.off[0] + self.shift[0],
                                Y(self.pos[1] + self.off[1] + self.shift[1]))
        a = int(max(0, min(255, self.alpha)))
        if self.sprite.alpha != a:
            self.sprite.alpha = a
        arcade.draw_sprite(self.sprite)


class _CachedText:
    """Строки кнопки: arcade.Text пересоздаётся только при смене текста,
    позиция обновляется каждый кадр (учитывает смещение/параллакс)."""

    def __init__(self):
        self.texts = []
        self.key = None
        self.fg = None

    def draw(self, lines, sizes, cx, cy, fg):
        key = (tuple(lines), tuple(sizes))
        if key != self.key:
            self.key = key
            self.fg = fg
            self.texts = [arcade.Text(
                ln, cx, 0, fg, ps(sizes[i]), font_name="DejaVu Sans",
                bold=True, anchor_x="center", anchor_y="center")
                for i, ln in enumerate(lines)]
        elif fg != self.fg:
            # цвет/прозрачность анимируются — текст не пересоздаём
            self.fg = fg
            for t in self.texts:
                t.color = fg
        total = sum(sizes) + (len(lines) - 1) * 10
        y = cy - total // 2
        for i, t in enumerate(self.texts):
            t.position = (cx, Y(y + sizes[i] // 2))
            t.draw()
            y += sizes[i] + 10


class Button:
    """Кнопка: PNG-панель (btn_*.png) + строки текста; плавное увеличение
    при наведении — как в pygame-версии."""

    def __init__(self, x, y, w, h, label, cb, bg="panel", size=26, fg=st.CLR_TEXT):
        self.rect = Rect(x, y, w, h)
        self.label = label
        self.cb = cb
        self.bg = bg      # ключ: green/grey/fire/exit/shop/panel/dark/selected
        self.size = size
        self.fg = fg
        self.visible = True
        self.enabled = True
        self.scale = 1.0
        self.off = (0, 0)
        self.sub_size = 0
        # анимация (экран «ИГРАТЬ»): сдвиг, яркость, доп. масштаб, прозрачность
        self.shift = (0.0, 0.0)
        self.dim = 1.0
        self.zoom = 1.0
        self.alpha = 255
        self.hover_k = 1.06
        # прокручиваемый список: кнопка ловит мышь только внутри clip
        # (видимой части колонки), иначе — «невидимые» клики за краем
        self.clip = None
        self._sprite = None
        self._tex_key = None
        self._text = _CachedText()

    def _contains(self, pos):
        """Попадание с учётом сдвига анимации, доп. масштаба и clip."""
        if self.clip is not None and not self.clip.collidepoint(pos):
            return False
        r = self.rect
        cx = r.x + r.w / 2.0 + self.shift[0]
        cy = r.y + r.h / 2.0 + self.shift[1]
        hw, hh = r.w * self.zoom / 2.0, r.h * self.zoom / 2.0
        return cx - hw <= pos[0] < cx + hw and cy - hh <= pos[1] < cy + hh

    def _hovered(self, mouse):
        return (self.visible and self.enabled and self.alpha > 0
                and self._contains(mouse))

    def _draw_panel(self, assets, cx, cy, rw, rh):
        tex = assets.button(self.bg, self.rect.w, self.rect.h)
        if self._sprite is None or self._tex_key != self.bg:
            self._sprite = arcade.Sprite(tex)
            self._tex_key = self.bg
        self._sprite.texture = tex
        self._sprite.scale = rw / tex.width
        self._sprite.position = (cx, Y(cy))
        v = int(255 * max(0.0, min(1.0, self.dim)))
        self._sprite.color = (v, v, v)
        self._sprite.alpha = int(max(0, min(255, self.alpha)))
        arcade.draw_sprite(self._sprite)

    def _fg(self):
        fg = self.fg if self.enabled else st.CLR_DIM
        if self.dim >= 0.999 and self.alpha >= 255:
            return fg
        k = max(0.0, min(1.0, self.dim))
        return (int(fg[0] * k), int(fg[1] * k), int(fg[2] * k),
                int(max(0, min(255, self.alpha))))

    def draw(self, assets, mouse):
        if not self.visible or self.alpha <= 0:
            return
        target = self.hover_k if self._hovered(mouse) else 1.0
        self.scale += (target - self.scale) * 0.22
        sc = self.scale * self.zoom
        cx = self.rect.centerx + self.off[0] + self.shift[0]
        cy = self.rect.centery + self.off[1] + self.shift[1]
        self._draw_panel(assets, cx, cy, self.rect.w * sc, self.rect.h * sc)

        lines = self.label.split("\n")
        base = [self.size if (i == 0 or not self.sub_size) else self.sub_size
                for i in range(len(lines))]
        if abs(self.zoom - 1.0) > 0.004:
            # уменьшенная кнопка — и текст чуть меньше (шаг 1 px: без дрожи)
            sizes = [max(8, int(round(sz * self.zoom))) for sz in base]
        else:
            sizes = base
        self._text.draw(lines, sizes, cx, cy, self._fg())

    def hit(self, pos):
        return (self.visible and self.enabled and self.alpha > 0
                and self._contains(pos))


class CheckCard:
    """Карточка испытания с чекбоксом: клик переключает выбор.
    Испытания можно соединять — отмечается несколько карточек сразу."""

    def __init__(self, x, y, w, h, title, sub, checked, cb):
        self.rect = Rect(x, y, w, h)
        self.title = title
        self.sub = sub
        self.checked = checked
        self.cb = cb
        self.visible = True
        self.enabled = True
        self.scale = 1.0
        self.off = (0, 0)
        self.shift = (0.0, 0.0)   # анимация появления
        self.alpha = 255
        self.zoom = 1.0
        self._sprite = None
        self._tex_key = None
        self._t1 = None
        self._t2 = None
        self._mark = None
        self._alpha_applied = None

    def _contains(self, pos):
        r = self.rect
        return (r.x + self.shift[0] <= pos[0] < r.x + r.w + self.shift[0] and
                r.y + self.shift[1] <= pos[1] < r.y + r.h + self.shift[1])

    def _hovered(self, mouse):
        return (self.visible and self.enabled and self.alpha > 0
                and self._contains(mouse))

    def hit(self, pos):
        return (self.visible and self.enabled and self.alpha > 0
                and self._contains(pos))

    def toggle(self):
        self.checked = not self.checked

    def draw(self, assets, mouse):
        if not self.visible or self.alpha <= 0:
            return
        target = 1.02 if self._hovered(mouse) else 1.0
        self.scale += (target - self.scale) * 0.22
        sc = self.scale * self.zoom
        r = self.rect
        a = int(max(0, min(255, self.alpha)))
        cx = r.centerx + self.off[0] + self.shift[0]
        cy = r.centery + self.off[1] + self.shift[1]
        key = "green" if self.checked else "panel"
        tex = assets.button(key, r.w, r.h)
        if self._sprite is None or self._tex_key != key:
            self._sprite = arcade.Sprite(tex)
            self._tex_key = key
        self._sprite.texture = tex
        self._sprite.scale = (r.w * sc) / tex.width
        self._sprite.position = (cx, Y(cy))
        self._sprite.alpha = a
        arcade.draw_sprite(self._sprite)

        # чекбокс слева на карточке — место для галочки
        bs = 30 * sc
        bx = cx - r.w * sc / 2.0 + 32 * sc
        by = Y(cy)      # в координаты arcade (y вверх)
        arcade.draw_rect_filled(arcade.rect.XYWH(bx, by, bs, bs),
                                (16, 20, 32, int(235 * a / 255)))
        stroke = st.CLR_GOLD if self.checked else st.CLR_STROKE
        arcade.draw_rect_outline(arcade.rect.XYWH(bx, by, bs, bs),
                                 tuple(stroke[:3]) + (a,), 2)
        if self._alpha_applied != a:
            # прозрачность текста меняется только во время появления
            self._alpha_applied = a
            for t, col in ((self._mark, st.CLR_GOLD), (self._t1, st.CLR_TEXT),
                           (self._t2, st.CLR_DIM)):
                if t is not None:
                    t.color = tuple(col[:3]) + (a,)
        if self.checked:
            if self._mark is None:
                self._mark = arcade.Text(
                    "✓", bx, by, tuple(st.CLR_GOLD[:3]) + (a,), ps(24),
                    font_name="DejaVu Sans", bold=True,
                    anchor_x="center", anchor_y="center")
            self._mark.position = (bx, by)
            self._mark.draw()

        # заголовок с множителем + описание
        tx = bx + bs / 2 + 20
        if self._t1 is None:
            self._t1 = arcade.Text(
                "", tx, 0, tuple(st.CLR_TEXT[:3]) + (a,), ps(23),
                font_name="DejaVu Sans",
                bold=True, anchor_x="left", anchor_y="center")
            self._t2 = arcade.Text(
                "", tx, 0, tuple(st.CLR_DIM[:3]) + (a,), ps(16),
                font_name="DejaVu Sans",
                bold=False, anchor_x="left", anchor_y="center")
        self._t1.value = self.title
        self._t2.value = self.sub
        dy1, dy2 = r.h * 0.22 * sc, r.h * 0.21 * sc   # 72 px: −16 / +15
        self._t1.position = (tx, Y(cy - dy1))
        self._t2.position = (tx, Y(cy + dy2))
        self._t1.draw()
        self._t2.draw()


class RibbonButton(Button):
    """Лента главного меню: PNG-спрайт с иконкой и косым срезом «/»,
    текст слева; при наведении плавно увеличивается."""

    RIBBON_PAD = 6   # запас под тень внутри спрайта (рендер: h + 6)

    def __init__(self, x, y, w, h, label, cb, bg, icon_kind, size=25):
        super().__init__(x, y, w, h, label, cb, bg, size)
        self.icon_kind = icon_kind
        self._label_text = None

    def draw(self, assets, mouse):
        if not self.visible:
            return
        target = 1.07 if self._hovered(mouse) else 1.0
        self.scale += (target - self.scale) * 0.22
        sc = self.scale
        r = self.rect
        cx, cy = r.centerx + self.off[0], r.centery + self.off[1]
        w = r.w * sc
        tex = assets.ribbons[self.icon_kind]
        if self._sprite is None:
            self._sprite = arcade.Sprite(tex)
        self._sprite.texture = tex
        self._sprite.scale = w / tex.width
        # тело ленты смещено вверх на RIBBON_PAD/2 внутри спрайта
        self._sprite.position = (cx, Y(cy + self.RIBBON_PAD // 2))
        arcade.draw_sprite(self._sprite)
        cap = (r.h // 2) * sc
        tx = cx - w / 2 + cap + 8
        if self._label_text is None:
            self._label_text = arcade.Text(
                self.label, tx, Y(cy - 2), (255, 255, 255), ps(self.size),
                font_name="DejaVu Sans", bold=True,
                anchor_x="left", anchor_y="center")
        else:
            self._label_text.value = self.label
        self._label_text.position = (tx, Y(cy - 2))
        self._label_text.draw()


def field_frame_points(V):
    """Точки двух «утопленных» рамок вокруг поля (порт draw_field_frame)."""
    def poly(x, y, w, h, rad):
        pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
        path = _rounded_path(pts, [rad] * 4)
        return [(px, Y(py)) for px, py in path]

    return (poly(V.ox - 6, V.oy - 6, V.w + 12, V.h + 12, 4),
            poly(V.ox - 3, V.oy - 3, V.w + 6, V.h + 6, 3))
