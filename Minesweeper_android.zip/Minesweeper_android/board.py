# -*- coding: utf-8 -*-
"""Игровое поле: расстановка мин, открытие, флажки, «аккорд», разведка.
Чистая логика без графики — покрывается юнит-тестами."""

import random


class Cell:
    __slots__ = ("mine", "adj", "revealed", "flagged", "exploded")

    def __init__(self):
        self.mine = False
        self.adj = 0
        self.revealed = False
        self.flagged = False
        self.exploded = False


class Board:
    def __init__(self, cols, rows, mines, seed=None):
        self.cols = cols
        self.rows = rows
        self.mines = mines
        self.grid = [[Cell() for _ in range(cols)] for _ in range(rows)]
        self.mines_placed = False
        self.revealed_safe = 0
        self.flags_used = 0

    # --- геометрия ---

    def in_range(self, x, y):
        return 0 <= x < self.cols and 0 <= y < self.rows

    def cell(self, x, y):
        return self.grid[y][x]

    def neighbors(self, x, y):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if self.in_range(nx, ny):
                    yield nx, ny

    # --- мины ---

    def place_mines(self, safe_x, safe_y, rng=None):
        """Мины после первого клика: клетка и её 8 соседей всегда чисты."""
        rng = rng or random
        spots = [(x, y) for y in range(self.rows) for x in range(self.cols)
                 if abs(x - safe_x) > 1 or abs(y - safe_y) > 1]
        rng.shuffle(spots)
        for x, y in spots[:min(self.mines, len(spots))]:
            self.cell(x, y).mine = True
        for y in range(self.rows):
            for x in range(self.cols):
                c = self.cell(x, y)
                if not c.mine:
                    c.adj = sum(1 for nx, ny in self.neighbors(x, y)
                                if self.cell(nx, ny).mine)
        self.mines_placed = True

    def mine_list(self):
        return [(x, y) for y in range(self.rows) for x in range(self.cols)
                if self.cell(x, y).mine]

    # --- действия игрока ---

    def reveal(self, x, y):
        """Открыть клетку. Возвращает список открытых клеток,
        либо None, если попал по мине (взрыв обрабатывает вызывающий)."""
        c = self.cell(x, y)
        if c.revealed or c.flagged:
            return []
        if c.mine:
            return None
        opened = []
        stack = [(x, y)]
        while stack:
            cx, cy = stack.pop()
            if not self.in_range(cx, cy):
                continue
            cc = self.cell(cx, cy)
            if cc.revealed or cc.flagged or cc.mine:
                continue
            cc.revealed = True
            self.revealed_safe += 1
            opened.append((cx, cy))
            if cc.adj == 0:
                stack.extend(self.neighbors(cx, cy))
        return opened

    def toggle_flag(self, x, y):
        c = self.cell(x, y)
        if c.revealed:
            return False
        c.flagged = not c.flagged
        self.flags_used += 1 if c.flagged else -1
        return True

    def flags_around(self, x, y):
        return sum(1 for nx, ny in self.neighbors(x, y) if self.cell(nx, ny).flagged)

    def chord(self, x, y):
        """Аккорд: на открытом числе открыть соседей, если флажков ровно столько.
        Возвращает (открытые_клетки, мина_или_None)."""
        c = self.cell(x, y)
        if not (c.revealed and c.adj > 0 and self.flags_around(x, y) == c.adj):
            return [], None
        opened, mine = [], None
        for nx, ny in self.neighbors(x, y):
            nc = self.cell(nx, ny)
            if nc.revealed or nc.flagged:
                continue
            if nc.mine:
                return [], (nx, ny)
        for nx, ny in self.neighbors(x, y):
            nc = self.cell(nx, ny)
            if not nc.revealed and not nc.flagged and not nc.mine:
                opened.extend(self.reveal(nx, ny) or [])
        return opened, None

    # --- фугас (испытание «ФУГАС») ---

    def zone3x3(self, x, y):
        """Клетки в радиусе 1 от (x, y), включая саму клетку."""
        cells = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                nx, ny = x + dx, y + dy
                if self.in_range(nx, ny):
                    cells.append((nx, ny))
        return cells

    def reshuffle_zone(self, x, y, rng=None):
        """Взрыв временной бомбы в (x, y): зона 3×3 закрывается, мины внутри
        неё перемешиваются заново (общее число мин на поле сохраняется),
        числа пересчитываются в зоне и у всех её соседей.
        Флажки вне зоны не трогаются, внутри зоны снимаются — позиции мин
        там всё равно изменились. Возвращает число закрытых клеток."""
        rng = rng or random
        zone = self.zone3x3(x, y)

        # закрыть клетки зоны, снять флажки внутри зоны
        closed = 0
        for cx, cy in zone:
            c = self.cell(cx, cy)
            if c.flagged:
                c.flagged = False
                self.flags_used -= 1
            if c.revealed:
                c.revealed = False
                self.revealed_safe -= 1
                closed += 1

        # перемешать мины: сколько было в зоне — столько и заново, но случайно
        k = sum(1 for cx, cy in zone if self.cell(cx, cy).mine)
        for cx, cy in zone:
            self.cell(cx, cy).mine = False
        spots = zone[:]
        rng.shuffle(spots)
        for cx, cy in spots[:k]:
            self.cell(cx, cy).mine = True

        # пересчитать числа: клетки зоны + все клетки-соседи зоны
        touched = set(zone)
        for cx, cy in zone:
            touched.update(self.neighbors(cx, cy))
        for cx, cy in touched:
            c = self.cell(cx, cy)
            if not c.mine:
                c.adj = sum(1 for nx, ny in self.neighbors(cx, cy)
                            if self.cell(nx, ny).mine)
        return closed

    # --- испытание «ТАСОВКА» ---

    def shuffle_swap(self, vertical, width, side, rng=None):
        """Тасовка: полоса шириной width отсоединяется и меняется местами
        с оставшейся частью («портал»). vertical=True — тасуем столбцы
        (полоса слева/справа: side 'low'/'high'), иначе строки
        (сверху/снизу). Улетевшая часть обнуляется: свежие закрытые клетки,
        флажки сняты, мины внутри новой полосы расставляются заново —
        столько же, сколько улетело (общее число мин сохраняется), числа
        пересчитываются в полосе и у клеток оставшейся части у шва.
        Оставшаяся часть не меняется — только сдвигается. Возвращает
        координаты клеток новой полосы в её итоговом месте."""
        rng = rng or random
        n = self.cols if vertical else self.rows
        k = max(1, min(width, n - 1))
        hi = (side == "high")

        if vertical:
            xs_strip = list(range(n - k, n)) if hi else list(range(k))
            xs_rest = list(range(n - k)) if hi else list(range(k, n))
            strip_coords = [(x, y) for y in range(self.rows) for x in xs_strip]
            strip_cells = [row[x] for row in self.grid for x in xs_strip]
            rest = [[row[x] for x in xs_rest] for row in self.grid]
            fresh = [[Cell() for _ in xs_strip] for _ in self.grid]
            if hi:      # полоса справа: оставшаяся часть уезжает вправо
                self.grid = [f + r for f, r in zip(fresh, rest)]
            else:       # полоса слева: новая встаёт справа
                self.grid = [r + f for r, f in zip(rest, fresh)]
            slot = [(x, y) for y in range(self.rows)
                    for x in (range(k) if hi else range(n - k, n))]
        else:
            ys_strip = range(n - k, n) if hi else range(k)
            ys_rest = range(n - k) if hi else range(k, n)
            strip_coords = [(x, y) for y in ys_strip for x in range(self.cols)]
            strip_cells = [c for y in ys_strip for c in self.grid[y]]
            rest = [self.grid[y][:] for y in ys_rest]
            fresh = [[Cell() for _ in range(self.cols)] for _ in range(k)]
            if hi:      # полоса снизу: оставшаяся часть уезжает вниз
                self.grid = fresh + rest
            else:       # полоса сверху: новая встаёт снизу
                self.grid = rest + fresh
            slot = [(x, y) for y in (range(k) if hi else range(n - k, n))
                    for x in range(self.cols)]

        # улетевшая часть обнуляется: флажки и открытия уходят вместе с ней
        for c in strip_cells:
            if c.flagged:
                c.flagged = False
                self.flags_used -= 1
            if c.revealed and not c.exploded:
                self.revealed_safe -= 1

        # мины в новой полосе: столько же, сколько улетело
        k_mines = sum(1 for c in strip_cells if c.mine)
        spots = slot[:]
        rng.shuffle(spots)
        for x, y in spots[:k_mines]:
            self.cell(x, y).mine = True

        # числа: новая полоса + клетки оставшейся части у обоих швов —
        # у нового шва соседями стали клетки новой полосы, у старого шва
        # соседей-мин улетевшей полосы не стало (координаты old-шва после
        # сдвига указывают на сдвинутые клетки — их и пересчитываем)
        touched = set(slot)
        for x, y in slot:
            touched.update(self.neighbors(x, y))
        for x, y in strip_coords:
            touched.update(self.neighbors(x, y))
        for x, y in touched:
            c = self.cell(x, y)
            if not c.mine:
                c.adj = sum(1 for nx, ny in self.neighbors(x, y)
                            if self.cell(nx, ny).mine)
        self.mines_placed = True
        return slot

    def shuffle_auto_open(self, slot, rng=None):
        """После прилёта новой полосы: открыть одну случайную безопасную
        клетку внутри неё — как первое нажатие (с каскадом нулей).
        Возвращает список открытых клеток, None — если безопасных нет."""
        rng = rng or random
        candidates = [(x, y) for x, y in slot if not self.cell(x, y).mine]
        if not candidates:
            return None
        return self.reveal(*rng.choice(candidates))

    # --- исход ---

    def all_safe_revealed(self):
        return self.revealed_safe >= self.cols * self.rows - self.mines

    def mines_left(self):
        return self.mines - self.flags_used
