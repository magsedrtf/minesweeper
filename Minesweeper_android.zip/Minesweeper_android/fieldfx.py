# -*- coding: utf-8 -*-
"""Украшения и эффекты скинов поля (патч 11).

Всё здесь — только картинка: логика сапёра (board.py, клики, испытания)
о FieldFX ничего не знает. Набор для каждого скина — settings.FIELD_FX:

    deco     — украшения на ЗАКРЫТЫХ клетках (трава и цветы на мху,
               замки и игрушки на пляже, тыквы на хеллоуине...): часть
               клеток получает картинку, открыли клетку (или поставили
               флажок) — украшение «пыхает» и исчезает;
    grow_*   — новые украшения со временем вырастают (мох);
    snowman  — снеговик на одной закрытой клетке (лёд); клетку открыли —
               переходит на другую;
    snow / petals — падающий снег / лепестки сакуры по всему экрану;
    tumble   — иногда через поле катится перекати-поле (песок);
    bats     — иногда пролетает летучая мышь (хеллоуин);
    hearts / sparkle — сердечки (розовое) / блёстки (алмазное);
    glitch   — поле «лагает»: дёргается, полосы клеток съезжают (ERROR).

Украшение привязано к СПРАЙТУ клетки, а не к координате: поэтому оно
само едет с тасовкой (и улетает с полосой), крутится с «Орбитой» и
масштабируется зумом. PNG — sprites/deco_*.png и sprites/fx_*.png
(рисует tools/gen_fields.py).
"""
import math
import random

import arcade

import settings as st

# name: (высота — доля клетки, якорь, анимация)
#   якорь: bottom — стоит на клетке (вертикально, как флажки);
#          flat — лежит на клетке (крутится вместе с картой);
#          corner — в левом верхнем углу клетки (паутина)
DECO = {
    "grass1": (0.36, "bottom", "sway"), "grass2": (0.40, "bottom", "sway"),
    "grass3": (0.30, "bottom", "sway"),
    "flower_r": (0.52, "bottom", "sway"), "flower_y": (0.52, "bottom", "sway"),
    "flower_b": (0.50, "bottom", "sway"), "flower_w": (0.52, "bottom", "sway"),
    "flowers2": (0.54, "bottom", "sway"),
    "castle": (0.62, "bottom", None), "tower": (0.56, "bottom", None),
    "bucket": (0.56, "bottom", None), "spade": (0.60, "bottom", None),
    "ball": (0.42, "bottom", None), "starfish": (0.40, "flat", None),
    "shell": (0.32, "flat", None), "duck": (0.44, "bottom", "bob_s"),
    "jack": (0.52, "bottom", "flicker"), "candle": (0.60, "bottom", "frames"),
    "ghost": (0.56, "bottom", "bob"), "skull": (0.40, "bottom", None),
    "tomb": (0.56, "bottom", None), "candy": (0.30, "flat", None),
    "web": (0.62, "corner", None),
    "snowman": (0.90, "bottom", None),
    "petals": (0.46, "flat", None), "petals2": (0.40, "flat", None),
    "gem_c": (0.38, "bottom", None), "gem_p": (0.36, "bottom", None),
    "gem_g": (0.36, "bottom", None),
    "pawn": (0.60, "bottom", None), "rook": (0.62, "bottom", None),
    "bishop": (0.66, "bottom", None),
}
CHESS = ("pawn", "rook", "bishop")      # цвет фигуры — против цвета клетки
GROW_T = 0.55                            # вырастание украшения, с
DIE_T = 0.18                             # исчезновение при открытии, с


def _ease_back(p):
    p = max(0.0, min(1.0, p))
    c = 1.70158
    return 1 + (c + 1) * (p - 1) ** 3 + c * (p - 1) ** 2


def _rng_range(rng, r):
    return rng.uniform(r[0], r[1]) if isinstance(r, (tuple, list)) else float(r)


class FieldFX:
    """Украшения/эффекты одного скина поля в одной партии."""

    def __init__(self, game, skin, rng=None):
        self.g = game
        self.skin = skin
        on = getattr(st, "FIELD_FX_ON", True)
        self.cfg = dict(st.FIELD_FX.get(skin, {})) if on else {}
        self.rng = rng or random.Random()
        self.t = 0.0
        self.decos = {}            # id(спрайт клетки) -> украшение | None
        self.deco_list = arcade.SpriteList()
        self.ground_list = arcade.SpriteList()   # блёстки, сердечки, перекати-поле, мыши
        self.air_list = arcade.SpriteList()      # снег, лепестки (поверх тумана)
        self.glitch_list = arcade.SpriteList()
        self.snowman = None
        self.jitter = (0.0, 0.0)
        self.blocks = []           # «битые» прямоугольники ERROR
        self.movers = []           # перекати-поле / летучие мыши
        self.pops = []             # блёстки / сердечки
        self.flakes = []           # снег / лепестки
        self._gl_pool = []
        self._gl_used = 0
        self.glitch_on = 0.0       # сколько ещё длится «лаг»
        self._gl_step = 0.0
        self._gl_bands = []
        self._gl_micro = None
        w = self.cfg.get("deco") or {}
        self._weights = [(k, float(v)) for k, v in w.items() if k in DECO]
        self._wsum = sum(v for _, v in self._weights)
        self.chance = float(self.cfg.get("chance", 0.0)) if self._weights else 0.0
        self.grow_t = _rng_range(self.rng, self.cfg["grow_every"]) if "grow_every" in self.cfg else None
        self.tumble_t = _rng_range(self.rng, st.TUMBLE_EVERY) * 0.5
        self.bat_t = _rng_range(self.rng, st.BAT_EVERY) * 0.6
        self.pop_t = 0.4
        self.glitch_t = _rng_range(self.rng, st.GLITCH_EVERY)
        self.micro_t = _rng_range(self.rng, st.GLITCH_MICRO)
        self._first = True

    # ---------- общие ----------

    @property
    def active(self):
        return bool(self.cfg)

    def _xf(self):
        """Поворот (cos, sin) и зум карты: украшения едут вместе с ней."""
        g = self.g
        if g._orbit_on():
            th = math.radians(g.orbit_deg)
            return math.cos(th), math.sin(th), g.orbit_zoom, -g.orbit_deg
        return 1.0, 0.0, 1.0, 0.0

    def _cells(self):
        """{id(спрайт): (спрайт, координата | None)} — все клетки, которые
        сейчас рисуются, включая улетающую полосу тасовки (координата None)."""
        out = {}
        for coord, sp in self.g.cell_sprites.items():
            out[id(sp)] = (sp, coord)
        a = self.g.shuffle_anim
        if a and a.get("stage") == "out":
            meta = a.get("out_meta", {})
            for sp, _, _ in a.get("out", ()):
                if meta.get(id(sp), (False,))[0] and id(sp) not in out:
                    out[id(sp)] = (sp, None)
        return out

    def _closed(self, coord):
        c = self.g.board.cell(*coord)
        return not c.revealed and not c.flagged

    def _pick_name(self):
        r = self.rng.uniform(0.0, self._wsum)
        for k, v in self._weights:
            r -= v
            if r <= 0:
                return k
        return self._weights[-1][0]

    def _new_deco(self, name, sp, grow=1.0):
        h, anchor, anim = DECO[name]
        if name in CHESS:
            # светлая клетка — чёрная фигура, тёмная — белая
            light = sp.texture is self.g._tile_textures()[0]
            name = name + ("_b" if light else "_w")
        _, _, z, _ = self._xf()
        px = max(8, int(round(2.0 * h * self.g.cell * z)))
        frames = self.g.assets.deco_frames("deco_" + name, px)
        if not frames:
            return None
        rng = self.rng
        if anchor == "corner":
            off = (0.0, 0.0)
        elif anchor == "flat":
            off = (rng.uniform(-0.14, 0.14), rng.uniform(-0.14, 0.10))
        elif name == "snowman":
            off = (rng.uniform(-0.04, 0.04), -0.42)
        else:
            off = (rng.uniform(-0.16, 0.16), rng.uniform(-0.40, -0.26) + (0.5 - h) * 0.25)
        d = {
            "name": name, "base": "deco_" + name, "frames": frames, "h": h, "anchor": anchor, "anim": anim,
            "off": off, "phase": rng.uniform(0, math.tau), "rot": rng.uniform(-25, 25)
            if anchor == "flat" else 0.0, "grow": grow, "die": None, "cell": sp,
            "px": 0, "tex": None,
        }
        spr = arcade.Sprite(frames[0])
        spr.alpha = 255
        d["sprite"] = spr
        self.deco_list.append(spr)
        return d

    def _drop(self, d):
        try:
            self.deco_list.remove(d["sprite"])
        except ValueError:
            pass

    # ---------- кадр ----------

    def update(self, dt):
        if not self.active or self.g.board is None:
            return
        self.t += dt
        cells = self._cells()
        self._update_decos(dt, cells)
        if self.cfg.get("snowman"):
            self._update_snowman(dt, cells)
        if self.grow_t is not None:
            self._update_grow(dt, cells)
        if self.cfg.get("snow") or self.cfg.get("petals"):
            self._update_flakes(dt)
        if self.cfg.get("tumble") or self.cfg.get("bats"):
            self._update_movers(dt)
        if self.cfg.get("hearts") or self.cfg.get("sparkle"):
            self._update_pops(dt, cells)
        if self.cfg.get("glitch"):
            self._update_glitch(dt, cells)
        self._first = False

    def _update_decos(self, dt, cells):
        # новые клетки (старт партии, прилетевшая полоса тасовки)
        for key, (sp, coord) in cells.items():
            if key in self.decos:
                continue
            d = None
            if (coord is not None and self.chance > 0 and self._closed(coord)
                    and self.rng.random() < self.chance):
                d = self._new_deco(self._pick_name(), sp, 1.0 if self._first else 0.0)
            self.decos[key] = d
        # ушедшие спрайты (улетевшая полоса, пересборка поля)
        for key in [k for k in self.decos if k not in cells]:
            d = self.decos.pop(key)
            if d:
                self._drop(d)
        c, s, z, ang = self._xf()
        S = self.g.cell
        for key, d in self.decos.items():
            if d is None:
                continue
            sp, coord = cells[key]
            self._place_deco(d, sp, coord, dt, c, s, z, ang, S)
        for key in [k for k, d in self.decos.items() if d and d.get("gone")]:
            self._drop(self.decos[key])
            self.decos[key] = None

    def _place_deco(self, d, sp, coord, dt, c, s, z, ang, S):
        spr = d["sprite"]
        if coord is not None and d["die"] is None and not self._closed(coord):
            d["die"] = 0.0
            self._poof(d, spr.position)
        k = 1.0
        if d["die"] is not None:
            d["die"] += dt
            k = max(0.0, 1.0 - d["die"] / DIE_T)
            if k <= 0.0:
                d["gone"] = True
                spr.alpha = 0
                return
        if d["grow"] < 1.0:
            d["grow"] = min(1.0, d["grow"] + dt / GROW_T)
            k *= max(0.0, _ease_back(d["grow"]))
        # кадр анимации
        fr = d["frames"]
        if len(fr) > 1:
            if d["anim"] == "flicker":
                n = math.sin(self.t * 7.3 + d["phase"]) * math.sin(self.t * 3.1 + d["phase"] * 2)
                tex = fr[1 if n > 0.25 else 0]
            else:
                tex = fr[int(self.t * 8.0 + d["phase"]) % len(fr)]
            if spr.texture is not tex:
                spr.texture = tex
        disp_h = d["h"] * S * z
        tex = spr.texture
        th = max(1, tex.height)
        sc = disp_h / th * k
        spr.scale = sc
        spr.alpha = int(255 * (min(1.0, k * 1.6) if d["die"] is not None else 1.0))
        hw, hh = tex.width * sc / 2.0, th * sc / 2.0
        px, py = sp.position
        if d["anchor"] == "corner":
            # левый верхний угол клетки, крутится вместе с картой
            lx = -0.5 * S + 0.04 * S + hw / z
            ly = 0.5 * S - 0.04 * S - hh / z
            spr.position = (px + z * (lx * c - ly * s), py + z * (lx * s + ly * c))
            spr.angle = ang
            return
        ox, oy = d["off"][0] * S, d["off"][1] * S
        ax, ay = px + z * (ox * c - oy * s), py + z * (ox * s + oy * c)
        if d["anchor"] == "flat":
            spr.position = (ax, ay)
            spr.angle = ang + d["rot"]
            return
        a = 0.0
        if d["anim"] == "sway":
            a = 5.0 * math.sin(self.t * 1.7 + d["phase"]) + 2.0 * math.sin(self.t * 3.9 + d["phase"])
        elif d["anim"] == "bob":
            ay += math.sin(self.t * 2.2 + d["phase"]) * 0.05 * S * z
        elif d["anim"] == "bob_s":
            a = 4.0 * math.sin(self.t * 1.4 + d["phase"])
        r = math.radians(a)
        # поворот вокруг основания (как травинка на ветру)
        spr.position = (ax + hh * math.sin(r), ay + hh * math.cos(r))
        spr.angle = a

    def _poof(self, d, pos):
        """Клетку открыли — украшение «пыхает» (крошки его цвета)."""
        col = self.g.assets.deco_color(d["base"])
        x, y = pos
        n = 7 if d["name"] == "snowman" else 5
        for _ in range(n):
            a = self.rng.uniform(0, math.tau)
            v = self.rng.uniform(40, 120)
            life = self.rng.uniform(0.25, 0.45)
            self.g.particles.append([x, st.SCREEN_H - y, math.cos(a) * v,
                                     -abs(math.sin(a)) * v - 60, life, life,
                                     self.rng.uniform(1.5, 3.0), col])

    # ---------- мох: новые украшения вырастают ----------

    def _update_grow(self, dt, cells):
        self.grow_t -= dt
        if self.grow_t > 0:
            return
        self.grow_t = _rng_range(self.rng, self.cfg["grow_every"])
        if self.g.ended:
            return
        total = max(1, len(self.g.cell_sprites))
        have = sum(1 for d in self.decos.values() if d and d["die"] is None)
        if have >= float(self.cfg.get("grow_max", 0.25)) * total:
            return
        free = [(k, sp) for k, (sp, coord) in cells.items()
                if coord is not None and self.decos.get(k) is None and self._closed(coord)
                and (self.snowman is None or self.snowman["cell"] is not sp)]
        if free:
            k, sp = self.rng.choice(free)
            self.decos[k] = self._new_deco(self._pick_name(), sp, 0.0)

    # ---------- лёд: снеговик ----------

    def _update_snowman(self, dt, cells):
        sm = self.snowman
        if sm is not None:
            ok = id(sm["cell"]) in cells
            coord = cells[id(sm["cell"])][1] if ok else None
            if ok and sm["die"] is None and coord is not None and not self._closed(coord):
                sm["die"] = 0.0
                self._poof(sm, sm["sprite"].position)
            if not ok or sm.get("gone"):
                self._drop(sm)
                sm = self.snowman = None
        if sm is None:
            free = [sp for sp, coord in cells.values()
                    if coord is not None and self._closed(coord)
                    and self.decos.get(id(sp)) is None]
            if not free:
                return
            sp = self.rng.choice(free)
            sm = self.snowman = self._new_deco("snowman", sp, 1.0 if self._first else 0.0)
            if sm is None:
                return
        sp = sm["cell"]
        coord = cells[id(sp)][1]
        c, s, z, ang = self._xf()
        self._place_deco(sm, sp, coord, dt, c, s, z, ang, self.g.cell)

    # ---------- снег и лепестки ----------

    def _spawn_flake(self, top=True):
        rng = self.rng
        W, H = st.SCREEN_W, st.SCREEN_H
        petals = bool(self.cfg.get("petals"))
        if petals:
            tex = self.g.assets.fx_tex("fx_petal", 40)
            size = rng.uniform(11, 18)
            vy = -rng.uniform(*st.PETAL_SPEED)
            vx = rng.uniform(0.4, 1.0) * st.PETAL_WIND
        else:
            star = rng.random() < 0.22
            tex = self.g.assets.fx_tex("fx_flake" if star else "fx_snow", 32)
            size = rng.uniform(9, 14) if star else rng.uniform(3, 7.5)
            vy = -rng.uniform(*st.SNOW_SPEED) * (0.8 if star else 1.0)
            vx = rng.uniform(-6, 6)
        sp = arcade.Sprite(tex)
        sp.alpha = int(rng.uniform(170, 240))
        f = {"sp": sp, "x": rng.uniform(-30, W + 30),
             "y": H + rng.uniform(10, 60) if top else rng.uniform(-10, H),
             "vx": vx, "vy": vy, "size": size, "tex_w": max(1, tex.width),
             "ph": rng.uniform(0, math.tau), "w": rng.uniform(0.6, 1.4),
             "amp": rng.uniform(8, 22), "spin": rng.uniform(-90, 90), "ang": rng.uniform(0, 360),
             "petal": petals}
        self.air_list.append(sp)
        self.flakes.append(f)
        return f

    def _update_flakes(self, dt):
        n = int(self.cfg.get("snow") or self.cfg.get("petals") or 0)
        while len(self.flakes) < n:
            self._spawn_flake(top=not self._first)
        for f in self.flakes:
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["ang"] += f["spin"] * dt
            if f["y"] < -30 or f["x"] > st.SCREEN_W + 50:
                f["y"] = st.SCREEN_H + self.rng.uniform(10, 40)
                f["x"] = self.rng.uniform(-60, st.SCREEN_W)
            sw = math.sin(self.t * f["w"] + f["ph"]) * f["amp"]
            sp = f["sp"]
            sp.position = (f["x"] + sw, f["y"])
            sc = f["size"] / f["tex_w"]
            if f["petal"]:
                # лепесток кувыркается: ширина «дышит» как у плоской пластинки
                fl = 0.25 + 0.75 * abs(math.cos(self.t * f["w"] * 2.0 + f["ph"]))
                sp.scale = (sc * fl, sc)
                sp.angle = f["ang"]
            else:
                sp.scale = sc
                sp.angle = f["ang"]

    # ---------- перекати-поле и летучие мыши ----------

    def _board_box(self):
        """Рамка поля на экране (мир, y вверх): left, right, bottom, top."""
        xs, ys = [], []
        for sp in self.g.cell_sprites.values():
            xs.append(sp.position[0])
            ys.append(sp.position[1])
        if not xs:
            return 0, st.SCREEN_W, 0, st.SCREEN_H
        _, _, z, _ = self._xf()
        h = self.g.cell * z / 2.0
        return min(xs) - h, max(xs) + h, min(ys) - h, max(ys) + h

    def _spawn_mover(self, kind):
        rng = self.rng
        l, r, b, t = self._board_box()
        _, _, z, _ = self._xf()
        S = self.g.cell * z
        d = rng.choice((-1, 1))
        if kind == "tumble":
            size = max(26.0, S * 0.95)
            frames = [self.g.assets.fx_tex("fx_tumble", int(size * 2))]
            y0 = rng.uniform(b + S * 0.3, max(b + S * 0.4, t - S * 1.2))
            speed = rng.uniform(*st.TUMBLE_SPEED)
        else:
            size = max(26.0, S * 0.8)
            frames = self.g.assets.fx_frames("fx_bat", int(size * 2))
            y0 = rng.uniform(b + (t - b) * 0.3, min(st.SCREEN_H - 90, t + S))
            speed = rng.uniform(150, 220)
        if not frames:
            return
        sp = arcade.Sprite(frames[0])
        x0 = -size if d > 0 else st.SCREEN_W + size
        m = {"kind": kind, "sp": sp, "frames": frames, "x": x0, "y0": y0, "dir": d,
             "v": speed, "size": size, "ph": 0.0, "hop": rng.uniform(0.35, 0.6) * size,
             "ang": 0.0, "land": False}
        self.ground_list.append(sp)
        self.movers.append(m)

    def _update_movers(self, dt):
        if self.cfg.get("tumble"):
            self.tumble_t -= dt
            if self.tumble_t <= 0:
                self.tumble_t = _rng_range(self.rng, st.TUMBLE_EVERY)
                if (self.rng.random() < st.TUMBLE_CHANCE
                        and not any(m["kind"] == "tumble" for m in self.movers)):
                    self._spawn_mover("tumble")
        if self.cfg.get("bats"):
            self.bat_t -= dt
            if self.bat_t <= 0:
                self.bat_t = _rng_range(self.rng, st.BAT_EVERY)
                if self.rng.random() < st.BAT_CHANCE:
                    self._spawn_mover("bat")
        for m in self.movers[:]:
            sp = m["sp"]
            m["x"] += m["dir"] * m["v"] * dt
            tex = sp.texture
            sc = m["size"] / max(1, tex.width)
            if m["kind"] == "tumble":
                # скачет: |sin|, на каждом касании — облачко пыли
                m["ph"] += dt * m["v"] / (m["size"] * 1.6)
                hop = abs(math.sin(m["ph"]))
                land = hop < 0.12
                if land and not m["land"]:
                    self._dust(m["x"], m["y0"] - m["size"] * 0.45)
                    m["hop"] *= 0.97
                m["land"] = land
                y = m["y0"] + hop * m["hop"]
                m["ang"] += m["dir"] * dt * m["v"] / (m["size"] * 0.5) * 57.3
                sp.angle = m["ang"]
            else:
                y = m["y0"] + math.sin(m["x"] * 0.02) * 26
                fr = m["frames"][int(self.t * 9.0) % len(m["frames"])]
                if sp.texture is not fr:
                    sp.texture = fr
                sp.angle = math.sin(self.t * 4.0) * 6
            sp.scale = sc
            sp.position = (m["x"], y)
            if m["x"] < -m["size"] * 2 or m["x"] > st.SCREEN_W + m["size"] * 2:
                self.movers.remove(m)
                try:
                    self.ground_list.remove(sp)
                except ValueError:
                    pass

    def _dust(self, x, y):
        for _ in range(4):
            a = self.rng.uniform(0.3, math.pi - 0.3)
            v = self.rng.uniform(30, 70)
            life = self.rng.uniform(0.3, 0.5)
            self.g.particles.append([x + self.rng.uniform(-8, 8), st.SCREEN_H - y,
                                     math.cos(a) * v, -math.sin(a) * v - 40, life, life,
                                     self.rng.uniform(1.5, 3.0), (214, 186, 130)])

    # ---------- сердечки и блёстки ----------

    def _update_pops(self, dt, cells):
        hearts = bool(self.cfg.get("hearts"))
        self.pop_t -= dt
        if self.pop_t <= 0:
            self.pop_t = _rng_range(self.rng, st.HEART_EVERY if hearts else st.SPARKLE_EVERY)
            closed = [sp for sp, coord in cells.values()
                      if coord is not None and self._closed(coord)]
            if closed and len(self.pops) < (6 if hearts else 9):
                sp0 = self.rng.choice(closed)
                _, _, z, _ = self._xf()
                S = self.g.cell * z
                name = "fx_heart" if hearts else "fx_sparkle"
                size = S * (self.rng.uniform(0.30, 0.42) if hearts else self.rng.uniform(0.34, 0.56))
                tex = self.g.assets.fx_tex(name, int(size * 2))
                sp = arcade.Sprite(tex)
                x = sp0.position[0] + self.rng.uniform(-0.32, 0.32) * S
                y = sp0.position[1] + self.rng.uniform(-0.32, 0.32) * S
                self.pops.append({"sp": sp, "cell": sp0, "dx": x - sp0.position[0],
                                  "dy": y - sp0.position[1], "t": 0.0,
                                  "life": 1.8 if hearts else 0.75, "size": size,
                                  "heart": hearts, "ph": self.rng.uniform(0, math.tau)})
                self.ground_list.append(sp)
        for p in self.pops[:]:
            p["t"] += dt
            u = p["t"] / p["life"]
            sp = p["sp"]
            if u >= 1.0 or id(p["cell"]) not in cells:
                self.pops.remove(p)
                try:
                    self.ground_list.remove(sp)
                except ValueError:
                    pass
                continue
            cx, cy = p["cell"].position
            tw = max(1, sp.texture.width)
            if p["heart"]:
                k = min(1.0, u * 4.0)
                sp.scale = p["size"] / tw * (0.5 + 0.5 * k)
                sp.alpha = int(230 * (1.0 - max(0.0, (u - 0.55) / 0.45)))
                sp.position = (cx + p["dx"] + math.sin(u * 6.0 + p["ph"]) * 4.0,
                               cy + p["dy"] + u * self.g.cell * 0.9)
                sp.angle = math.sin(u * 5.0 + p["ph"]) * 10
            else:
                k = math.sin(math.pi * u)
                sp.scale = p["size"] / tw * max(0.02, k)
                sp.alpha = int(255 * min(1.0, k * 1.5))
                sp.position = (cx + p["dx"], cy + p["dy"])
                sp.angle = u * 60.0

    # ---------- ERROR: поле «лагает» ----------

    def _gl_sprite(self):
        if self._gl_used >= len(self._gl_pool):
            sp = arcade.Sprite(self.g.assets.hover)
            self._gl_pool.append(sp)
            self.glitch_list.append(sp)
        sp = self._gl_pool[self._gl_used]
        self._gl_used += 1
        return sp

    def _gl_copy(self, src, dx, dy, col, alpha):
        sp = self._gl_sprite()
        sp.texture = src.texture
        sp.scale = src.scale
        sp.angle = src.angle
        sp.position = (src.position[0] + dx, src.position[1] + dy)
        sp.color = col
        sp.alpha = alpha

    def _update_glitch(self, dt, cells):
        g = self.g
        rng = self.rng
        self.glitch_t -= dt
        if self.glitch_t <= 0 and self.glitch_on <= 0 and g.shuffle_phase != "anim":
            self.glitch_on = _rng_range(rng, st.GLITCH_T)
            self.glitch_t = _rng_range(rng, st.GLITCH_EVERY) + self.glitch_on
            self._gl_step = 0.0
        self.micro_t -= dt
        if self.micro_t <= 0 and self.glitch_on <= 0:
            self.micro_t = _rng_range(rng, st.GLITCH_MICRO)
            coords = list(g.cell_sprites)
            if coords:
                self._gl_micro = {"coord": rng.choice(coords), "t": rng.uniform(0.07, 0.16),
                                  "dx": rng.choice((-1, 1)) * rng.uniform(0.08, 0.2),
                                  "col": rng.choice(((255, 90, 255), (90, 255, 255),
                                                     (255, 255, 120)))}
        self._gl_used = 0
        self.blocks = []
        self.jitter = (0.0, 0.0)
        c, s, z, _ = self._xf()
        S = g.cell * z
        if self.glitch_on > 0:
            self.glitch_on -= dt
            self._gl_step -= dt
            if self._gl_step <= 0:
                self._gl_step = rng.uniform(0.045, 0.08)
                rows = g.board.rows
                self._gl_bands = []
                for _ in range(rng.choice((1, 1, 2))):
                    h = rng.choice((1, 1, 2, 3))
                    r0 = rng.randrange(0, max(1, rows - h + 1))
                    self._gl_bands.append((r0, r0 + h, rng.choice((-1, 1))
                                           * rng.uniform(0.18, st.GLITCH_SHIFT)))
                j = st.GLITCH_JITTER
                self._gl_jit = (rng.uniform(-j, j), rng.uniform(-j * 0.5, j * 0.5))
                l, r, b, t = self._board_box()
                self._gl_blocks = []
                for _ in range(rng.randint(2, 5)):
                    w = rng.uniform(0.4, 3.0) * S
                    hh = rng.uniform(0.08, 0.35) * S
                    x = rng.uniform(l, max(l + 1, r - w))
                    y = rng.uniform(b, max(b + 1, t - hh))
                    col = rng.choice(((255, 40, 220, 120), (40, 255, 240, 110),
                                      (10, 12, 20, 150), (255, 255, 255, 90)))
                    self._gl_blocks.append((x, x + w, y, y + hh, col))
            self.jitter = self._gl_jit
            self.blocks = self._gl_blocks
            by_coord = {}
            for sp, coord in zip(g.overlay_list, g.overlay_coords):
                by_coord.setdefault(coord, []).append(sp)
            for sp, coord in zip(g.num_list, g.num_coords):
                by_coord.setdefault(coord, []).append(sp)
            for r0, r1, k in self._gl_bands:
                dx, dy = k * S * c, k * S * s
                for coord, sp in g.cell_sprites.items():
                    if r0 <= coord[1] < r1:
                        self._gl_copy(sp, dx, dy, (255, 255, 255), 255)
                        for o in by_coord.get(coord, ()):
                            self._gl_copy(o, dx, dy, (255, 255, 255), 255)
                        self._gl_copy(sp, dx + 3, dy, (255, 60, 255), 70)
        elif self._gl_micro:
            m = self._gl_micro
            m["t"] -= dt
            sp = g.cell_sprites.get(m["coord"])
            if m["t"] <= 0 or sp is None:
                self._gl_micro = None
            else:
                self._gl_copy(sp, m["dx"] * S * c, m["dx"] * S * s, m["col"], 200)
        for sp in self._gl_pool[self._gl_used:]:
            sp.alpha = 0

    # ---------- отрисовка ----------

    def draw_ground(self):
        """Украшения, блёстки, сердечки, перекати-поле, «лаг» — под туманом."""
        if not self.active:
            return
        self.deco_list.draw()
        self.ground_list.draw()
        if self._gl_used:
            self.glitch_list.draw()
        for l, r, b, t, col in self.blocks:
            arcade.draw_lrbt_rectangle_filled(l, r, b, t, col)

    def draw_air(self):
        """Снег и лепестки — поверх всего поля (и тумана)."""
        if self.active and self.flakes:
            self.air_list.draw()
