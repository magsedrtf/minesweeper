# -*- coding: utf-8 -*-
"""Звуки Minesweeper: WAV-файлы из папки sounds/ через arcade.

Если аудиоустройства нет — игра молча работает без звука.
M — вкл/выкл музыку.

МУЗЫКА (патч 10): в меню играет sounds/music.wav, в партии — свой трек
по сложности и набору испытаний (см. track_for); треки сменяются плавно
(перекрёстное затухание MUSIC_FADE секунд). Треки собирает
tools/gen_music.py.
"""
import os

import arcade

import settings as st

ROOT = os.path.dirname(os.path.abspath(__file__))
SOUNDS_DIR = os.path.join(ROOT, "sounds")

ALL_CHALLENGES = ("blitz", "noflags", "fugas", "shuffle", "orbit", "fog")


def track_for(diff_index, challenges):
    """Какой трек играет в партии:
        без испытаний        — game_easy / game_medium / game_hard (по сложности);
        только «Орбита»      — orbit (космос, напряжение мягкое);
        ВСЕ испытания на «Любителе» или «Эксперте» (с «Орбитой») — boss;
        иначе — chal или chal_hard: напряжённость = номер сложности (0..2)
                 + число испытаний; от MUSIC_TENSE_AT — chal_hard."""
    keys = set(challenges or ())
    if not keys:
        names = ("game_easy", "game_medium", "game_hard")
        return names[max(0, min(len(names) - 1, int(diff_index)))]
    if keys == {"orbit"}:
        return "orbit"
    if keys >= set(ALL_CHALLENGES) and diff_index >= 1:
        return "boss"
    tension = int(diff_index) + len(keys)
    return "chal_hard" if tension >= st.MUSIC_TENSE_AT else "chal"


class Sounds:
    """Ленивая загрузка; при неудаче все play() — no-op."""

    def __init__(self):
        self.ok = False
        self.music_on = True
        self.current = None        # имя играющего музыкального трека
        self._bank = {}
        self._music = []           # каналы: {"name", "player", "vol", "target"}
        self._music_player = None
        try:
            for name in ("boom1", "boom2", "boom3", "click", "flag",
                         "win", "lose", "music"):
                p = os.path.join(SOUNDS_DIR, name + ".wav")
                if os.path.exists(p):
                    self._bank[name] = arcade.load_sound(p)
            self.ok = "music" in self._bank
        except Exception:
            self.ok = False

    def play(self, name, volume=1.0):
        if not self.ok:
            return
        snd = self._bank.get(name)
        if snd is not None:
            try:
                arcade.play_sound(snd, volume=max(0.0, min(1.0, volume)))
            except Exception:
                pass

    # ---------- музыка ----------

    def _volume(self):
        return st.MUSIC_VOLUME if self.music_on else 0.0

    def _load_music(self, name):
        if name in self._bank:
            return self._bank[name]
        p = os.path.join(SOUNDS_DIR, name + ".wav")
        snd = None
        if os.path.exists(p):
            try:
                snd = arcade.load_sound(p)
            except Exception:
                snd = None
        self._bank[name] = snd
        return snd

    @staticmethod
    def has_track(name):
        return os.path.exists(os.path.join(SOUNDS_DIR, name + ".wav"))

    def music_start(self):
        """Фоновый луп меню (M — вкл/выкл)."""
        self.music_play("music", fade=False)

    def music_play(self, name, fade=True):
        """Сменить музыку на трек name (sounds/<name>.wav) — плавно:
        старый затихает, новый нарастает (MUSIC_FADE с). Тот же трек —
        ничего не делаем. Нет файла — остаётся музыка меню."""
        if not self.has_track(name):
            name = "music"
        if name == self.current:
            return
        self.current = name
        for ch in self._music:
            ch["target"] = 0.0
        player = None
        if self.ok:
            snd = self._load_music(name)
            if snd is not None:
                start = 0.0 if (fade and self._music) else self._volume()
                try:
                    player = arcade.play_sound(snd, start, loop=True)
                except Exception:
                    player = None
        self._music.append({"name": name, "player": player,
                            "vol": 0.0 if (fade and len(self._music) > 0) else 1.0,
                            "target": 1.0})
        self._music_player = player
        self._apply_volumes()

    def update(self, dt):
        """Каждый кадр: громкость каналов плавно идёт к цели; затихший
        канал останавливается."""
        if not self._music:
            return
        step = dt / max(0.05, st.MUSIC_FADE)
        for ch in list(self._music):
            v, t = ch["vol"], ch["target"]
            if v < t:
                ch["vol"] = min(t, v + step)
            elif v > t:
                ch["vol"] = max(t, v - step)
            if ch["target"] <= 0.0 and ch["vol"] <= 0.0:
                self._stop(ch["player"])
                self._music.remove(ch)
        self._apply_volumes()

    def _apply_volumes(self):
        base = self._volume()
        for ch in self._music:
            p = ch["player"]
            if p is not None:
                try:
                    p.volume = base * ch["vol"]
                except Exception:
                    pass

    @staticmethod
    def _stop(player):
        if player is None:
            return
        try:
            arcade.stop_sound(player)
        except Exception:
            try:
                player.pause()
                player.delete()
            except Exception:
                pass

    def music_toggle(self):
        self.music_on = not self.music_on
        self._apply_volumes()
