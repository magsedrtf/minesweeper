# Minesweeper — сборка APK

## Как устроен порт

- Движок на телефоне — **Kivy** (Python + OpenGL ES). Сам arcade на Android не запускается, поэтому
  в папке `arcade/` лежит слой совместимости: те же `arcade.Sprite`, `SpriteList`, `Text`,
  `Camera2D`, `draw_*`, звуки, но рисуют через Kivy.
- `game.py`, `ui.py`, `sprites.py`, `fieldfx.py`, `sounds.py`, `board.py`, `challenges.py`,
  `settings.py`, `saveio.py`, спрайты, звуки и шрифты — **байт-в-байт как на ПК**.
- `mobile.py` — сенсорное управление (переводит касания в те же вызовы, что мышь/клавиатура).
- `main.py` — точка входа для Android. ПК-версию запускай из исходной папки
  (здесь локальный `arcade/` заслоняет настоящий).

## Управление

| Жест | Что делает |
|---|---|
| Тап | ЛКМ: открыть клетку, нажать кнопку |
| Долгое нажатие (0,4 с) | ПКМ: флажок (с вибрацией) |
| Два пальца | двигать карту + щипок = зум (в любой партии) |
| Один палец тянет | двигать карту (без тумана) |
| Туман: палец тянет | несёт лампу; пока держишь — другим пальцем тап/флажки |
| Туман: покачать лампу пальцем или потрясти телефон | зарядить лампу |
| Кнопка «ЛАМПА» (справа внизу) | = ПРОБЕЛ (вкл/выкл лампу) |
| Тап во время взрывов | = ПРОБЕЛ (пропустить) |
| Свайп в магазине/инвентаре | = колесо мыши |
| Кнопка «Назад» | = ESC |
| ♪ в меню | = M (музыка) |

Пороги (долгое нажатие, сила тряски) — в начале `mobile.py`.

## Сборка на ПК (Windows → WSL2 Ubuntu, или просто Linux)

1. Один раз установи зависимости:

```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv autoconf libtool \
    pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo6 cmake libffi-dev libssl-dev
python3 -m venv ~/bz && source ~/bz/bin/activate
pip install --upgrade buildozer cython==0.29.36 setuptools
```

2. Распакуй архив **внутри Linux-диска WSL** (например `~/Minesweeper_android`, не в `/mnt/c/...` — там очень медленно).

3. Собери:

```bash
cd ~/Minesweeper_android
source ~/bz/bin/activate
buildozer android debug
```

Первая сборка сама скачает Android SDK/NDK (~3 ГБ, 20–40 мин). Готовый файл: `bin/minesweeper-1.0-arm64-v8a_armeabi-v7a-debug.apk`.

4. Скинь APK на телефон и установи (разреши «установку из неизвестных источников»).
   Или по USB с отладкой: `buildozer android deploy run logcat | grep python`.

## Быстрая проверка на ПК без телефона

```bash
pip install kivy pillow plyer
python main.py
```

Мышь = один палец (ПКМ тоже ставит флажок). Второй палец для щипка на ПК не эмулируется.

## Сейв

Сейв лежит в папке приложения на телефоне (та же логика `saveio.py`). В APK сейв с ПК не кладётся.
Чтобы перенести прогресс с ПК, убери `minesweeper_save.json` из `source.exclude_patterns`
в `buildozer.spec` и пересобери. После этого верни строку, иначе каждое обновление будет затирать сейв на телефоне.
