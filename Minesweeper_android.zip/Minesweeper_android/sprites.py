# -*- coding: utf-8 -*-
"""Спрайты Minesweeper — ВСЯ графика игры лежит в одной папке sprites/.

Каждый элемент интерфейса и игрового поля — обычный PNG с прозрачностью:
    sprites/background.png      — фон меню
    sprites/badge.png           — круглая эмблема с бомбой (+ badge_shadow.png)
    sprites/ribbon_*.png        — ленты-кнопки главного меню
    sprites/btn_*.png           — панели кнопок (заливка/градиент/рамка)
    sprites/panel_*.png         — панели оверлеев (победа/взрыв/подтверждение)
    sprites/coin.png            — монета (показывается только в магазине)
    sprites/hud_bar.png         — верхняя полоса HUD
    sprites/t_<скин>_closed.png  — закрытая клетка (скины поля)
    sprites/t_<скин>_closed2.png — её тёмный вариант (шахматка, необязателен)
    sprites/t_<скин>_open.png    — открытая клетка
    sprites/tile_scorch.png     — обугленная клетка (больше не используется:
                                  после взрыва остаётся обычная клетка)
    sprites/explosion_01..NN.png — кадры анимации взрыва бомбы
    sprites/panel_chal.png      — панель испытаний на экране «ИГРАТЬ»
                                  (+ panel_chal_glow.png — её свечение)
    sprites/f_<скин>.png        — флажок, кадр 0
    sprites/f_<скин>_f1..3.png  — флажок, кадры анимации (волна)
    sprites/b_<скин>.png        — бомба
    sprites/num_1..8.png        — векторные цифры клеток (в духе minesweeper.online)
    sprites/fog_cloud_0..3.png, fog_wisp.png, fog_dark.png, fog_vignette.png,
    lamp.png, lamp_glow.png — «ТУМАН» (tools/gen_fog.py)

Свой скин: положите PNG в sprites/ (f_мой.png / b_мой.png / t_мой_closed.png)
— он сам появится в ИНВЕНТАРЕ. Кадры анимации флажка не обязательны:
без них флажок просто статичный.
"""
import os
import re

import arcade

import settings as st

ROOT = os.path.dirname(os.path.abspath(__file__))
SPRITES_DIR = os.path.join(ROOT, "sprites")

_TILE_TEX = 64          # рендер-размер PNG тайла
_FRAME_RE = re.compile(r"^(f|b|t)_(.+?)(_closed|_open|_f\d+)?$")
_TILE_SKIN_RE = re.compile(r"^t_([a-zA-Z0-9_]+?)_(closed2|closed|open)\.png$")


def _path(name):
    return os.path.join(SPRITES_DIR, name)


def _tex(name, fallback_color=None):
    """Текстура из sprites/; если файла нет — однотонная заглушка."""
    p = _path(name)
    if os.path.exists(p):
        try:
            return arcade.load_texture(p)
        except Exception:
            pass
    tex = arcade.Texture.create_empty(name, (2, 2))
    return tex


_BEVEL_MASKS = {}


def _bevel_f(d, bw):
    """Спад фаски от края внутрь: 1 у края -> 0 на глубине bw (плавно)."""
    t = max(0.0, 1.0 - d / bw)
    return t * t * (3.0 - 2.0 * t) * t


def _bevel_masks(w, h, wfrac):
    """Маски фаски для клетки w×h: (свет, тень) — PIL «L».
    Верх/лево — свет, низ/право — тень, углы смешиваются плавно.
    Рамка PNG (~3 % края) не трогается."""
    key = (w, h, round(wfrac, 4))
    if key in _BEVEL_MASKS:
        return _BEVEL_MASKS[key]
    from PIL import Image
    inset = max(1, int(round(min(w, h) * 4.0 / 128.0)))
    bw = max(2.0, min(w, h) * float(wfrac))
    light, shade = [], []
    for y in range(h):
        # весь квадрат чуть светлее сверху и чуть темнее снизу
        gy = 1.0 - 2.0 * (y + 0.5) / h
        for x in range(w):
            dt, dl = y - inset, x - inset
            db, dr = (h - 1 - inset) - y, (w - 1 - inset) - x
            if min(dt, dl, db, dr) < 0:     # рамка PNG — как была
                light.append(0)
                shade.append(0)
                continue
            # края складываются плавно (без резких «усов» в углах):
            # левый верхний угол — самый светлый, правый нижний — тёмный
            v = (_bevel_f(dt, bw) + 0.7 * _bevel_f(dl, bw)
                 - _bevel_f(db, bw) - 0.7 * _bevel_f(dr, bw)
                 + 0.16 * gy)
            light.append(int(255 * max(0.0, v)))
            shade.append(int(255 * max(0.0, -v)))
    lm, sm = Image.new("L", (w, h)), Image.new("L", (w, h))
    lm.putdata(light)
    sm.putdata(shade)
    _BEVEL_MASKS[key] = (lm, sm)
    return lm, sm


def bevel_image(im, k=1.0, wfrac=0.11):
    """Лёгкий объём закрытой клетки: светлая фаска сверху/слева, тень
    снизу/справа. k — сила (1.0 — едва заметно), wfrac — ширина фаски
    (доля клетки). Возвращает новую PIL-картинку RGBA."""
    from PIL import Image
    im = im.convert("RGBA")
    lm, sm = _bevel_masks(im.width, im.height, wfrac)
    kl, ks = 0.20 * k, 0.24 * k            # макс. доля белого / чёрного
    lm = lm.point(lambda v: int(v * kl))
    sm = sm.point(lambda v: int(v * ks))
    white = Image.new("RGBA", im.size, (255, 255, 255, 255))
    black = Image.new("RGBA", im.size, (0, 0, 0, 255))
    out = Image.composite(white, im, lm)
    out = Image.composite(black, out, sm)
    out.putalpha(im.getchannel("A"))
    return out


def boom_image(im):
    """Клетка взорвавшейся мины из открытой клетки скина: темнее в
    BOOM_CELL_DARK раз, затем смешана с BOOM_CELL_COLOR на BOOM_CELL_MIX."""
    from PIL import Image
    mix = max(0.0, min(1.0, float(st.BOOM_CELL_MIX)))
    dark = max(0.0, min(1.0, float(getattr(st, "BOOM_CELL_DARK", 1.0))))
    im = im.convert("RGBA")
    base = im.convert("RGB").point(lambda v: int(v * dark))
    red = Image.new("RGB", im.size, tuple(st.BOOM_CELL_COLOR))
    out = Image.blend(base, red, mix).convert("RGBA")
    out.putalpha(im.getchannel("A"))
    return out


class Assets:
    """Загрузка и учёт всех спрайтов игры."""

    def __init__(self):
        self.background = _tex("background.png")
        self.badge = _tex("badge.png")
        self.badge_shadow = _tex("badge_shadow.png")
        self.coin = _tex("coin.png")
        self.hud_bar = _tex("hud_bar.png")
        self.hover = _tex("hover.png")
        self.panel_result = _tex("panel_result.png")
        self.panel_confirm = _tex("panel_confirm.png")
        self.panel_toast = _tex("panel_toast.png")
        # испытание «ТУМАН»: клочок тумана, облако, фонарь и его свет
        self.fog_clouds = [_tex("fog_cloud_{}.png".format(i)) for i in range(4)]
        self.fog_wisp = _tex("fog_wisp.png")
        self.fog_dark = _tex("fog_dark.png")
        self.fog_vignette = _tex("fog_vignette.png")
        self.lamp = _tex("lamp.png")
        self.lamp_glow = _tex("lamp_glow.png")

        self.ribbons = {k: _tex("ribbon_{}.png".format(k))
                        for k in ("play", "fire", "shop", "bag", "exit")}
        self.panel_chal = _tex("panel_chal.png")
        self.panel_chal_glow = _tex("panel_chal_glow.png")
        # кадры взрыва: explosion_01.png, explosion_02.png, ... (по номеру)
        self.explosion = self._load_frames("explosion")

        self.flags = {}     # skin -> [Texture, ...] кадры анимации
        self.bombs = {}     # skin -> Texture
        self.tiles = {}     # skin -> {"closed": Texture, "open": Texture}
        self.scorch = _tex("tile_scorch.png")
        self._load_skins()

        self._buttons = {}  # (color, w, h) -> Texture
        self._flag_icons = {}
        self._bomb_icons = {}
        self._tile_icons = {}
        self._derived = {}  # производные текстуры: белые силуэты, красная бомба

    @staticmethod
    def _load_frames(prefix):
        """Кадры анимации <prefix>_NN.png из sprites/ по возрастанию номера."""
        if not os.path.isdir(SPRITES_DIR):
            return []
        found = []
        for fn in os.listdir(SPRITES_DIR):
            m = re.match(r"^" + re.escape(prefix) + r"_(\d+)\.png$", fn)
            if m:
                found.append((int(m.group(1)), fn))
        return [_tex(fn) for _, fn in sorted(found)]

    # ---------- скины ----------

    def _load_skins(self):
        files = sorted(f for f in os.listdir(SPRITES_DIR)
                       if f.lower().endswith(".png")) if os.path.isdir(SPRITES_DIR) else []
        for fn in files:
            m = re.match(r"^(f_[a-zA-Z0-9_]+?)_f(\d+)\.png$", fn)
            if m:
                self.flags.setdefault(m.group(1), []).append((int(m.group(2)), _tex(fn)))
                continue
            if fn.startswith("f_"):
                self.flags.setdefault(fn[:-4], []).append((0, _tex(fn)))
                continue
            if fn.startswith("b_"):
                self.bombs[fn[:-4]] = _tex(fn)
                continue
            m = _TILE_SKIN_RE.match(fn)
            if m:
                kind = m.group(2)
                tex = self._bevel_tex(fn) if kind.startswith("closed") else _tex(fn)
                self.tiles.setdefault(m.group(1), {})[kind] = tex

        # кадры анимации по порядку: базовый (0), затем _f1, _f2, ...
        for skin in self.flags:
            self.flags[skin] = [t for _, t in sorted(self.flags[skin], key=lambda p: p[0])]
        # скины поля: если нет _open — используем _closed
        for skin, pair in self.tiles.items():
            pair.setdefault("open", pair.get("closed"))
            pair.setdefault("closed", pair.get("open"))

    def flag_frames(self, skin):
        """Кадры анимации флажка (один и более)."""
        return self.flags.get(skin) or self.flags.get("f_classic") or []

    def flag_bbox(self, skin):
        """Рамка непрозрачной части флажка (объединение по всем кадрам):
        ((left, top, right, bottom), (w, h)) в пикселях PNG, y сверху вниз.
        Нужна, чтобы вписать флажок по размеру (например, в заголовок)."""
        name = skin if skin in self.flags else "f_classic"
        key = ("bbox", name)
        if key not in self._derived:
            box, size = None, None
            files = [name + ".png"] + sorted(
                (f for f in os.listdir(SPRITES_DIR)
                 if re.match(r"^" + re.escape(name) + r"_f\d+\.png$", f)),
                key=lambda f: int(f.rsplit("_f", 1)[1][:-4])
            ) if os.path.isdir(SPRITES_DIR) else []
            for fn in files:
                im = self._open_rgba(fn)
                if im is None:
                    continue
                size = im.size
                b = im.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
                if b:
                    box = b if box is None else (min(box[0], b[0]), min(box[1], b[1]),
                                                 max(box[2], b[2]), max(box[3], b[3]))
            if size is None:
                size = (96, 96)
            self._derived[key] = (box or (0, 0) + size, size)
        return self._derived[key]

    @staticmethod
    def flag_fps(skin):
        """Кадров в секунду для анимации флажка (FLAG_SKIN_FPS или FLAG_FPS)."""
        return getattr(st, "FLAG_SKIN_FPS", {}).get(skin, st.FLAG_FPS)

    def flag_icon(self, skin, size):
        """Текстура флажка для иконки в магазине/инвентаре."""
        key = ("f", skin, int(size))
        if key not in self._flag_icons:
            frames = self.flag_frames(skin)
            self._flag_icons[key] = frames[0] if frames else _tex("f_classic.png")
        return self._flag_icons[key]

    def bomb_icon(self, skin, size):
        key = ("b", skin, int(size))
        if key not in self._bomb_icons:
            self._bomb_icons[key] = self.bombs.get(skin) or self.bombs.get("b_classic")
        return self._bomb_icons[key]

    # ---------- производные текстуры (строятся из PNG в памяти) ----------

    @staticmethod
    def _open_rgba(name):
        """PIL-картинка из sprites/ (RGBA) или None, если файла нет."""
        p = _path(name)
        if not os.path.exists(p):
            return None
        try:
            from PIL import Image
            with Image.open(p) as im:
                return im.convert("RGBA")
        except Exception:
            return None

    def silhouette(self, name):
        """Белый силуэт PNG (форма по альфа-каналу) — для декора фона.
        None, если файла нет."""
        key = ("white", name)
        if key not in self._derived:
            im = self._open_rgba(name)
            tex = None
            if im is not None:
                from PIL import Image
                white = Image.new("RGBA", im.size, (255, 255, 255, 0))
                white.putalpha(im.getchannel("A"))
                tex = arcade.Texture(white, hash="white_" + name)
            self._derived[key] = tex
        return self._derived[key]

    def bomb_red(self, skin):
        """Красная версия бомбы (светотень сохраняется) — её рисуем поверх
        обычной с меняющейся прозрачностью, и временная бомба «краснеет»."""
        key = ("red", skin)
        if key not in self._derived:
            name = skin if skin in self.bombs else "b_classic"
            im = self._open_rgba(name + ".png")
            tex = None
            if im is not None:
                from PIL import Image
                lum = im.convert("L")
                r = lum.point(lambda v: int(150 + 105 * (v / 255.0)))
                g = lum.point(lambda v: int(18 + 150 * (v / 255.0) ** 2))
                b = lum.point(lambda v: int(14 + 130 * (v / 255.0) ** 2))
                red = Image.merge("RGBA", (r, g, b, im.getchannel("A")))
                tex = arcade.Texture(red, hash="red_" + name)
            self._derived[key] = tex or self.bomb_icon(skin, 96)
        return self._derived[key]

    def bomb_shards(self, skin, n=7):
        """Бомба, «расколотая» на n осколков с рваными краями: список
        (Texture, ox, oy), где (ox, oy) — смещение центра осколка от центра
        PNG (в пикселях текстуры, y вверх, как в arcade). Сложенные вместе
        осколки дают целую бомбу — при взрыве они разлетаются в стороны."""
        name = skin if skin in self.bombs else "b_classic"
        n = max(2, int(n))
        key = ("shards", name, n)
        if key in self._derived:
            return self._derived[key]
        out = []
        im = self._open_rgba(name + ".png")
        if im is not None:
            out = _cut_shards(im, n, name)
        self._derived[key] = out
        return out

    def _bevel_tex(self, fn):
        """Закрытая клетка с лёгким объёмом (фаска, settings.TILE_BEVEL):
        PNG не меняется — объём добавляется при загрузке. 0 — плоско."""
        k = float(getattr(st, "TILE_BEVEL", 0.0))
        if k <= 0.0:
            return _tex(fn)
        im = self._open_rgba(fn)
        if im is None:
            return _tex(fn)
        try:
            out = bevel_image(im, k, getattr(st, "TILE_BEVEL_W", 0.11))
            return arcade.Texture(out, hash="bevel{:g}_{}".format(k, fn))
        except Exception:
            return _tex(fn)

    def panel_stretch(self, name, width):
        """Панель name.png, растянутая по ширине до width px (в пикселях
        самой PNG): закруглённые края не искажаются — тянется середина."""
        key = ("stretch", name, int(width))
        if key not in self._derived:
            im = self._open_rgba(name)
            tex = None
            if im is not None:
                from PIL import Image
                sw, sh = im.size
                width = max(sw, int(width))
                cap = min(sw // 2 - 1, max(8, sh))
                out = Image.new("RGBA", (width, sh), (0, 0, 0, 0))
                out.paste(im.crop((0, 0, cap, sh)), (0, 0))
                out.paste(im.crop((sw - cap, 0, sw, sh)), (width - cap, 0))
                mid = im.crop((cap, 0, sw - cap, sh)).resize(
                    (width - 2 * cap, sh), Image.BILINEAR)
                out.paste(mid, (cap, 0))
                tex = arcade.Texture(out, hash="stretch_{}_{}".format(name, width))
            self._derived[key] = tex
        return self._derived[key]

    def vignette(self, size=0.55):
        """Виньетка «Тумана» (тёмные края экрана), строится в памяти:
        size — как далеко темнота заходит к центру (0.2..0.9). Края
        текстуры — полностью тёмные; рисуется ровно по экрану."""
        size = max(0.05, min(0.95, float(size)))
        key = ("vignette", round(size, 3))
        if key not in self._derived:
            from PIL import Image
            w, h = 320, 180
            # radial_gradient 256×256: 0 в центре, ~180 — середина края
            rad = Image.radial_gradient("L")
            edge = float(rad.getpixel((255, 128))) or 180.0
            rad = rad.resize((w, h), Image.BILINEAR)
            r0 = 1.0 - size                 # отсюда (доля полуэкрана) темнеет

            def lut(v):
                r = v / edge                # 1.0 — середина края экрана
                t = max(0.0, min(1.0, (r - r0) / max(1e-3, 1.0 - r0)))
                return int(255 * (t * t * (3.0 - 2.0 * t)) ** 1.1)
            alpha = rad.point(lut)
            im = Image.new("RGBA", (w, h), (3, 5, 13, 0))
            im.putalpha(alpha)
            self._derived[key] = arcade.Texture(
                im, hash="vignette_{:.3f}".format(size))
        return self._derived[key]

    def tile_boom(self, skin):
        """Клетка взорвавшейся НАСТОЯЩЕЙ мины: открытая клетка скина,
        смешанная с BOOM_CELL_COLOR — чуть темнее и красная."""
        key = ("boom", skin)
        if key not in self._derived:
            name = skin if skin in self.tiles else "classic"
            im = self._open_rgba("t_{}_open.png".format(name))
            if im is None:
                im = self._open_rgba("t_{}_closed.png".format(name))
            tex = None
            if im is not None:
                tex = arcade.Texture(boom_image(im), hash="boom_{}_{:g}_{:g}_{}".format(
                    name, st.BOOM_CELL_MIX, st.BOOM_CELL_DARK, st.BOOM_CELL_COLOR))
            self._derived[key] = tex or self.tile_open(skin)
        return self._derived[key]

    def tile_icon(self, skin):
        """Иконка скина поля для магазина/инвентаря: мини-поле 2×2
        (закрытая, тёмная, открытая клетки) и украшение скина
        (settings.FIELD_ICON). Нет PNG — просто закрытая клетка."""
        pair = self.tiles.get(skin) or self.tiles.get("classic") or {}
        key = ("tile_icon", skin)
        if key in self._derived:
            return self._derived[key] or pair.get("closed")
        tex = None
        try:
            tex = self._tile_icon_tex(skin)
        except Exception:
            tex = None
        self._derived[key] = tex
        return tex or pair.get("closed")

    def _tile_icon_tex(self, skin):
        from PIL import Image
        k = float(getattr(st, "TILE_BEVEL", 0.0))
        ims = {}
        for kind in ("closed", "closed2", "open"):
            im = self._open_rgba("t_{}_{}.png".format(skin, kind))
            if im is None and kind == "closed2":
                im = ims.get("closed")
            if im is None:
                return None
            if kind != "open" and k > 0:
                im = bevel_image(im, k, getattr(st, "TILE_BEVEL_W", 0.11))
            ims[kind] = im.resize((64, 64), Image.LANCZOS)
        out = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        out.paste(ims["closed"], (0, 0))
        out.paste(ims["closed2"], (64, 0))
        out.paste(ims["closed2"], (0, 64))
        out.paste(ims["open"], (64, 64))
        name = getattr(st, "FIELD_ICON", {}).get(skin)
        if name == "glitch":
            band = out.crop((0, 40, 128, 62))
            r, g, b, a = band.split()
            out.paste(Image.merge("RGBA", (r, g.point(lambda v: v // 2), b, a)), (10, 40))
            out.paste(band, (-6, 44), band)
        elif name:
            im = self._open_rgba(name + ".png")
            if im is not None:
                bb = im.getchannel("A").getbbox()
                if bb:
                    im = im.crop(bb)
                f = 86.0 / max(im.size)
                im = im.resize((max(1, int(im.width * f)), max(1, int(im.height * f))),
                               Image.LANCZOS)
                out.alpha_composite(im, ((128 - im.width) // 2, 124 - im.height))
        return arcade.Texture(out, hash="tile_icon_" + skin)

    # ---------- украшения и эффекты полей (fieldfx.py) ----------

    def _crop_png(self, name):
        key = ("crop", name)
        if key not in self._derived:
            im = self._open_rgba(name + ".png")
            if im is not None:
                bb = im.getchannel("A").getbbox()
                if bb:
                    im = im.crop(bb)
            self._derived[key] = im
        return self._derived[key]

    def _scaled_tex(self, name, px, by="h"):
        """PNG name (без полей) уменьшенный LANCZOS до px по высоте
        (by="h") или по большей стороне ("max"); arcade.Texture или None."""
        key = ("dtex", name, int(px), by)
        if key not in self._derived:
            from PIL import Image
            im = self._crop_png(name)
            tex = None
            if im is not None:
                side = im.height if by == "h" else max(im.size)
                f = min(1.0, float(px) / max(1, side))
                if f < 0.999:
                    im = im.resize((max(1, int(round(im.width * f))),
                                    max(1, int(round(im.height * f)))), Image.LANCZOS)
                tex = arcade.Texture(im, hash="d_{}_{}_{}".format(name, int(px), by))
            self._derived[key] = tex
        return self._derived[key]

    def _frame_names(self, base):
        """base.png, base_1.png, base_2.png, ... (кадры украшения/эффекта)."""
        key = ("fnames", base)
        if key not in self._derived:
            names = []
            if os.path.exists(_path(base + ".png")):
                names.append(base)
                i = 1
                while os.path.exists(_path("{}_{}.png".format(base, i))):
                    names.append("{}_{}".format(base, i))
                    i += 1
            self._derived[key] = names
        return self._derived[key]

    def deco_frames(self, base, px):
        """Кадры украшения высотой ~px (запас ×2 к размеру на экране)."""
        px = max(8, int(px) // 4 * 4)
        return [t for t in (self._scaled_tex(n, px, "h") for n in self._frame_names(base)) if t]

    def fx_frames(self, base, px):
        px = max(8, int(px) // 4 * 4)
        return [t for t in (self._scaled_tex(n, px, "max") for n in self._frame_names(base)) if t]

    def fx_tex(self, name, px):
        fr = self.fx_frames(name, px)
        return fr[0] if fr else self.hover

    def deco_color(self, base):
        """Средний цвет украшения (для крошек, когда оно исчезает)."""
        key = ("dcol", base)
        if key not in self._derived:
            col = (230, 230, 230)
            im = self._crop_png(base)
            if im is not None:
                sm = im.resize((16, 16))
                data = (sm.get_flattened_data() if hasattr(sm, "get_flattened_data")
                        else sm.getdata())
                px = [p for p in data if p[3] > 128]
                if px:
                    col = tuple(int(sum(p[i] for p in px) / len(px)) for i in range(3))
            self._derived[key] = col
        return self._derived[key]

    def tile_closed(self, skin):
        pair = self.tiles.get(skin) or self.tiles.get("classic") or {}
        return pair.get("closed") or self.scorch

    def tile_closed2(self, skin):
        """Тёмный вариант закрытой клетки (шахматная раскладка).
        Если файла t_<скин>_closed2.png нет — обычная закрытая."""
        pair = self.tiles.get(skin) or self.tiles.get("classic") or {}
        return pair.get("closed2") or pair.get("closed") or self.scorch

    def digit_image(self, n):
        """Векторная цифра клетки (sprites/num_<n>.png) как PIL RGBA —
        игра плавно уменьшает её под размер клетки. None, если PNG нет."""
        key = ("digit", n)
        if key not in self._derived:
            self._derived[key] = self._open_rgba("num_{}.png".format(n))
        return self._derived[key]

    def tile_is_dark(self, skin):
        """Тёмная ли открытая клетка скина (для светлого варианта цифр)."""
        key = ("dark", skin)
        if key not in self._derived:
            dark = False
            im = self._open_rgba("t_{}_open.png".format(skin))
            if im is not None:
                from PIL import ImageStat
                r, g, b = ImageStat.Stat(im.convert("RGB")).mean
                dark = (0.299 * r + 0.587 * g + 0.114 * b) < 100
            self._derived[key] = dark
        return self._derived[key]

    def tile_open(self, skin):
        pair = self.tiles.get(skin) or self.tiles.get("classic") or {}
        return pair.get("open") or pair.get("closed") or self.scorch

    # ---------- кнопки ----------

    def button(self, color_key, w, h):
        """Панель кнопки (PNG btn_<цвет>_<ш>х<в>).
        Если панели точного размера нет — собираем её из самой крупной
        панели этого цвета девятью кусочками (углы не искажаются),
        а если и цвета нет — однотонная заглушка."""
        key = (color_key, int(w), int(h))
        if key in self._buttons:
            return self._buttons[key]
        name = "btn_{}_{}x{}.png".format(color_key, int(w), int(h))
        if not os.path.exists(_path(name)):
            src = self._largest_btn(color_key)
            if src:
                tex = self._nine_patch(src[0], int(w), int(h), key)
                self._buttons[key] = tex
                return tex
        self._buttons[key] = _tex(name)
        return self._buttons[key]

    def _largest_btn(self, color_key):
        """Самая крупная PNG-панель заданного цвета: (файл, ш, в)."""
        best = None
        if os.path.isdir(SPRITES_DIR):
            for fn in os.listdir(SPRITES_DIR):
                m = re.match(r"^btn_" + re.escape(color_key) +
                             r"_(\d+)x(\d+)\.png$", fn)
                if m:
                    area = int(m.group(1)) * int(m.group(2))
                    if best is None or area > best[0]:
                        best = (area, fn, int(m.group(1)), int(m.group(2)))
        return best[1:] if best else None

    def _nine_patch(self, src, w, h, cache_key):
        """Собираем панель точного размера из 9 кусочков исходной."""
        from PIL import Image
        im = Image.open(_path(src)).convert("RGBA")
        sw, sh = im.size
        c = max(8, min(24, sw // 4, sh // 4))
        # маленькая кнопка: собираем крупнее (углы целиком), спрайт её
        # всё равно масштабирует до нужного размера
        k = max(1, -(-2 * c // max(1, min(w, h))))
        w, h = w * k, h * k
        out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        mid_w, mid_h = w - 2 * c, h - 2 * c
        # углы — без искажений
        out.paste(im.crop((0, 0, c, c)), (0, 0))
        out.paste(im.crop((sw - c, 0, sw, c)), (w - c, 0))
        out.paste(im.crop((0, sh - c, c, sh)), (0, h - c))
        out.paste(im.crop((sw - c, sh - c, sw, sh)), (w - c, h - c))
        if mid_w > 0:
            out.paste(im.crop((c, 0, sw - c, c)).resize((mid_w, c), Image.LANCZOS),
                      (c, 0))
            out.paste(im.crop((c, sh - c, sw - c, sh)).resize((mid_w, c), Image.LANCZOS),
                      (c, h - c))
        if mid_h > 0:
            out.paste(im.crop((0, c, c, sh - c)).resize((c, mid_h), Image.LANCZOS),
                      (0, c))
            out.paste(im.crop((sw - c, c, sw, sh - c)).resize((c, mid_h), Image.LANCZOS),
                      (w - c, c))
        if mid_w > 0 and mid_h > 0:
            out.paste(im.crop((c, c, sw - c, sh - c)).resize(
                (mid_w, mid_h), Image.LANCZOS), (c, c))
        return arcade.Texture(out, hash="btn9_{}_{}x{}".format(*cache_key))

    # ---------- пользовательские скины ----------

    def custom_skins(self, kind):
        """PNG-скины из sprites/, которых нет в магазине."""
        return [it_id for it_id in self._all_skin_ids(kind)
                if st.item_by_id(it_id) is None]

    def _all_skin_ids(self, kind):
        if kind == "tile":
            ids = ["t_" + skin for skin in self.tiles]
        else:
            # ключи flags/bombs уже содержат префикс f_/b_
            book = self.flags if kind == "flag" else self.bombs
            ids = list(book.keys())
        return sorted(set(ids))

    def skin_title(self, skin_id):
        return skin_id.replace("_", " ").strip().capitalize()


def _cut_shards(im, n, name):
    """Режем PNG на n клиньев от центра (края клиньев — ломаные)."""
    import math
    import random
    import zlib
    from PIL import Image, ImageDraw
    rnd = random.Random(zlib.crc32(name.encode("utf-8")) ^ n)
    w, h = im.size
    alpha = im.getchannel("A")
    bb = alpha.getbbox() or (0, 0, w, h)
    cx = (bb[0] + bb[2]) / 2.0 + rnd.uniform(-0.06, 0.06) * (bb[2] - bb[0])
    cy = (bb[1] + bb[3]) / 2.0 + rnd.uniform(-0.06, 0.06) * (bb[3] - bb[1])
    far = math.hypot(w, h)
    base = rnd.uniform(0, math.tau)
    angs = [base + (i + rnd.uniform(-0.28, 0.28)) * math.tau / n for i in range(n)]
    # ломаная граница вдоль каждого луча (общая для соседних осколков)
    rays = []
    for a in angs:
        pts = []
        steps = 5
        for j in range(1, steps + 1):
            rr = far * j / steps * 0.6
            jit = rnd.uniform(-0.22, 0.22) * (far / steps) * 0.6 if j < steps else 0.0
            pts.append((cx + math.cos(a) * rr - math.sin(a) * jit,
                        cy + math.sin(a) * rr + math.cos(a) * jit))
        rays.append(pts)
    out = []
    for i in range(n):
        a0 = angs[i]
        a1 = angs[(i + 1) % n] + (math.tau if i == n - 1 else 0.0)
        poly = [(cx, cy)] + rays[i]
        for k in range(1, 6):          # внешняя дуга (за пределами картинки)
            a = a0 + (a1 - a0) * k / 6.0
            poly.append((cx + math.cos(a) * far, cy + math.sin(a) * far))
        poly += list(reversed(rays[(i + 1) % n]))
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).polygon(poly, fill=255)
        piece = im.copy()
        piece.putalpha(Image.composite(alpha, Image.new("L", (w, h), 0), mask))
        pb = piece.getchannel("A").getbbox()
        if not pb:
            continue
        piece = piece.crop(pb)
        ox = (pb[0] + pb[2]) / 2.0 - w / 2.0
        oy = -((pb[1] + pb[3]) / 2.0 - h / 2.0)       # y вверх (arcade)
        tex = arcade.Texture(piece, hash="shard_{}_{}_{}".format(name, n, i))
        out.append((tex, ox, oy))
    return out
